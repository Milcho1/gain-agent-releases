#!/usr/bin/env node
"use strict";

// G.A.I.N Agent CLI: metadata-only AI usage visibility for local/dev workflows.
// Commands: scan <path> [--mode m] [--json] [--no-report] | status | doctor | flush

const path = require("path");
const fs = require("fs");
const { spawnSync } = require("child_process");
const { loadConfig, configPath, readConfigFile, writeConfigFile, DEFAULT_SUPABASE_URL, DEPLOYMENT_MODES } = require("../config/loadPolicy");
const { findProjectPolicy } = require("../config/projectConfig");
const { getOrgPolicyBundle, cachePath, writePolicyCache } = require("../config/orgPolicyCache");
const { loadBaseline, writeBaseline, applyBaseline, baselinePath } = require("../config/baseline");
const { loadGainignore, findRepoRoot } = require("../config/gainignore");
const { scanFileMetadata } = require("../scanners/scanFileMetadata");
const { decide } = require("../policies/decisionEngine");
const localQueue = require("../reporters/localQueue");
const {
  sendEvent,
  checkConnection,
  enrollDevice,
  sendHeartbeat,
  sendPresence,
  isConfigured,
  AGENT_VERSION
} = require("../reporters/supabaseEdgeClient");
const { PATTERNS_PATH, getDetector } = require("../scanners/patterns");
const { detectSensitivePatterns } = require("../scanners/patterns");
const { redactSensitiveText, getRedactor, REDACT_PATH } = require("../scanners/redact");
const { verifyLicense, enforceLicenseSeatCount } = require("../license/verify");
const { installHealthSchedule, uninstallHealthSchedule, installDesktopGuardSchedule, uninstallDesktopGuardSchedule, installAutoUpdateSchedule, uninstallAutoUpdateSchedule } = require("../system/healthSchedule");
const { isRevokedResponse, markAgentDormant } = require("../system/dormancy");
const { sendSiemEvent } = require("../reporters/siem");
const { checkForUpdate, runHostedInstaller, reportWindowsUpdateFailure } = require("../system/updater");
const { installProxyService, uninstallProxyService, getProxyServiceStatus, runProxyServiceWatchdog, ENV_VARS, parseLoopbackProxyUrl } = require("../system/proxyService");
const { actionLine, patternLabel } = require("../ui/messages");

function currentCliPath() {
  return process.pkg ? process.execPath : path.resolve(__dirname, "index.js");
}

const BOOL_FLAGS = {
  "--no-report": "noReport",
  "--json": "json",
  "--write": "write",
  "--force": "force",
  "--no-baseline": "noBaseline",
  "--no-gainignore": "noGainignore",
  "--auto-update": "autoUpdate",
  "--disable-auto-update": "disableAutoUpdate",
  "--telemetry-enabled": "telemetryEnabled",
  "--no-telemetry": "noTelemetry",
  "--check": "check",
  "--scheduled": "scheduled",
  "--apply": "apply",
  "--once": "once",
  "--no-service": "noService",
  "--no-proxy-env": "noProxyEnv",
  "--no-git-hook": "noGitHook"
};
const VALUE_FLAGS = {
  "--mode": "mode",
  "--org-key": "orgKey",
  "--supabase-url": "supabaseUrl",
  "--supabase-key": "supabaseKey",
  "--label": "label",
  "--department": "department",
  "--deployment-mode": "deploymentMode",
  "--siem-webhook-url": "siemWebhookUrl",
  "--siem-token": "siemToken",
  "--access-mode": "accessMode",
  "--approved-tools": "approvedTools",
  "--blocked-tools": "blockedTools",
  "--desktop-guard": "desktopGuard",
  "--desktop-guard-apps": "desktopGuardApps",
  "--app": "app",
  "--domain": "domain",
  "--exec": "exec",
  "--host": "host",
  "--port": "port",
  "--service": "service",
  "--proxy-fail-policy": "proxyFailPolicy",
  "--interval-ms": "intervalMs",
  "--anthropic-upstream": "anthropicUpstream",
  "--openai-upstream": "openaiUpstream",
  "--tools": "tools",
  "--old-version": "oldVersion",
  "--new-version": "newVersion",
  "--reason": "reason"
};

function parseArgs(argv) {
  const args = { _: [], flags: {} };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (BOOL_FLAGS[token]) args.flags[BOOL_FLAGS[token]] = true;
    else if (VALUE_FLAGS[token]) { args.flags[VALUE_FLAGS[token]] = argv[i + 1]; i += 1; }
    else args._.push(token);
  }
  return args;
}

function handleRevokedResponse(result) {
  if (!isRevokedResponse(result)) return false;
  const dormant = markAgentDormant();
  console.log(dormant.notice);
  if (dormant.schedule && dormant.schedule.manual && dormant.schedule.instructions) {
    console.log(dormant.schedule.instructions);
  } else if (dormant.schedule && dormant.schedule.ok === false && Array.isArray(dormant.schedule.errors)) {
    console.log("Health schedule removal warning:");
    for (const item of dormant.schedule.errors) console.log(`  - ${item.task}: ${item.error}`);
  }
  return true;
}

// Combine per-file pattern groups into one set of { type, count, risk } for the scan.
function mergePatterns(findings) {
  const merged = new Map();
  for (const finding of findings) {
    for (const pattern of finding.patterns) {
      const current = merged.get(pattern.type);
      if (current) current.count += pattern.count || 1;
      else merged.set(pattern.type, { type: pattern.type, count: pattern.count || 1, risk: pattern.risk });
    }
  }
  return [...merged.values()];
}

function buildEvent(config, { patterns, decision, scannedFiles, findingFiles, contentLength, orgPolicyResult, skippedByGainignore = 0 }) {
  return {
    surface: "agent",
    event_type: "agent_scan",
    domain: "agent.local",
    tool_name: "G.A.I.N Agent",
    category: "developer_workflow",
    action: decision.action,
    enforcement_action: decision.action,
    severity: decision.severity,
    content_length: contentLength,
    patterns_detected: patterns,
    policy_triggered: decision.policy_triggered,
    detection_reason: `${decision.reason} (${findingFiles}/${scannedFiles} files with findings, ${skippedByGainignore} path${skippedByGainignore === 1 ? "" : "s"} skipped by .gainignore)`,
    policy_bundle_version: orgPolicyResult?.policy_bundle?.bundle_version || null,
    policy_source: orgPolicyResult?.source || "local",
    device_id: config.device_id,
    created_at: new Date().toISOString()
  };
}

async function reportEvent(config, event, flags) {
  if (flags.noReport) return { reported: false, reason: "no-report flag" };
  localQueue.enqueue(event);
  if (!isConfigured(config)) {
    await sendSiemEvent(config, event);
    return { reported: false, reason: "not connected (queued locally)" };
  }
  const result = await sendEvent(config, event);
  if (result.ok) {
    // Drop the just-sent event from the queue (best effort).
    const remaining = localQueue.readAll();
    remaining.pop();
    localQueue.rewrite(remaining);
    await sendSiemEvent(config, event);
    return { reported: true };
  }
  await sendSiemEvent(config, event);
  return { reported: false, reason: result.error || result.reason || "send failed (kept in queue)" };
}

async function cmdScan(args) {
  const target = args._[0] || ".";
  const config = loadConfig();
  const enforcementMode = args.flags.mode || config.enforcement_mode;
  const orgPolicyResult = await getOrgPolicyBundle(config);
  const orgPolicyBundle = orgPolicyResult.ok ? orgPolicyResult.policy_bundle : null;

  const projectResult = findProjectPolicy(target);
  if (projectResult && projectResult.error) {
    console.error(`Project policy error: ${projectResult.error}`);
    process.exitCode = 1;
    return;
  }
  const projectPolicy = projectResult ? projectResult.policy : null;

  let scan;
  const repoRoot = findRepoRoot(target);
  const gainignoreResult = args.flags.noGainignore ? null : loadGainignore(repoRoot);
  try {
    scan = scanFileMetadata(target, {
      disabledPaths: config.disabled_paths,
      ignorePatterns: gainignoreResult ? gainignoreResult.patterns : [],
      ignoreRoot: repoRoot
    });
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
    return;
  }

  const baselineResult = args.flags.noBaseline ? null : loadBaseline(scan.root);
  const baselineApplied = baselineResult ? applyBaseline(scan.findings, baselineResult.baseline) : { findings: scan.findings, suppressed: 0 };
  const effectiveFindings = baselineApplied.findings;
  const patterns = mergePatterns(effectiveFindings);
  const contentLength = effectiveFindings.reduce((sum, f) => sum + (f.contentLength || 0), 0);
  const decision = decide({
    patterns,
    projectPolicy,
    orgPolicyBundle,
    enforcementMode,
    context: { domain: "agent.local", toolName: "G.A.I.N Agent", category: "developer_workflow" }
  });

  const summary = {
    target: path.resolve(target),
    scannedFiles: scan.scannedFiles,
    findingFiles: effectiveFindings.length,
    findingDetails: effectiveFindings,
    baselineSuppressed: baselineApplied.suppressed,
    skippedByGainignore: scan.skippedByGainignore || 0,
    skippedDocuments: scan.skippedDocuments || [],
    gainignorePath: gainignoreResult ? gainignoreResult.path : null,
    gainignoreDisabled: Boolean(args.flags.noGainignore),
    patterns,
    decision,
    enforcementMode,
    orgPolicy: orgPolicyResult.ok ? {
      source: orgPolicyResult.source,
      bundle_version: orgPolicyBundle?.bundle_version || null,
      policy_count: Array.isArray(orgPolicyBundle?.policies) ? orgPolicyBundle.policies.length : 0,
      org_name: orgPolicyBundle?.org?.name || null
    } : null,
    projectPolicy: projectPolicy || null
  };

  if (args.flags.json) {
    console.log(JSON.stringify(summary, null, 2));
  } else {
    printScanSummary(summary, scan);
  }

  // Report when there is something to say (findings, or a project AI ban).
  const shouldReport = patterns.length > 0 || (projectPolicy && projectPolicy.ai_allowed === false);
  if (shouldReport) {
    const event = buildEvent(config, {
      patterns,
      decision,
      scannedFiles: scan.scannedFiles,
      findingFiles: effectiveFindings.length,
      contentLength,
      orgPolicyResult,
      skippedByGainignore: scan.skippedByGainignore || 0
    });
    const report = await reportEvent(config, event, args.flags);
    if (!args.flags.json) {
      console.log(report.reported ? "Reported to dashboard." : `Not reported: ${report.reason}.`);
    }
  }

  // Exit non-zero on block so the agent can gate git hooks / CI.
  if (decision.action === "block") process.exitCode = 2;
}

function printScanSummary(summary, scan) {
  console.log(`G.A.I.N Agent scan: ${summary.target}`);
  console.log(`  files scanned:  ${summary.scannedFiles}`);
  console.log(`  files w/ findings: ${summary.findingFiles}`);
  if (summary.gainignoreDisabled) {
    console.log("  .gainignore:    disabled");
  } else if (summary.gainignorePath || summary.skippedByGainignore) {
    console.log(`  .gainignore:    skipped ${summary.skippedByGainignore} path${summary.skippedByGainignore === 1 ? "" : "s"}`);
  }
  if (summary.baselineSuppressed) console.log(`  baseline:       suppressed ${summary.baselineSuppressed} known finding${summary.baselineSuppressed === 1 ? "" : "s"}`);
  if (Array.isArray(summary.skippedDocuments) && summary.skippedDocuments.length) {
    console.log(`  documents:      skipped ${summary.skippedDocuments.length} PDF/DOCX file${summary.skippedDocuments.length === 1 ? "" : "s"} that could not be text-extracted`);
    for (const item of summary.skippedDocuments.slice(0, 5)) {
      console.log(`    - ${item.file}: ${item.reason}`);
    }
  }
  console.log(`  enforcement mode:  ${summary.enforcementMode}`);
  if (summary.orgPolicy) {
    console.log(`  org policy:        ${summary.orgPolicy.source} (${summary.orgPolicy.policy_count} policies` +
      (summary.orgPolicy.org_name ? `, ${summary.orgPolicy.org_name}` : "") + ")");
  }
  if (summary.projectPolicy) {
    console.log(`  project policy:    ai_allowed=${summary.projectPolicy.ai_allowed}` +
      (summary.projectPolicy.reason ? ` (${summary.projectPolicy.reason})` : ""));
  }
  if (!summary.patterns.length && !(summary.projectPolicy && summary.projectPolicy.ai_allowed === false)) {
    console.log("  result: clean. No sensitive patterns detected.");
    return;
  }
  if (summary.patterns.length) {
    console.log("  detected:");
    for (const p of summary.patterns) console.log(`    - ${patternLabel(p.type)} x${p.count} [${p.risk}]`);
  }
  for (const finding of (summary.findingDetails || []).slice(0, 20)) {
    console.log(`    - ${finding.file}: ${finding.patterns.map((p) => patternLabel(p.type)).join(", ")}`);
  }
  console.log(`  result: ${actionLine(summary.decision, summary.patterns, { context: "continuing" })}`);
}

const ENFORCEMENT_MODES = ["visibility_only", "warn", "redact", "block"];

// `setup`: write connection/config to ~/.gain/config.json without hand-editing
// JSON. Non-interactive (flag-driven) so it's safe in CI/managed rollouts.
// Org/Supabase keys are connection config; never printed back, only "set"/"not set".
async function cmdSetup(args) {
  const f = args.flags;
  if (!f.orgKey && !f.supabaseKey && !f.supabaseUrl && !f.mode && !f.label && !f.department && !f.deploymentMode && !f.siemWebhookUrl && !f.siemToken && !f.accessMode && !f.approvedTools && !f.blockedTools && !f.desktopGuard && !f.desktopGuardApps && !f.autoUpdate && !f.disableAutoUpdate && !f.telemetryEnabled && !f.noTelemetry) {
    console.error("Nothing to set. Usage:");
    console.error("  gain-agent setup --org-key <KEY> [--supabase-url <URL>] [--supabase-key <KEY>] [--mode visibility_only|warn|redact|block] [--deployment-mode hosted|self_hosted] [--no-telemetry] [--label \"Name\"] [--department Engineering] [--access-mode monitor|allow_only_approved] [--approved-tools claude.ai,api.openai.com] [--blocked-tools api.anthropic.com] [--desktop-guard on|off] [--siem-webhook-url <URL>] [--auto-update]");
    process.exitCode = 1;
    return;
  }
  if (f.mode && !ENFORCEMENT_MODES.includes(f.mode)) {
    console.error(`Invalid mode "${f.mode}". Choose one of: ${ENFORCEMENT_MODES.join(", ")}`);
    process.exitCode = 1;
    return;
  }
  if (f.deploymentMode && !DEPLOYMENT_MODES.has(f.deploymentMode)) {
    console.error(`Invalid deployment mode "${f.deploymentMode}". Choose one of: ${Array.from(DEPLOYMENT_MODES).join(", ")}`);
    process.exitCode = 1;
    return;
  }
  if (f.accessMode && !["monitor", "allow_all", "allow_only_approved"].includes(String(f.accessMode).toLowerCase().replace(/-/g, "_"))) {
    console.error("Invalid access mode. Choose one of: monitor, allow_all, allow_only_approved");
    process.exitCode = 1;
    return;
  }
  if (f.desktopGuard && !["on", "off"].includes(String(f.desktopGuard).toLowerCase())) {
    console.error("Invalid desktop guard value. Choose one of: on, off");
    process.exitCode = 1;
    return;
  }

  const next = { ...readConfigFile() };
  if (f.orgKey) next.org_api_key = f.orgKey;
  if (f.supabaseUrl) next.supabase_url = f.supabaseUrl;
  if (f.supabaseKey) next.supabase_key = f.supabaseKey;
  if (f.mode) next.enforcement_mode = f.mode;
  if (f.deploymentMode) next.deployment_mode = f.deploymentMode;
  if (f.telemetryEnabled) next.telemetry_enabled = true;
  if (f.noTelemetry) next.telemetry_enabled = false;
  if (f.label) next.device_label = f.label;
  if (f.department) next.department = f.department;
  if (f.siemWebhookUrl) next.siem_webhook_url = f.siemWebhookUrl;
  if (f.siemToken) next.siem_bearer_token = f.siemToken;
  if (f.accessMode) next.access_mode = String(f.accessMode).toLowerCase().replace(/-/g, "_");
  if (f.approvedTools) next.approved_tools = f.approvedTools.split(",").map((item) => item.trim()).filter(Boolean);
  if (f.blockedTools) next.blocked_tools = f.blockedTools.split(",").map((item) => item.trim()).filter(Boolean);
  if (f.desktopGuard) next.desktop_guard_enabled = String(f.desktopGuard).toLowerCase() === "on";
  if (f.desktopGuardApps) next.desktop_guard_apps = f.desktopGuardApps.split(",").map((item) => item.trim()).filter(Boolean);
  if (f.autoUpdate) next.auto_update = true;
  if (f.disableAutoUpdate) next.auto_update = false;
  next.active = true;
  delete next.inactive_reason;
  delete next.inactive_at;
  writeConfigFile(next);

  console.log(`Saved configuration to ${configPath()}`);
  console.log(`  org key:        ${next.org_api_key ? "set" : "not set"}`);
  console.log(`  supabase url:   ${next.supabase_url || DEFAULT_SUPABASE_URL}`);
  console.log(`  supabase key:   ${next.supabase_key ? "set" : "default"}`);
  console.log(`  enforcement:    ${next.enforcement_mode || "visibility_only"}`);
  console.log(`  deployment:     ${next.deployment_mode || "hosted"}`);
  console.log(`  telemetry:      ${next.telemetry_enabled === false ? "disabled" : "enabled"}`);
  if (next.department) console.log(`  department:     ${next.department}`);
  if (next.access_mode) console.log(`  access mode:    ${next.access_mode}`);
  if (Array.isArray(next.approved_tools) && next.approved_tools.length) console.log(`  approved tools: ${next.approved_tools.length}`);
  if (Array.isArray(next.blocked_tools) && next.blocked_tools.length) console.log(`  blocked tools:  ${next.blocked_tools.length}`);
  console.log(`  desktop guard:  ${next.desktop_guard_enabled === false ? "disabled" : "enabled"}`);
  if (Array.isArray(next.desktop_guard_apps) && next.desktop_guard_apps.length) console.log(`  desktop apps:   ${next.desktop_guard_apps.length}`);
  if (next.siem_webhook_url) console.log("  siem webhook:   set");
  console.log(`  auto-update:    ${next.auto_update ? "enabled" : "disabled"}`);

  if (f.desktopGuard && process.env.GAIN_SKIP_SCHEDULE !== "1") {
    printScheduleResult(
      String(f.desktopGuard).toLowerCase() === "on" ? installDesktopGuardSchedule() : uninstallDesktopGuardSchedule(),
      String(f.desktopGuard).toLowerCase() === "on" ? "install" : "uninstall"
    );
  }

  const config = loadConfig();
  if (isConfigured(config) && process.env.GAIN_SKIP_ENROLL !== "1") {
    const enrolled = await enrollDevice(config);
    if (enrolled.ok) {
      if (enrolled.policy_bundle) writePolicyCache(enrolled.policy_bundle);
      const policyCount = Array.isArray(enrolled.policy_bundle?.policies) ? enrolled.policy_bundle.policies.length : 0;
      const orgName = enrolled.org?.name || enrolled.policy_bundle?.org?.name || "organization recognized";
      console.log(`Connected to ${orgName}; enrolled this workstation and synced ${policyCount} policies.`);
      return;
    }
    console.log(`Saved, but enrollment failed: ${enrolled.error || enrolled.reason || "unknown error"}`);
    process.exitCode = 1;
    return;
  }
  console.log("Run 'gain-agent doctor' to verify the connection.");
}

async function cmdInit(args) {
  if (!args.flags.orgKey) {
    console.error("Usage: gain-agent init --org-key <KEY> [--label <name>] [--department <name>] [--no-service]");
    process.exitCode = 1;
    return;
  }

  console.log("G.A.I.N Agent init");
  console.log("1. Connecting this device in monitor mode...");
  const setupFlags = {
    orgKey: args.flags.orgKey,
    label: args.flags.label,
    department: args.flags.department,
    mode: "visibility_only"
  };
  if (args.flags.supabaseUrl) setupFlags.supabaseUrl = args.flags.supabaseUrl;
  if (args.flags.supabaseKey) setupFlags.supabaseKey = args.flags.supabaseKey;
  if (args.flags.desktopGuard) setupFlags.desktopGuard = args.flags.desktopGuard;
  process.exitCode = 0;
  await cmdSetup({ _: [], flags: setupFlags });
  if (process.exitCode) return;

  let installWarning = false;
  console.log("");
  console.log("2. Installing the hidden local proxy service...");
  if (args.flags.noService || process.env.GAIN_AGENT_NO_SERVICE === "1") {
    console.log("Skipped proxy service install because --no-service or GAIN_AGENT_NO_SERVICE=1 was set.");
  } else {
    try {
      const service = installProxyService({ cliPath: currentCliPath() });
      printProxyServiceResult(service, "install");
    } catch (error) {
      installWarning = true;
      console.log(`Proxy service install warning: ${error.message}`);
      console.log("The agent is still connected. Run `gain-agent proxy --service install` later to enable seamless local proxy routing.");
    }
  }

  console.log("");
  console.log("3. Installing the local git hook...");
  const hook = require("../hooks/gitHook").installRepoGitHook(process.cwd(), { cliPath: currentCliPath() });
  if (hook.ok) {
    console.log(`Installed G.A.I.N pre-commit hook at ${hook.hookPath}`);
  } else {
    console.log(`Git hook not installed: ${hook.message || hook.reason || "unknown reason"}`);
  }

  console.log("");
  console.log("4. Auto-wiring detected coding tools...");
  const { applyAutoWiring, printAutoWiringResult } = require("../integrations/autoWire");
  const wiring = applyAutoWiring({
    agentPath: currentCliPath(),
    noProxyEnv: args.flags.noService || process.env.GAIN_AGENT_NO_SERVICE === "1"
  });
  printAutoWiringResult(wiring);
  if (!wiring.ok) installWarning = true;

  console.log("");
  console.log("5. Checking the final install...");
  process.exitCode = 0;
  await cmdDoctor();
  if (process.exitCode) return;

  console.log("");
  console.log("You're protected. Monitor mode is on; nothing is blocked except private keys, crypto wallet private keys, and seed phrases. The local proxy runs hidden and redacts through supported Anthropic and OpenAI-compatible tools when those clients use the configured base URL.");
  if (installWarning) process.exitCode = 1;
}

// `license`: install a license (string or @file) into config, or show status.
// Licensing is additive: an unlicensed agent still runs; a license proves
// entitlement (seats/expiry/features) and is verified offline. Self-hosted
// deployments can gate enforcement on `verifyLicense().valid`.
function cmdLicense(args) {
  const arg = args._[0];
  if (arg) {
    let value = arg;
    if (arg.startsWith("@") || fs.existsSync(arg)) {
      value = fs.readFileSync(arg.replace(/^@/, ""), "utf8").trim();
    }
    const result = verifyLicense(value);
    if (!result.valid && result.reason === "no public key configured") {
      console.error("Saved, but cannot verify yet: no public key configured (set GAIN_LICENSE_PUBLIC_KEY or src/license/public-key.pem).");
    } else if (!result.valid) {
      console.error(`Refusing to install. License is invalid: ${result.reason}`);
      process.exitCode = 1;
      return;
    }
    writeConfigFile({ ...readConfigFile(), license: value });
    console.log(`License saved to ${configPath()}.`);
  }

  const stored = readConfigFile().license;
  if (!stored) {
    console.log("No license installed (agent runs unlicensed). Install with: gain-agent license <string|@file>");
    return;
  }
  const result = verifyLicense(stored);
  const p = result.payload || {};
  console.log("G.A.I.N Agent license");
  console.log(`  status:   ${result.valid ? "VALID" : `INVALID (${result.reason})`}`);
  console.log(`  org id:   ${p.org_id || "not set"}`);
  console.log(`  customer: ${p.customer || "not set"}`);
  console.log(`  plan:     ${p.plan || "not set"}`);
  console.log(`  seats:    ${p.max_seats ?? p.seats ?? "not set"}`);
  console.log(`  features: ${(p.features || []).join(", ") || "(base)"}`);
  console.log(`  lifetime: ${p.lifetime ? "yes" : "no"}`);
  console.log(`  expires:  ${p.exp ? new Date(Number(p.exp)).toISOString().slice(0, 10) : "never"}`);
  console.log(`  updates:  ${p.allowed_updates_until ? new Date(Number(p.allowed_updates_until)).toISOString().slice(0, 10) : "not set"}`);
  if (!result.valid) process.exitCode = 1;
}

function cmdBaseline(args) {
  const action = args._[0] || "show";
  const target = args._[1] || ".";
  const root = path.resolve(target);

  if (action === "create" || action === "update") {
    let scan;
    try {
      scan = scanFileMetadata(root, { disabledPaths: loadConfig().disabled_paths });
    } catch (error) {
      console.error(error.message);
      process.exitCode = 1;
      return;
    }
    const result = writeBaseline(scan.root, scan);
    console.log(`Wrote baseline to ${result.path}`);
    console.log(`  entries: ${result.baseline.entries.length}`);
    console.log("Future scans suppress matching file/type/count findings and report only new or increased findings.");
    return;
  }

  if (action === "clear") {
    const filePath = baselinePath(root);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    console.log(`Removed baseline at ${filePath}`);
    return;
  }

  if (action === "show") {
    const result = loadBaseline(root);
    if (!result) {
      console.log(`No baseline found at ${baselinePath(root)}`);
      return;
    }
    console.log(`G.A.I.N baseline: ${result.path}`);
    console.log(`  created: ${result.baseline.created_at || "unknown"}`);
    console.log(`  entries: ${result.baseline.entries.length}`);
    const byType = new Map();
    for (const entry of result.baseline.entries) byType.set(entry.type, (byType.get(entry.type) || 0) + (entry.count || 1));
    for (const [type, count] of byType.entries()) console.log(`    - ${type}: ${count}`);
    return;
  }

  console.error("Usage: gain-agent baseline create [path] | show [path] | clear [path]");
  process.exitCode = 1;
}

async function cmdSiemTest() {
  const config = loadConfig();
  const event = {
    surface: "agent",
    event_type: "siem_test",
    domain: "agent.local",
    tool_name: "G.A.I.N Agent",
    category: "developer_workflow",
    action: "log_only",
    severity: "info",
    content_length: 0,
    patterns_detected: [],
    policy_triggered: null,
    created_at: new Date().toISOString()
  };
  const result = await sendSiemEvent(config, event);
  if (result.ok) {
    console.log("SIEM webhook test delivered.");
    return;
  }
  console.log(`SIEM webhook test failed: ${result.reason || result.error || "unknown error"}`);
  process.exitCode = 1;
}

async function cmdUpdate(args = { flags: {} }) {
  const config = loadConfig();
  let update;
  try {
    update = await checkForUpdate({ config });
  } catch (error) {
    console.log(`Update check failed: ${error.message}`);
    if (args.flags.scheduled) return;
    process.exitCode = 1;
    return;
  }

  if (update.skipped) {
    if (!args.flags.scheduled) {
      console.log("Update check skipped: self-hosted mode with telemetry disabled does not contact CyberWardion update endpoints.");
    }
    return;
  }

  if (args.flags.check) {
    console.log(update.updateAvailable
      ? `Update available: ${update.currentVersion} -> ${update.latestVersion}`
      : `G.A.I.N Agent is current: ${update.currentVersion}`);
    return;
  }

  if (!update.updateAvailable && !args.flags.force) {
    if (!args.flags.scheduled) console.log(`G.A.I.N Agent is already current: ${update.currentVersion}`);
    return;
  }

  if (!args.flags.scheduled) console.log(`Updating G.A.I.N Agent ${update.currentVersion} -> ${update.latestVersion}...`);
  const installed = await runHostedInstaller(config, { update, version: update.latestVersion, stdio: args.flags.scheduled ? "ignore" : "inherit" });
  if (installed && installed.skipped && !args.flags.scheduled) {
    console.log("Update skipped: self-hosted mode with telemetry disabled does not contact CyberWardion update endpoints.");
  } else if (installed && installed.message && !args.flags.scheduled) {
    console.log(installed.message);
  }
}

async function cmdUpdateReport(args = { flags: {} }) {
  const config = loadConfig();
  const result = await reportWindowsUpdateFailure(config, {
    oldVersion: args.flags.oldVersion || AGENT_VERSION,
    newVersion: args.flags.newVersion || "",
    reason: args.flags.reason || "windows_helper_failed"
  });
  if (!result.ok && !result.skipped) process.exitCode = 1;
}

async function integrationStatusForHeartbeat(config = loadConfig()) {
  try {
    const { getIntegrationStatus } = require("../integrations/autoWire");
    return await getIntegrationStatus({ timeoutMs: 200, config, agentActive: config.active !== false });
  } catch (_error) {
    return null;
  }
}

async function cmdStatus(args = { flags: {} }) {
  const config = loadConfig();
  const queued = localQueue.count();
  let proxy = null;
  try { proxy = await getProxyServiceStatus({ timeoutMs: 300 }); } catch (_error) {}
  console.log("G.A.I.N Agent status");
  console.log(`  active:           ${config.active === false ? `no (${config.inactive_reason || "inactive"})` : "yes"}`);
  console.log(`  protection:       ${config.active === false ? "Inactive until re-enrolled by setup." : (config.enforcement_mode === "visibility_only" ? "Monitor mode. Metadata only; private keys, crypto wallet private keys, and seed phrases are blocked." : config.enforcement_mode)}`);
  console.log(`  connected:        ${isConfigured(config) ? "yes" : "no. Events queue locally until setup is complete."}`);
  console.log(`  device:           ${config.device_label} (${config.device_id})`);
  console.log(`  department:       ${config.department || "not set"}`);
  console.log(`  version:          ${AGENT_VERSION}`);
  console.log(`  deployment:       ${config.deployment_mode}, telemetry ${config.telemetry_enabled ? "enabled" : "disabled"}`);
  console.log(`  dashboard:        ${config.supabase_url}`);
  console.log(`  org key:          ${config.org_api_key ? "set" : "not set"}`);
  console.log(`  access mode:      ${config.access_mode || "monitor"}`);
  console.log(`  approved tools:   ${Array.isArray(config.approved_tools) ? config.approved_tools.length : String(config.approved_tools || "").split(",").filter(Boolean).length}`);
  console.log(`  blocked tools:    ${Array.isArray(config.blocked_tools) ? config.blocked_tools.length : String(config.blocked_tools || "").split(",").filter(Boolean).length}`);
  console.log(`  desktop guard:    ${config.desktop_guard_enabled === false ? "off" : "on"} (${Array.isArray(config.desktop_guard_apps) && config.desktop_guard_apps.length ? `${config.desktop_guard_apps.length} configured app${config.desktop_guard_apps.length === 1 ? "" : "s"}` : "default Claude Desktop and ChatGPT Desktop"})`);
  if (proxy) {
    console.log(`  proxy service:    ${proxy.enabled ? (proxy.running ? "on and reachable" : "on but not reachable") : "off"} (${proxy.url})`);
    console.log(`  proxy fail mode:  ${proxy.failPolicy === "fail_open" ? "fail open" : "fail closed"}`);
    console.log(`  proxy last use:   ${proxy.lastRequestAt || "never"}`);
  }
  try {
    const { getIntegrationStatus } = require("../integrations/autoWire");
    const integrations = await getIntegrationStatus({ tools: args.flags.tools || "", config, agentActive: config.active !== false });
    console.log("  coding tools:");
    if (config.active === false) {
      console.log("    G.A.I.N is disabled locally; configured hooks/proxy/MCP are ignored until setup re-enrolls this device.");
    }
    for (const tool of integrations.tools) {
      const detected = tool.detected ? `yes (${tool.detected_by || "detected"})` : "no";
      const mechanisms = tool.mechanisms
        .map((m) => `${m.name}:${m.active ? "active" : (m.configured ? "configured" : "off")}`)
        .join(", ");
      console.log(`    ${tool.name}: detected ${detected}; ${mechanisms}`);
    }
  } catch (error) {
    console.log(`  coding tools:     status unavailable (${error.message})`);
  }
  console.log(`  SIEM webhook:     ${config.siem_webhook_url ? "yes" : "no"}`);
  console.log(`  auto-update:      ${config.auto_update ? "yes" : "no"}`);
  const cached = fs.existsSync(cachePath()) ? "yes" : "no";
  console.log(`  policy cache:     ${cached}`);
  console.log(`  queued events:    ${queued}`);
  console.log(`  config file:      ${configPath()}`);
}

async function cmdDoctor() {
  const checks = [];
  const nodeOk = Number(process.versions.node.split(".")[0]) >= 18;
  checks.push([nodeOk, `Node ${process.versions.node} (>=18 required)`]);

  let detectorOk = false;
  try { getDetector(); detectorOk = true; } catch (error) { checks.push([false, `Detection patterns: ${error.message}`]); }
  if (detectorOk) checks.push([true, `Detection patterns loaded from ${PATTERNS_PATH}`]);

  let redactorOk = false;
  try { getRedactor(); redactorOk = true; } catch (error) { checks.push([false, `Redaction engine: ${error.message}`]); }
  if (redactorOk) checks.push([true, `Redaction engine loaded from ${REDACT_PATH}`]);
  checks.push(checkPdfTextDependency());

  const license = readConfigFile().license;
  if (license) {
    const result = verifyLicense(license);
    const p = result.payload || {};
    const seatCheck = result.valid ? enforceLicenseSeatCount(result, 1) : { ok: false, reason: result.reason };
    checks.push([result.valid && seatCheck.ok, `License ${result.valid && seatCheck.ok ? `valid: ${p.customer || "?"}, plan: ${p.plan || "?"}, seats: ${p.max_seats ?? p.seats}, expires: ${p.exp ? new Date(Number(p.exp)).toISOString().slice(0, 10) : "never"}` : `INVALID (${seatCheck.reason || result.reason})`}`]);
  } else {
    checks.push([true, "License: none installed (running unlicensed)"]);
  }

  const config = loadConfig();
  checks.push([config.active !== false, config.active === false ? `Agent disabled locally: ${config.inactive_reason || "inactive"}. Re-run setup to re-enroll before relying on protection.` : "Agent active"]);
  checks.push([DEPLOYMENT_MODES.has(config.deployment_mode), `Deployment mode: ${config.deployment_mode}`]);
  checks.push([true, `Telemetry: ${config.telemetry_enabled ? "enabled" : "disabled"}`]);
  if (config.deployment_mode === "self_hosted" && config.telemetry_enabled === false && String(config.supabase_url || "").replace(/\/+$/, "") === DEFAULT_SUPABASE_URL) {
    checks.push([true, "Hosted CyberWardion backend calls disabled for self-hosted mode"]);
  }
  checks.push([Boolean(config.org_api_key), `Org key ${config.org_api_key ? "configured" : "MISSING (run setup or push via managed config)"}`]);
  checks.push([Boolean(config.supabase_key), `Supabase key ${config.supabase_key ? "configured" : "MISSING"}`]);
  if (isConfigured(config)) {
    const connection = await checkConnection(config);
    if (connection.ok) {
      const orgName = connection.org && connection.org.name ? connection.org.name : "organization recognized";
      const license = connection.license && connection.license.status ? `, license: ${connection.license.status}` : "";
      checks.push([true, `Backend connection verified: ${orgName}${license}`]);
      const policyResult = await getOrgPolicyBundle(config);
      if (policyResult.ok) {
        const count = Array.isArray(policyResult.policy_bundle?.policies) ? policyResult.policy_bundle.policies.length : 0;
        checks.push([true, `Organization policies synced: ${count} policies (${policyResult.source}), cache: ${cachePath()}`]);
      } else {
        checks.push([false, `Organization policies not available: ${policyResult.reason || "unknown error"}`]);
      }
      const heartbeat = await sendHeartbeat(config, {
        policy_count: Array.isArray(policyResult.policy_bundle?.policies) ? policyResult.policy_bundle.policies.length : 0,
        integration_status: await integrationStatusForHeartbeat(config)
      });
      if (isRevokedResponse(heartbeat)) {
        handleRevokedResponse(heartbeat);
        checks.push([false, "Deployment heartbeat says this device was removed by your G.A.I.N admin"]);
      } else {
        checks.push([heartbeat.ok, heartbeat.ok ? "Deployment heartbeat accepted by dashboard" : `Deployment heartbeat failed: ${heartbeat.error || heartbeat.reason || "unknown error"}`]);
      }
    } else {
      checks.push([false, `Backend connection failed: ${connection.error || connection.reason || "unknown error"}`]);
    }
  } else {
    checks.push([false, "Backend connection not checked. Run setup with an Organization Key"]);
  }
  checks.push([true, `Queued events: ${localQueue.count()}`]);

  try {
    const proxy = await getProxyServiceStatus({ timeoutMs: 300 });
    const routedEnvVars = ENV_VARS.filter((name) => parseLoopbackProxyUrl(proxy.env?.[name]));
    const correctlyRoutedEnvVars = routedEnvVars.filter((name) => {
      const parsed = parseLoopbackProxyUrl(proxy.env?.[name]);
      return parsed && parsed.port === proxy.port;
    });
    if (config.proxy_service_enabled === true || routedEnvVars.length > 0) {
      checks.push([
        proxy.serviceEnabled,
        proxy.serviceEnabled
          ? `Proxy autostart configured: ${proxy.serviceVariant || "yes"}`
          : "Proxy environment is configured, but no proxy autostart was found. Run `gain-agent proxy --service install`."
      ]);
      checks.push([
        proxy.running,
        proxy.running
          ? `Proxy reachable at ${proxy.url}`
          : `Proxy is configured but not reachable at ${proxy.url}. Run \`gain-agent proxy --service install\` or \`gain-agent proxy --service status\`.`
      ]);
    }
    if (proxy.failPolicy === "fail_closed" && config.proxy_service_enabled === true) {
      checks.push([
        correctlyRoutedEnvVars.length > 0,
        correctlyRoutedEnvVars.length > 0
          ? `Proxy routing env visible in this shell: ${correctlyRoutedEnvVars.join(", ")}`
          : "Proxy fail-closed is enabled, but this shell does not see localhost routing env vars. Restart the terminal or rerun `gain-agent proxy --service install`."
      ]);
    }
    if (routedEnvVars.length > 0 && !proxy.running) {
      checks.push([
        false,
        `Proxy env routes ${routedEnvVars.join(", ")} through localhost, but the proxy is down. Supported clients will fail until the watchdog starts.`
      ]);
    }
  } catch (error) {
    checks.push([false, `Proxy service check failed: ${error.message}`]);
  }

  // Wiring drift guard: auto-update refreshes the binary but never re-runs
  // integrations --apply, so a tool wired under an older agent version can
  // end up with only SOME of the currently-required hook events configured
  // -- silently weaker protection with no prior visibility here. Only flags
  // partial configuration (some events present, some missing), not a tool
  // that was simply never wired at all.
  try {
    const { detectInstalledTools, configuredClaudeHookEvents, missingClaudeHookEvents } = require("../integrations/autoWire");
    const claudeTool = detectInstalledTools().find((tool) => tool.id === "claude-code" && tool.detected && tool.nativeHook);
    if (claudeTool) {
      const configured = configuredClaudeHookEvents(claudeTool);
      const missing = missingClaudeHookEvents(claudeTool);
      if (configured.length > 0 && missing.length > 0) {
        checks.push([false, `Claude Code hook partially configured -- missing: ${missing.join(", ")}. Run \`gain-agent integrations --apply\` to complete it.`]);
      }
    }
  } catch (_error) {
    // Best-effort: never let this diagnostic itself break doctor.
  }

  console.log("G.A.I.N Agent doctor");
  let failed = 0;
  for (const [ok, label, level] of checks) {
    if (!ok) failed += 1;
    const marker = level === "warn" ? "WARN" : (ok ? "OK  " : "!!  ");
    console.log(`  ${marker} ${label}`);
  }
  if (failed) process.exitCode = 1;
}

async function cmdSync() {
  const config = loadConfig();
  if (!isConfigured(config)) {
    console.log("Not connected. Run gain-agent setup --org-key <KEY> first.");
    process.exitCode = 1;
    return;
  }
  const result = await getOrgPolicyBundle(config);
  if (!result.ok) {
    console.log(`Policy sync failed: ${result.reason || result.error || "unknown error"}`);
    process.exitCode = 1;
    return;
  }
  const policyCount = Array.isArray(result.policy_bundle?.policies) ? result.policy_bundle.policies.length : 0;
  const toolCount = Array.isArray(result.policy_bundle?.ai_tools) ? result.policy_bundle.ai_tools.length : 0;
  const heartbeat = await sendHeartbeat(config, { policy_count: policyCount, tool_count: toolCount, integration_status: await integrationStatusForHeartbeat() });
  console.log(`Synced ${policyCount} policies and ${toolCount} AI tools from ${result.source}.`);
  if (handleRevokedResponse(heartbeat)) return;
  console.log(heartbeat.ok ? "Dashboard heartbeat updated." : `Heartbeat not updated: ${heartbeat.error || heartbeat.reason || "unknown error"}.`);
  if (!heartbeat.ok) process.exitCode = 1;
}

async function cmdHeartbeat({ lightweight = false } = {}) {
  const config = loadConfig();
  if (!isConfigured(config)) {
    console.log("Not connected. Run gain-agent setup --org-key <KEY> first.");
    process.exitCode = 1;
    return;
  }
  const result = lightweight ? await sendPresence(config) : await sendHeartbeat(config, { integration_status: await integrationStatusForHeartbeat() });
  if (handleRevokedResponse(result)) return;
  if (result.ok) {
    console.log(lightweight ? "Presence ping accepted by dashboard." : "Heartbeat accepted by dashboard.");
    return;
  }
  console.log(`${lightweight ? "Presence" : "Heartbeat"} failed: ${result.error || result.reason || "unknown error"}`);
  process.exitCode = 1;
}

function printScheduleResult(result, action) {
  if (result.manual) {
    console.log(result.instructions);
    return;
  }
  if (result.ok) {
    if (action === "install") {
      console.log("Installed G.A.I.N Agent health schedule:");
      for (const task of result.tasks || []) console.log(`  - ${task.name}: ${task.description}`);
    } else {
      console.log("Removed G.A.I.N Agent health schedule:");
      for (const task of result.removed || []) console.log(`  - ${task}`);
    }
    return;
  }
  console.log("Health schedule update warning:");
  for (const item of result.errors || []) console.log(`  - ${item.task}: ${item.error}`);
  console.log("Agent install/update can continue. Re-run `gain-agent install-health-schedule` from an elevated shell or MDM if dashboard presence does not update.");
}

function printProxyServiceResult(result, action) {
  if (result.ok) {
    if (action === "install") {
      console.log(result.message || "Installed G.A.I.N local proxy service.");
      console.log(`  url:          http://${result.host}:${result.port}`);
      console.log(`  fail policy:  ${result.failPolicy === "fail_open" ? "fail open" : "fail closed"}`);
      if (result.env && Array.isArray(result.env.variables) && result.env.variables.length) {
        console.log(`  env vars:     ${result.env.variables.join(", ")}`);
      } else {
        console.log("  env vars:     not changed");
      }
      if (result.service?.task) console.log(`  task:         ${result.service.task}`);
      if (result.service?.startupLauncherPath) console.log(`  startup app:  ${result.service.startupLauncherPath}`);
      if (result.service?.plistPath) console.log(`  launch agent: ${result.service.plistPath}`);
      if (result.service?.unitPath) console.log(`  systemd unit: ${result.service.unitPath}`);
      if (result.service?.warning) console.log(`  fallback:     Task Scheduler was denied, using Startup folder autostart.`);
      console.log("Restart Claude Code, Copilot CLI, or your shell so user environment changes take effect.");
      return;
    }
    console.log("Removed G.A.I.N local proxy service and cleared proxy environment variables.");
    if (Array.isArray(result.service?.removed)) {
      for (const item of result.service.removed) console.log(`  - ${item}`);
    }
    if (Array.isArray(result.stopped) && result.stopped.length) {
      console.log(`Stopped ${result.stopped.length} running proxy process${result.stopped.length === 1 ? "" : "es"}.`);
    }
    return;
  }
  console.log(`Proxy service ${action} warning:`);
  for (const item of result.errors || []) console.log(`  - ${item}`);
}

function formatBytes(value) {
  const bytes = Number(value);
  if (!Number.isFinite(bytes) || bytes < 0) return "unknown";
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(mb >= 10 ? 1 : 2)} MB`;
}

function formatProcessMemory(label, snapshot) {
  if (!snapshot) return `  ${label} RAM:     not running/available`;
  const parts = [`pid ${snapshot.pid}`, `working set ${formatBytes(snapshot.workingSetBytes)}`];
  if (snapshot.privateBytes !== null && snapshot.privateBytes !== undefined) {
    parts.push(`private ${formatBytes(snapshot.privateBytes)}`);
  }
  return `  ${label} RAM:     ${parts.join(", ")}`;
}

function cmdInstallHealthSchedule() {
  printScheduleResult(installHealthSchedule(), "install");
}

function cmdUninstallHealthSchedule() {
  printScheduleResult(uninstallHealthSchedule(), "uninstall");
}

function cmdEnableAutoUpdate() {
  writeConfigFile({ ...readConfigFile(), auto_update: true });
  printScheduleResult(installAutoUpdateSchedule(), "install");
}

function cmdDisableAutoUpdate() {
  writeConfigFile({ ...readConfigFile(), auto_update: false });
  printScheduleResult(uninstallAutoUpdateSchedule(), "uninstall");
}

async function cmdProxy(args) {
  const serviceAction = args.flags.service ? String(args.flags.service).toLowerCase() : null;
  const saved = readConfigFile();
  const host = args.flags.host || process.env.GAIN_PROXY_HOST || saved.proxy_service_host || "127.0.0.1";
  const port = Number(args.flags.port || process.env.GAIN_PROXY_PORT || saved.proxy_service_port || 8787);
  if (!Number.isFinite(port) || port < 1 || port > 65535) {
    console.error("Invalid --port. Use a TCP port from 1 to 65535.");
    process.exitCode = 1;
    return;
  }

  if (serviceAction) {
    if (serviceAction === "install") {
      try {
        const result = installProxyService({
          cliPath: currentCliPath(),
          host,
          port,
          failPolicy: args.flags.proxyFailPolicy
        });
        printProxyServiceResult(result, "install");
      } catch (error) {
        console.error(`Proxy service install failed: ${error.message}`);
        process.exitCode = 1;
      }
      return;
    }
    if (serviceAction === "uninstall" || serviceAction === "remove") {
      try {
        const result = uninstallProxyService();
        printProxyServiceResult(result, "uninstall");
      } catch (error) {
        console.error(`Proxy service uninstall failed: ${error.message}`);
        process.exitCode = 1;
      }
      return;
    }
    if (serviceAction === "status") {
      const status = await getProxyServiceStatus();
      console.log("G.A.I.N local proxy service");
      console.log(`  enabled:       ${status.enabled ? "yes" : "no"}`);
      console.log(`  autostart:     ${status.serviceEnabled ? (status.serviceVariant || "yes") : "no"}`);
      console.log(`  running:       ${status.running ? "yes" : "no"}`);
      console.log(`  version:       ${status.version}`);
      console.log(`  url:           ${status.url}`);
      console.log(`  fail policy:   ${status.failPolicy === "fail_open" ? "fail open" : "fail closed"}`);
      console.log(`  last request:  ${status.lastRequestAt || "never"}`);
      if (status.processMemory) {
        console.log(formatProcessMemory("watchdog", status.processMemory.watchdog));
        console.log(formatProcessMemory("proxy", status.processMemory.proxy));
      }
      console.log(`  ANTHROPIC_BASE_URL:       ${status.env.ANTHROPIC_BASE_URL || "not set in this process"}`);
      console.log(`  OPENAI_BASE_URL:          ${status.env.OPENAI_BASE_URL || "not set in this process"}`);
      console.log(`  OPENAI_API_BASE:          ${status.env.OPENAI_API_BASE || "not set in this process"}`);
      console.log(`  COPILOT_PROVIDER_BASE_URL: ${status.env.COPILOT_PROVIDER_BASE_URL || "not set in this process"}`);
      return;
    }
    if (serviceAction === "run") {
      return runProxyServiceWatchdog({ host, port, cliPath: currentCliPath() });
    }
    console.error("Usage: gain-agent proxy --service install|uninstall|status|run [--proxy-fail-policy fail_closed|fail_open]");
    process.exitCode = 1;
    return;
  }

  return require("../proxy/server").startProxy({
    host,
    port,
    upstreams: {
      anthropic: args.flags.anthropicUpstream,
      openai: args.flags.openaiUpstream
    }
  });
}

async function cmdDesktopCheck(args) {
  const appName = args.flags.app || args._[0];
  const domain = args.flags.domain;
  const execPath = args.flags.exec;
  if (!appName && !domain) {
    console.error("Usage: gain-agent desktop-check --app <name> [--domain <domain>] [--exec <path>] [--json] [--no-report]");
    process.exitCode = 1;
    return;
  }
  const config = loadConfig();
  if (args.flags.accessMode) config.access_mode = String(args.flags.accessMode).toLowerCase().replace(/-/g, "_");
  if (args.flags.approvedTools) config.approved_tools = args.flags.approvedTools.split(",").map((item) => item.trim()).filter(Boolean);
  if (args.flags.blockedTools) config.blocked_tools = args.flags.blockedTools.split(",").map((item) => item.trim()).filter(Boolean);

  const result = await require("../desktop/restrictOnly").guardDesktopLaunch({
    appName,
    domain,
    execPath
  }, {
    config,
    noReport: Boolean(args.flags.noReport)
  });

  if (args.flags.json) {
    console.log(JSON.stringify(result, null, 2));
  } else if (result.allowed) {
    console.log(`Allowed desktop AI app: ${result.target.appName} (${result.target.domain})`);
    if (result.launched) console.log("Launch command started.");
  } else {
    console.error(`Blocked desktop AI app: ${result.target.appName} (${result.target.domain})`);
    console.error(result.reason);
  }

  if (!result.allowed) process.exitCode = 2;
}

function startDesktopGuardProcess() {
  const { spawn } = require("child_process");
  const child = process.pkg
    ? spawn(process.execPath, ["desktop-guard"], { detached: true, stdio: "ignore" })
    : spawn(process.execPath, [currentCliPath(), "desktop-guard"], { detached: true, stdio: "ignore" });
  child.unref();
  return child.pid;
}

async function cmdDesktopGuard(args) {
  const subcommand = args._[0];
  if (subcommand === "start") {
    writeConfigFile({ ...readConfigFile(), desktop_guard_enabled: true, active: true });
    console.log("Desktop guard enabled.");
    printScheduleResult(installDesktopGuardSchedule(), "install");
    const pid = startDesktopGuardProcess();
    console.log(`Desktop guard started in the background (pid ${pid}).`);
    return;
  }
  if (subcommand === "stop") {
    writeConfigFile({ ...readConfigFile(), desktop_guard_enabled: false });
    console.log("Desktop guard disabled. Any running guard exits on its next poll.");
    printScheduleResult(uninstallDesktopGuardSchedule(), "uninstall");
    return;
  }
  if (subcommand === "status") {
    const config = loadConfig();
    console.log(`Desktop guard is ${config.desktop_guard_enabled === false ? "off" : "on"}.`);
    console.log(Array.isArray(config.desktop_guard_apps) && config.desktop_guard_apps.length
      ? `Configured apps: ${config.desktop_guard_apps.join(", ")}`
      : "Configured apps: default Claude Desktop and ChatGPT Desktop");
    return;
  }
  if (subcommand && !["run"].includes(subcommand)) {
    console.error("Usage: gain-agent desktop-guard [start|stop|status] [--once] [--interval-ms 500] [--no-report]");
    process.exitCode = 1;
    return;
  }

  const intervalMs = Number(args.flags.intervalMs || 500);
  const result = await require("../desktop/desktopGuard").runDesktopGuard({
    intervalMs,
    once: Boolean(args.flags.once),
    noReport: Boolean(args.flags.noReport)
  });
  if (!result.ok && result.reason === "clipboard_unavailable") process.exitCode = 1;
}

async function cmdFlush() {
  const config = loadConfig();
  if (!isConfigured(config)) {
    console.log("Not connected. Set org_api_key and supabase_key first. Events stay queued.");
    process.exitCode = 1;
    return;
  }
  const events = localQueue.readAll();
  if (!events.length) { console.log("Queue is empty."); return; }

  const remaining = [];
  let sent = 0;
  for (const event of events) {
    const result = await sendEvent(config, event);
    if (result.ok) {
      await sendSiemEvent(config, event);
      sent += 1;
    }
    else remaining.push(event);
  }
  localQueue.rewrite(remaining);
  console.log(`Flushed ${sent}/${events.length}. ${remaining.length} still queued.`);
  if (remaining.length) process.exitCode = 1;
}

// Read all of stdin (returns "" when nothing is piped, e.g. an interactive TTY).
function readStdin() {
  return new Promise((resolve) => {
    if (process.stdin.isTTY) { resolve(""); return; }
    let data = "";
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", (chunk) => { data += chunk; });
    process.stdin.on("end", () => resolve(data));
  });
}

// `redact`: read text on stdin, redact sensitive data locally, write the safe
// text to stdout. Pure local transform: nothing is sent anywhere. Useful for
// pipelines, e.g.  cat prompt.txt | gain-agent redact  > safe.txt
async function cmdRedact(args) {
  const target = args._[0];
  let text;
  if (target) {
    try {
      text = fs.readFileSync(target, "utf8");
    } catch (error) {
      console.error(`Cannot read ${target}: ${error.message}`);
      process.exitCode = 1;
      return;
    }
  } else {
    text = await readStdin();
    if (!text) {
      console.error("No input. Pipe text in or pass a file:  cat file | gain-agent redact   OR   gain-agent redact <file>");
      process.exitCode = 1;
      return;
    }
  }

  const patterns = detectSensitivePatterns(text);
  const result = redactSensitiveText(text, patterns);

  // --write: redact the file in place (only writes if something changed).
  if (args.flags.write) {
    if (!target) {
      console.error("--write requires a file path:  gain-agent redact <file> --write");
      process.exitCode = 1;
      return;
    }
    if (result.changed) {
      fs.writeFileSync(target, result.text);
      process.stderr.write(`[G.A.I.N] ${actionLine({ action: "redact" }, patterns, { context: `writing ${target}` })}\n`);
    } else {
      process.stderr.write(`[G.A.I.N] No sensitive data found in ${target}; left unchanged.\n`);
    }
    return;
  }

  process.stdout.write(result.text);
  if (args.flags.json) {
    process.stderr.write(`\n${JSON.stringify({
      redactions: result.count,
      changed: result.changed,
      patterns: patterns.map((p) => ({ type: p.type, count: p.count, risk: p.risk }))
    }, null, 2)}\n`);
  } else if (result.changed) {
    process.stderr.write(`\n[G.A.I.N] ${actionLine({ action: "redact" }, patterns, { context: "printing the safe text" })}\n`);
  }
}

function printHelp() {
  console.log(`G.A.I.N Agent: metadata-only AI usage visibility for local/dev workflows

Usage:
  gain-agent --version
  gain-agent init --org-key <KEY> [--label <name>] [--department <name>] [--no-service]
  gain-agent setup --org-key <KEY> [--supabase-url <URL>] [--supabase-key <KEY>] [--mode <m>] [--deployment-mode hosted|self_hosted] [--no-telemetry] [--label <name>] [--access-mode monitor|allow_only_approved] [--approved-tools <csv>] [--blocked-tools <csv>] [--desktop-guard on|off] [--siem-webhook-url <URL>] [--auto-update]
  gain-agent scan <path> [--mode visibility_only|warn|redact|block] [--json] [--no-report] [--no-baseline] [--no-gainignore]
  gain-agent baseline create [path] | show [path] | clear [path]
  gain-agent redact [<file>] [--json] [--write]   redact stdin or a file; --write redacts the file in place (local only)
  gain-agent proxy [--host 127.0.0.1] [--port 8787] [--anthropic-upstream <URL>] [--openai-upstream <URL>]
  gain-agent proxy --service install|uninstall|status|run [--proxy-fail-policy fail_closed|fail_open]
  gain-agent desktop-check --app <name> [--domain <domain>] [--exec <path>] [--json] [--no-report]
  gain-agent desktop-guard [start|stop|status] [--once] [--interval-ms 500] [--no-report]
  gain-agent mcp                     run as an MCP server (redact_text / scan_text tools over stdio)
  gain-agent integrations [--json] [--apply] [--tools <csv>] [--no-proxy-env] [--no-git-hook] show setup, or auto-wire detected AI coding tools
  gain-agent license [<string|@file>]  install or show the offline license (seats / expiry / features)
  gain-agent siem-test                send a metadata-only test event to the configured SIEM webhook
  gain-agent update [--check|--force] update from CyberWardion's hosted package
  gain-agent status
  gain-agent doctor
  gain-agent sync                   refresh org policy cache and update dashboard heartbeat
  gain-agent heartbeat              update full deployment health
  gain-agent presence               update lightweight online presence
  gain-agent install-health-schedule   keep presence/heartbeat updated automatically
  gain-agent uninstall-health-schedule remove automatic presence/heartbeat schedule
  gain-agent enable-auto-update        install daily hidden update checks
  gain-agent disable-auto-update       remove daily update checks
  gain-agent flush
  gain-agent install-git-hook        install a pre-commit secret scanner in this repo
  gain-agent install-global-git-hook install a global pre-commit scanner for all repos
  gain-agent uninstall-global-git-hook remove G.A.I.N as the global git hook path
  gain-agent git-hook                run the pre-commit scan (used by the installed hook)
  gain-agent claude-hook             Claude Code hook (reads hook JSON on stdin)

Notes:
  - Scans for the same categories as the browser extension (api_key, password_mention,
    iban, national_id_context, email, source_code, confidential_markers, ...).
  - File contents are never stored or sent. Metadata only.
  - 'integrations --apply' backs up and edits detected coding-tool configs for hooks and MCP, persists proxy environment variables, and installs the global git fallback when possible.
  - 'init' installs the hidden local proxy service by default. Use --no-service or GAIN_AGENT_NO_SERVICE=1 to skip it.
  - 'proxy --service install' starts a hidden watchdog at login and sets ANTHROPIC_BASE_URL, OPENAI_BASE_URL, OPENAI_API_BASE, and COPILOT_PROVIDER_BASE_URL to http://127.0.0.1:8787.
  - Proxy fail policy defaults to fail_closed: if the proxy is down, routed clients fail instead of bypassing G.A.I.N. Use --proxy-fail-policy fail_open to install the service without setting client environment variables.
  - 'proxy' supports Anthropic and OpenAI-compatible request formats. Claude Code, Copilot CLI, Codex, and Aider can route when their base URL setting points at the local proxy.
  - 'desktop-check' is restrict-only desktop coverage: app/domain allowlist and blocklist enforcement, no TLS MITM.
  - 'desktop-guard' monitors clipboard only while Claude Desktop or ChatGPT Desktop is foreground. It never sends clipboard content.
  - Baselines store file path, pattern type, count, and risk only; never secret values.
  - .gainignore skips explicitly listed detector, security-tooling, or fixture paths. Use --no-gainignore to audit those paths.
  - 'scan' exits with code 2 on a BLOCK decision so it can gate git hooks / CI.
`);
}

// Install a git pre-commit hook that runs `gain-agent git-hook` from this repo.
function cmdInstallGitHook() {
  const result = require("../hooks/gitHook").installRepoGitHook(process.cwd(), { cliPath: currentCliPath() });
  if (!result.ok) {
    console.error(result.message || "Could not install git hook.");
    process.exitCode = 1;
    return;
  }
  console.log(`Installed G.A.I.N pre-commit hook at ${result.hookPath}`);
  console.log("It blocks commits that contain critical secrets and reports metadata only.");
}

function cmdInstallGlobalGitHook(args) {
  const result = require("../hooks/gitHook").installGlobalGitHook({
    cliPath: currentCliPath(),
    force: Boolean(args.flags.force)
  });
  if (!result.ok) {
    console.error(result.message || "Could not install global git hook.");
    process.exitCode = 1;
    return;
  }
  console.log(`Installed G.A.I.N global git hook at ${result.hookPath}`);
  console.log(`Configured git core.hooksPath to ${result.hooksDir}`);
  if (result.replaced) console.log("Replaced an existing global hooksPath because --force was used.");
  console.log("All repos that use the global git config will scan staged files before commit.");
}

function cmdUninstallGlobalGitHook() {
  const result = require("../hooks/gitHook").uninstallGlobalGitHook();
  console.log(result.removedConfig
    ? "Removed G.A.I.N from git core.hooksPath."
    : "G.A.I.N was not the active global git hooksPath; no git config changed.");
  console.log(`Hook files remain at ${result.hooksDir} for audit/removal if needed.`);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const command = args._.shift();
  switch (command) {
    case "--version": case "-v": case "version": console.log(AGENT_VERSION); return;
    case "init": return cmdInit(args);
    case "scan": return cmdScan(args);
    case "baseline": return cmdBaseline(args);
    case "redact": return cmdRedact(args);
    case "setup": return cmdSetup(args);
    case "license": return cmdLicense(args);
    case "siem-test": return cmdSiemTest();
    case "proxy": return cmdProxy(args);
    case "desktop-check": return cmdDesktopCheck(args);
    case "desktop-guard": return cmdDesktopGuard(args);
    case "update": return cmdUpdate(args);
    case "update-report": return cmdUpdateReport(args);
    case "integrations": return require("../integrations/catalog").printIntegrations({ json: Boolean(args.flags.json), apply: Boolean(args.flags.apply), agentPath: currentCliPath(), tools: args.flags.tools, noProxyEnv: Boolean(args.flags.noProxyEnv), noGitHook: Boolean(args.flags.noGitHook) });
    case "status": return cmdStatus(args);
    case "doctor": return cmdDoctor();
    case "sync": return cmdSync();
    case "heartbeat": return cmdHeartbeat();
    case "presence": return cmdHeartbeat({ lightweight: true });
    case "install-health-schedule": return cmdInstallHealthSchedule();
    case "uninstall-health-schedule": return cmdUninstallHealthSchedule();
    case "enable-auto-update": return cmdEnableAutoUpdate();
    case "disable-auto-update": return cmdDisableAutoUpdate();
    case "flush": return cmdFlush();
    case "mcp": return require("../mcp/server").start();
    case "git-hook": return require("../hooks/gitHook").runGitPreCommit();
    case "install-git-hook": return cmdInstallGitHook();
    case "install-global-git-hook": return cmdInstallGlobalGitHook(args);
    case "uninstall-global-git-hook": return cmdUninstallGlobalGitHook();
    case "claude-hook": return require("../hooks/claudeCodeWrapper").interceptClaudeCode();
    case "help": case "--help": case "-h": case undefined: return printHelp();
    default:
      console.error(`Unknown command: ${command}`);
      printHelp();
      process.exitCode = 1;
  }
}

function commandAvailable(command, { platform = process.platform, spawnSyncFn = spawnSync } = {}) {
  const checker = platform === "win32" ? "where.exe" : "which";
  const args = [command];
  const result = spawnSyncFn(checker, args, { stdio: "ignore", windowsHide: true });
  return !result.error && result.status === 0;
}

function checkPdfTextDependency(options = {}) {
  const ok = commandAvailable("pdftotext", options);
  return [
    true,
    ok
      ? "PDF scanning dependency: pdftotext available"
      : "PDF scanning dependency MISSING: install Poppler/pdftotext so .pdf files are scanned instead of skipped",
    ok ? undefined : "warn"
  ];
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`G.A.I.N Agent error: ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = {
  checkPdfTextDependency
};
