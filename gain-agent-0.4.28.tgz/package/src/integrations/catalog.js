"use strict";

const { PROXY_ENV_VARS } = require("./autoWire");

const GAIN_MCP_CONFIG = {
  command: "gain-agent",
  args: ["mcp"]
};

const INTEGRATIONS = [
  {
    id: "claude-code",
    name: "Claude Code",
    status: "proxy-hook-mcp-git",
    coverage: "Redact via ANTHROPIC_BASE_URL proxy, hard-block via native UserPromptSubmit and PreToolUse hooks, MCP tools, and git fallback.",
    install: [
      "Run gain-agent integrations --apply to write the Claude Code hook and MCP config automatically.",
      "Restart Claude Code after wiring so hooks are loaded.",
      "Use gain-agent status to confirm ANTHROPIC_BASE_URL points at a reachable local proxy."
    ],
    config: {
      mcpServers: { gain: GAIN_MCP_CONFIG },
      proxyEnv: { ANTHROPIC_BASE_URL: "http://127.0.0.1:8787" },
      hookCommand: "gain-agent claude-hook"
    }
  },
  {
    id: "cursor",
    name: "Cursor",
    status: "mcp-git",
    coverage: "MCP redaction/scanning tools plus git fallback. Proxy redaction is honest only in Cursor modes configured to use an OpenAI-compatible local base URL.",
    install: [
      "Run gain-agent integrations --apply to write ~/.cursor/mcp.json when Cursor is detected.",
      "Use Cursor's own provider settings for proxy routing only when your mode supports a custom OpenAI-compatible base URL.",
      "Git fallback is installed globally when possible."
    ],
    config: { mcpServers: { gain: GAIN_MCP_CONFIG } }
  },
  {
    id: "copilot-cli",
    name: "GitHub Copilot CLI",
    status: "proxy-git",
    coverage: "Redact via COPILOT_PROVIDER_BASE_URL proxy plus git fallback.",
    install: [
      "Run gain-agent integrations --apply or gain-agent proxy --service install.",
      "Open a new terminal so COPILOT_PROVIDER_BASE_URL is visible to the CLI.",
      "Use gain-agent status to confirm proxy routing is active."
    ],
    config: { proxyEnv: { COPILOT_PROVIDER_BASE_URL: "http://127.0.0.1:8787" } }
  },
  {
    id: "codex-cli",
    name: "OpenAI Codex CLI",
    status: "proxy-mcp-git",
    coverage: "MCP tools plus OpenAI-compatible proxy routing where the CLI honors OPENAI_BASE_URL or OPENAI_API_BASE.",
    install: [
      "Run gain-agent integrations --apply to write ~/.codex/config.toml MCP config.",
      "Open a new terminal so OPENAI_BASE_URL and OPENAI_API_BASE are visible.",
      "Use gain-agent status to confirm which mechanisms are active."
    ],
    configToml: "[mcp_servers.gain]\ncommand = \"gain-agent\"\nargs = [\"mcp\"]"
  },
  {
    id: "gemini-cli",
    name: "Gemini CLI",
    status: "mcp-git",
    coverage: "MCP redaction/scanning tools plus git fallback. Native Gemini API proxy redaction is not claimed yet.",
    install: [
      "Run gain-agent integrations --apply to write ~/.gemini/settings.json MCP config.",
      "Use MCP tools for explicit scan/redact actions.",
      "Git fallback is installed globally when possible."
    ],
    config: { mcpServers: { gain: GAIN_MCP_CONFIG } }
  },
  {
    id: "windsurf",
    name: "Windsurf",
    status: "git",
    coverage: "Git fallback for AI-written code. No stable native hook is edited.",
    install: ["Run gain-agent integrations --apply to detect Windsurf and install the global git fallback."],
    config: { gitFallback: "gain-agent install-global-git-hook" }
  },
  {
    id: "aider",
    name: "Aider",
    status: "proxy-git",
    coverage: "Redact via OPENAI_API_BASE proxy for OpenAI-compatible Aider models, plus git fallback.",
    install: [
      "Run gain-agent integrations --apply or gain-agent proxy --service install.",
      "Open a new terminal so OPENAI_API_BASE is visible to Aider.",
      "Use gain-agent status to confirm proxy routing is active."
    ],
    config: { proxyEnv: { OPENAI_API_BASE: "http://127.0.0.1:8787" } }
  },
  {
    id: "continue",
    name: "Continue",
    status: "git",
    coverage: "Git fallback for AI-written code. Provider-specific proxy settings are left to the admin because Continue configs vary by provider.",
    install: ["Run gain-agent integrations --apply to detect Continue and install the global git fallback."],
    config: { gitFallback: "gain-agent install-global-git-hook" }
  },
  {
    id: "cline",
    name: "Cline",
    status: "git",
    coverage: "Git fallback for AI-written code. No stable native hook is edited.",
    install: ["Run gain-agent integrations --apply to detect Cline and install the global git fallback."],
    config: { gitFallback: "gain-agent install-global-git-hook" }
  },
  {
    id: "desktop-apps",
    name: "Desktop AI apps",
    status: "restrict-and-clipboard-guard",
    coverage: "Device-level allowlist/blocklist plus foreground-only clipboard scanning for monitored desktop AI apps. No TLS MITM.",
    install: [
      "Use gain-agent setup --desktop-guard on to keep clipboard protection enabled.",
      "Run gain-agent desktop-guard status to confirm it is running.",
      "Review events in the dashboard with the Desktop app source filter."
    ],
    config: {
      command: "gain-agent desktop-check --app \"ChatGPT Desktop\" --domain chatgpt.com",
      guardCommand: "gain-agent desktop-guard start",
      surface: "desktop_app"
    }
  }
];

function normalizeToolFilter(value) {
  return String(value || "")
    .split(",")
    .map((s) => s.trim().toLowerCase().replace(/\s+/g, "-"))
    .filter(Boolean);
}

function itemMatches(item, filter) {
  if (!filter.length) return true;
  const names = [item.id, item.name].map((v) => String(v).toLowerCase().replace(/\s+/g, "-"));
  return filter.some((token) => names.includes(token));
}

function getIntegrations({ tools = "" } = {}) {
  const filter = normalizeToolFilter(tools);
  return INTEGRATIONS.filter((item) => itemMatches(item, filter)).map((item) => ({ ...item }));
}

function printIntegrations({ json = false, apply = false, agentPath = null, tools = "", noProxyEnv = false, noGitHook = false } = {}) {
  if (apply) {
    const { applyAutoWiring, printAutoWiringResult } = require("./autoWire");
    const result = applyAutoWiring({ agentPath, tools, noProxyEnv, noGitHook });
    if (json) {
      console.log(JSON.stringify(result, null, 2));
    } else {
      printAutoWiringResult(result);
    }
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if (json) {
    console.log(JSON.stringify({ integrations: getIntegrations({ tools }) }, null, 2));
    return;
  }

  console.log("G.A.I.N Agent integrations");
  console.log("Install/update the agent first, then wire it into the coding agents your team uses.\n");
  console.log("Auto-wire detected tools with: gain-agent integrations --apply");
  console.log(`Proxy envs managed by the agent: ${PROXY_ENV_VARS.join(", ")}\n`);
  for (const item of getIntegrations({ tools })) {
    console.log(`${item.name} [${item.status}]`);
    console.log(`  Coverage: ${item.coverage}`);
    console.log("  Steps:");
    for (const step of item.install) console.log(`    - ${step}`);
    if (item.configToml) {
      console.log("  Config:");
      console.log(indent(item.configToml, 4));
    } else if (item.config) {
      console.log("  Config:");
      console.log(indent(JSON.stringify(item.config, null, 2), 4));
    }
    console.log("");
  }
  console.log("Honesty rule: `gain-agent status` only says redact is active when a detected tool is routed to a reachable local proxy.");
}

function indent(text, spaces) {
  const pad = " ".repeat(spaces);
  return String(text).split("\n").map((line) => `${pad}${line}`).join("\n");
}

module.exports = { getIntegrations, printIntegrations };
