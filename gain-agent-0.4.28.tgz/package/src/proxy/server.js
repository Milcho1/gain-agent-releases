"use strict";

const http = require("http");
const https = require("https");
const { URL } = require("url");
const { loadConfig } = require("../config/loadPolicy");
const { getOrgPolicyBundle } = require("../config/orgPolicyCache");
const { scanText } = require("../scanners/scanText");
const { redactSensitiveText } = require("../scanners/redact");
const { decide } = require("../policies/decisionEngine");
const { decideAccess } = require("../policies/accessControl");
const localQueue = require("../reporters/localQueue");
const { sendEvent, isConfigured, AGENT_VERSION } = require("../reporters/supabaseEdgeClient");
const { sendSiemEvent } = require("../reporters/siem");
const { actionLine } = require("../ui/messages");
const { markProxyRequest, writeProxyState } = require("../system/proxyService");

const DEFAULT_ANTHROPIC_UPSTREAM = "https://api.anthropic.com";
const DEFAULT_OPENAI_UPSTREAM = "https://api.openai.com";
const MAX_BODY_BYTES = 8 * 1024 * 1024;

function providerForPath(pathname) {
  if (pathname === "/v1/messages" || pathname.startsWith("/v1/messages/")) return "anthropic";
  if (pathname === "/v1/chat/completions" || pathname === "/v1/responses" || pathname === "/v1/models") return "openai";
  return null;
}

function providerName(provider) {
  return provider === "anthropic" ? "Claude Code" : "Copilot CLI";
}

function providerDomain(provider) {
  return provider === "anthropic" ? "api.anthropic.com" : "api.openai.com";
}

function upstreamBase(provider, upstreams = {}) {
  return String(
    provider === "anthropic"
      ? (upstreams.anthropic || process.env.GAIN_ANTHROPIC_UPSTREAM_BASE_URL || DEFAULT_ANTHROPIC_UPSTREAM)
      : (upstreams.openai || process.env.GAIN_OPENAI_UPSTREAM_BASE_URL || process.env.GAIN_COPILOT_UPSTREAM_BASE_URL || DEFAULT_OPENAI_UPSTREAM)
  ).replace(/\/+$/, "");
}

function extractStrings(value, out = []) {
  if (typeof value === "string") out.push(value);
  else if (Array.isArray(value)) value.forEach((item) => extractStrings(item, out));
  else if (value && typeof value === "object") {
    for (const [key, child] of Object.entries(value)) {
      if (["model", "role", "type", "id", "name"].includes(key)) continue;
      extractStrings(child, out);
    }
  }
  return out;
}

function redactBodyValue(value, patterns) {
  if (typeof value === "string") return redactSensitiveText(value, patterns).text;
  if (Array.isArray(value)) return value.map((item) => redactBodyValue(item, patterns));
  if (value && typeof value === "object") {
    const next = {};
    for (const [key, child] of Object.entries(value)) {
      if (["model", "role", "type", "id", "name"].includes(key)) next[key] = child;
      else next[key] = redactBodyValue(child, patterns);
    }
    return next;
  }
  return value;
}

function cleanForwardHeaders(headers = {}) {
  const out = {};
  for (const [key, value] of Object.entries(headers)) {
    const lower = key.toLowerCase();
    if (["host", "content-length", "connection", "proxy-connection", "keep-alive", "transfer-encoding", "upgrade"].includes(lower)) continue;
    out[key] = value;
  }
  return out;
}

function buildForwardHeaders(headers = {}, body = undefined, method = "POST") {
  const out = cleanForwardHeaders(headers);
  const upperMethod = String(method || "GET").toUpperCase();
  if (!["GET", "HEAD"].includes(upperMethod) && body !== undefined) {
    out["content-length"] = String(Buffer.byteLength(String(body)));
  }
  return out;
}

function providerError(provider, status, message) {
  if (provider === "anthropic") {
    return {
      type: "error",
      error: {
        type: status === 403 ? "permission_error" : "invalid_request_error",
        message
      }
    };
  }
  return {
    error: {
      message,
      type: status === 403 ? "policy_blocked" : "invalid_request_error",
      code: "gain_policy_block"
    }
  };
}

function buildProxyEvent(config, provider, decision, patterns, bodyText, policySource, access = null) {
  return {
    surface: "agent",
    event_type: "cli_proxy_request",
    domain: providerDomain(provider),
    tool_name: providerName(provider),
    category: "cli_proxy",
    action: decision.action,
    enforcement_action: decision.action,
    severity: decision.severity,
    content_length: bodyText.length,
    patterns_detected: patterns,
    policy_triggered: decision.policy_triggered,
    detection_reason: decision.reason,
    policy_source: policySource || "local",
    is_approved_tool: access?.is_approved_tool ?? null,
    tool_status: access?.status ?? null,
    device_id: config.device_id,
    created_at: new Date().toISOString()
  };
}

async function reportProxyEvent(config, event, reporter) {
  if (reporter) return reporter(event);
  localQueue.enqueue(event);
  if (isConfigured(config)) {
    const sent = await sendEvent(config, event);
    if (sent.ok) {
      const remaining = localQueue.readAll();
      remaining.pop();
      localQueue.rewrite(remaining);
    }
  }
  await sendSiemEvent(config, event);
  return { ok: true };
}

async function resolvePolicyBundle(config, injectedBundle) {
  if (injectedBundle !== undefined) {
    return injectedBundle ? { ok: true, source: "test", policy_bundle: injectedBundle } : { ok: false, source: "none" };
  }
  return getOrgPolicyBundle(config);
}

async function handleProxyRequest(input, options = {}) {
  const config = options.config || loadConfig();
  const url = new URL(input.url, "http://127.0.0.1");
  const provider = providerForPath(url.pathname);
  if (!provider) {
    return {
      status: 404,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ error: "Unsupported proxy endpoint." })
    };
  }

  if (url.pathname === "/v1/models" && input.method === "GET" && options.modelListPassthrough === false) {
    return {
      status: 200,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ object: "list", data: [] })
    };
  }

  const bodyText = String(input.body || "");
  let parsed = null;
  if (bodyText) {
    try {
      parsed = JSON.parse(bodyText);
    } catch (_error) {
      return {
        status: 400,
        headers: { "content-type": "application/json" },
        body: JSON.stringify(providerError(provider, 400, "G.A.I.N proxy requires JSON request bodies."))
      };
    }
  }

  const textForScan = extractStrings(parsed).join("\n");
  const patterns = scanText(textForScan);
  const policyResult = await resolvePolicyBundle(config, options.orgPolicyBundle);
  const access = decideAccess({
    toolName: providerName(provider),
    domain: providerDomain(provider),
    config,
    orgPolicyBundle: policyResult.ok ? policyResult.policy_bundle : null
  });
  if (!access.allowed) {
    const event = buildProxyEvent(config, provider, {
      action: "block",
      severity: "high",
      policy_triggered: access.policy_triggered,
      reason: access.reason
    }, patterns, bodyText, policyResult.source, access);
    await reportProxyEvent(config, event, options.reporter);
    return {
      status: 403,
      headers: {
        "content-type": "application/json",
        "x-gain-policy-action": "block",
        "x-gain-access-policy": access.policy_triggered
      },
      body: JSON.stringify(providerError(provider, 403, access.reason)),
      notice: "Blocked: this AI tool is not approved on this device."
    };
  }

  const decision = decide({
    patterns,
    orgPolicyBundle: policyResult.ok ? policyResult.policy_bundle : null,
    enforcementMode: options.enforcementMode || config.enforcement_mode,
    context: {
      domain: providerDomain(provider),
      toolName: providerName(provider),
      category: "cli_proxy"
    }
  });

  if (patterns.length || decision.action === "block") {
    const event = buildProxyEvent(config, provider, decision, patterns, bodyText, policyResult.source, access);
    await reportProxyEvent(config, event, options.reporter);
  }

  if (decision.action === "block") {
    return {
      status: 403,
      headers: {
        "content-type": "application/json",
        "x-gain-policy-action": "block"
      },
      body: JSON.stringify(providerError(provider, 403, "G.A.I.N blocked this CLI request because it matched policy.")),
      notice: actionLine(decision, patterns, { context: `sending to ${providerName(provider)}` })
    };
  }

  let outboundBody = bodyText;
  if (decision.action === "redact" && parsed) {
    outboundBody = JSON.stringify(redactBodyValue(parsed, patterns));
  }

  const target = upstreamBase(provider, options.upstreams) + url.pathname + url.search;
  const fetchImpl = options.fetchImpl || fetch;
  const method = input.method || "POST";
  const upstreamBody = ["GET", "HEAD"].includes(String(method).toUpperCase()) ? undefined : outboundBody;
  const upstream = {
    method,
    target,
    headers: buildForwardHeaders(input.headers || {}, upstreamBody, method),
    body: upstreamBody
  };

  if (options.deferUpstream) {
    return {
      status: 0,
      headers: {},
      body: "",
      upstream,
      forwarded: { url: target, body: outboundBody },
      notice: patterns.length ? actionLine(decision, patterns, { context: `sending to ${providerName(provider)}` }) : null
    };
  }

  const response = await fetchImpl(target, {
    method: upstream.method,
    headers: upstream.headers,
    body: upstream.body
  });

  const headers = {};
  if (response.headers && typeof response.headers.forEach === "function") {
    response.headers.forEach((value, key) => { headers[key] = value; });
  }
  const body = typeof response.arrayBuffer === "function"
    ? Buffer.from(await response.arrayBuffer())
    : (typeof response.text === "function" ? await response.text() : "");

  return {
    status: response.status || 200,
    headers,
    body,
    forwarded: { url: target, body: outboundBody },
    notice: patterns.length ? actionLine(decision, patterns, { context: `sending to ${providerName(provider)}` }) : null
  };
}

function streamUpstreamResponse(upstream, downstream) {
  return new Promise((resolve, reject) => {
    const target = new URL(upstream.target);
    const transport = target.protocol === "https:" ? https : http;
    const request = transport.request({
      protocol: target.protocol,
      hostname: target.hostname,
      port: target.port || undefined,
      method: upstream.method,
      path: `${target.pathname}${target.search}`,
      headers: upstream.headers
    }, (upstreamResponse) => {
      if (upstreamResponse.statusMessage) {
        downstream.writeHead(upstreamResponse.statusCode || 502, upstreamResponse.statusMessage, upstreamResponse.headers);
      } else {
        downstream.writeHead(upstreamResponse.statusCode || 502, upstreamResponse.headers);
      }
      upstreamResponse.pipe(downstream);
      upstreamResponse.on("end", resolve);
      upstreamResponse.on("error", reject);
    });

    request.on("error", reject);
    downstream.on("close", () => {
      if (!downstream.writableEnded) request.destroy();
    });

    if (upstream.body !== undefined) request.write(upstream.body);
    request.end();
  });
}

function readRequestBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error("Request body too large."));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function createProxyServer(options = {}) {
  return http.createServer(async (req, res) => {
    try {
      markProxyRequest();
      const body = await readRequestBody(req);
      const result = await handleProxyRequest({
        method: req.method,
        url: req.url,
        headers: req.headers,
        body
      }, { ...options, deferUpstream: true });
      if (result.notice) console.log(`[G.A.I.N] ${result.notice}`);
      if (result.upstream) {
        await streamUpstreamResponse(result.upstream, res);
        return;
      }
      res.writeHead(result.status, result.headers);
      res.end(result.body);
    } catch (error) {
      if (res.headersSent) {
        res.destroy(error);
        return;
      }
      res.writeHead(500, { "content-type": "application/json" });
      res.end(JSON.stringify({ error: error.message }));
    }
  });
}

function startProxy({ host = "127.0.0.1", port = 8787, upstreams = {} } = {}) {
  const server = createProxyServer({ upstreams });
  server.listen(port, host, () => {
    const config = loadConfig();
    writeProxyState({
      enabled: config.proxy_service_enabled === true,
      host,
      port,
      version: AGENT_VERSION,
      proxy_pid: process.pid,
      started_at: new Date().toISOString()
    });
    console.log("G.A.I.N CLI proxy");
    console.log(`  listening: http://${host}:${port}`);
    console.log(`  mode:      ${config.enforcement_mode || "visibility_only"}`);
    console.log("  privacy:   redacting on-device, metadata only");
    console.log("  safety:    private keys and seed phrases are always blocked");
    console.log(`  Claude Code: ANTHROPIC_BASE_URL=http://${host}:${port}`);
    console.log(`  OpenAI-compatible tools: OPENAI_BASE_URL=http://${host}:${port}`);
    console.log(`  Aider: OPENAI_API_BASE=http://${host}:${port}`);
    console.log(`  Copilot CLI: COPILOT_PROVIDER_BASE_URL=http://${host}:${port}`);
    console.log("  Cursor: limited; use only where the client supports a custom OpenAI-compatible base URL.");
    console.log(`  Agent version: ${AGENT_VERSION}`);
  });
  return server;
}

module.exports = {
  createProxyServer,
  handleProxyRequest,
  streamUpstreamResponse,
  buildForwardHeaders,
  startProxy,
  extractStrings,
  providerForPath,
  DEFAULT_ANTHROPIC_UPSTREAM,
  DEFAULT_OPENAI_UPSTREAM
};
