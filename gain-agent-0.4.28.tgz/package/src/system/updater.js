"use strict";

const https = require("https");
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { execFileSync, spawn } = require("child_process");
const { AGENT_VERSION } = require("../reporters/supabaseEdgeClient");

const DEFAULT_BASE_URL = "https://www.cyberwardion.com/downloads/gain-agent";

function updateBaseUrl() {
  return (process.env.GAIN_AGENT_BASE_URL || DEFAULT_BASE_URL).replace(/\/+$/, "");
}

function latestManifestUrl() {
  return process.env.GAIN_AGENT_LATEST_URL || `${updateBaseUrl()}/latest.json`;
}

function isCyberWardionUpdateUrl(url) {
  try {
    const parsed = new URL(String(url || ""));
    return /(^|\.)cyberwardion\.com$/i.test(parsed.hostname) &&
      parsed.pathname.includes("/downloads/gain-agent");
  } catch (_error) {
    return String(url || "").toLowerCase().includes("cyberwardion.com/downloads/gain-agent");
  }
}

function shouldCheckForHostedUpdate(config = {}, manifestUrl = latestManifestUrl()) {
  if (
    config.deployment_mode === "self_hosted" &&
    config.telemetry_enabled === false &&
    isCyberWardionUpdateUrl(manifestUrl)
  ) {
    return {
      ok: false,
      skipped: true,
      reason: "self_hosted_no_vendor_update"
    };
  }
  return { ok: true, skipped: false };
}

function installScriptUrl(platform = process.platform) {
  return `${updateBaseUrl()}/${platform === "win32" ? "install.ps1" : "install.sh"}`;
}

function isStandaloneBinary() {
  return Boolean(process.pkg);
}

function platformKey(platform = process.platform, arch = process.arch) {
  const osPart = platform === "win32"
    ? "win"
    : platform === "darwin"
      ? "macos"
      : platform === "linux"
        ? "linux"
        : platform;
  const archPart = arch === "x64" || arch === "arm64" ? arch : arch;
  return `${osPart}-${archPart}`;
}

function resolveDownloadUrl(urlOrPath) {
  const raw = String(urlOrPath || "").trim();
  if (/^https?:\/\//i.test(raw)) return raw;
  return `${updateBaseUrl()}/${raw.replace(/^\/+/, "")}`;
}

function compareVersions(a, b) {
  const left = String(a || "0").split(".").map((part) => Number(part) || 0);
  const right = String(b || "0").split(".").map((part) => Number(part) || 0);
  const length = Math.max(left.length, right.length);
  for (let i = 0; i < length; i += 1) {
    const diff = (left[i] || 0) - (right[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function getJson(url) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, { headers: { "User-Agent": `gain-agent/${AGENT_VERSION}` } }, (response) => {
      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => { body += chunk; });
      response.on("end", () => {
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error(`HTTP ${response.statusCode}`));
          return;
        }
        try {
          resolve(JSON.parse(body));
        } catch (error) {
          reject(new Error(`invalid update manifest: ${error.message}`));
        }
      });
    });
    request.setTimeout(8000, () => request.destroy(new Error("timeout")));
    request.on("error", reject);
  });
}

function downloadFile(url, destination, redirects = 0) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    let request = null;
    let settled = false;
    const fail = (error) => {
      if (settled) return;
      settled = true;
      if (request) request.destroy();
      fs.rmSync(destination, { force: true });
      reject(error);
    };
    const file = fs.createWriteStream(destination, { mode: 0o755 });
    file.on("error", fail);
    request = https.get(url, { headers: { "User-Agent": `gain-agent/${AGENT_VERSION}` } }, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        if (redirects >= 5) {
          file.close(() => fail(new Error("too many redirects")));
          return;
        }
        const nextUrl = new URL(response.headers.location, url).toString();
        file.close(() => {
          fs.rmSync(destination, { force: true });
          if (settled) return;
          settled = true;
          resolve(downloadFile(nextUrl, destination, redirects + 1));
        });
        return;
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        file.close(() => fs.rmSync(destination, { force: true }));
        reject(new Error(`HTTP ${response.statusCode}`));
        return;
      }
      response.pipe(file);
      file.on("finish", () => file.close(() => {
        if (settled) return;
        settled = true;
        resolve();
      }));
    });
    request.setTimeout(30000, () => request.destroy(new Error("timeout")));
    request.on("error", (error) => {
      file.close(() => fail(error));
    });
  });
}

function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex");
}

function windowsUpdaterHelperPath(nextVersion, pid = process.pid) {
  return path.join(os.tmpdir(), `gain-agent-updater-${nextVersion || AGENT_VERSION}-${pid}.ps1`);
}

function writeWindowsUpdaterHelper(helperPath) {
  fs.mkdirSync(path.dirname(helperPath), { recursive: true });
  const script = String.raw`param(
  [Parameter(Mandatory=$true)][int]$ProcessId,
  [Parameter(Mandatory=$true)][string]$TargetPath,
  [Parameter(Mandatory=$true)][string]$PendingPath,
  [Parameter(Mandatory=$true)][string]$BackupPath,
  [Parameter(Mandatory=$true)][string]$LogPath
)

$ErrorActionPreference = "Stop"

function Write-UpdateLog([string]$Message) {
  try {
    $dir = Split-Path -Parent $LogPath
    if ($dir) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Add-Content -LiteralPath $LogPath -Value ("{0} {1}" -f (Get-Date).ToUniversalTime().ToString("o"), $Message)
  } catch {}
}

try {
  Write-UpdateLog "waiting for process $ProcessId to exit"
  $deadline = (Get-Date).AddMinutes(5)
  while ((Get-Date) -lt $deadline) {
    $process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if (-not $process) { break }
    Start-Sleep -Milliseconds 500
  }

  $stoppedProxy = $false
  try {
    $targetFullPath = [System.IO.Path]::GetFullPath($TargetPath)
    $runningTargetProcesses = Get-Process -ErrorAction SilentlyContinue | Where-Object {
      $_.Id -ne $PID -and $_.Id -ne $ProcessId -and $_.Path -and ([System.IO.Path]::GetFullPath($_.Path) -ieq $targetFullPath)
    }
    foreach ($runningProcess in $runningTargetProcesses) {
      try {
        $commandLine = (Get-CimInstance Win32_Process -Filter "ProcessId = $($runningProcess.Id)" -ErrorAction SilentlyContinue).CommandLine
        if ($commandLine -match '(?i)\bproxy\b' -and $commandLine -match '(?i)--service' -and $commandLine -match '(?i)\brun\b') {
          $stoppedProxy = $true
        }
      } catch {}
      Write-UpdateLog ("stopping old process {0} before replace" -f $runningProcess.Id)
      Stop-Process -Id $runningProcess.Id -Force -ErrorAction SilentlyContinue
    }
  } catch {
    Write-UpdateLog ("process cleanup skipped: {0}" -f $_.Exception.Message)
  }

  for ($attempt = 1; $attempt -le 90; $attempt++) {
    try {
      if (-not (Test-Path -LiteralPath $PendingPath)) {
        throw "pending binary is missing: $PendingPath"
      }
      if (Test-Path -LiteralPath $TargetPath) {
        Copy-Item -LiteralPath $TargetPath -Destination $BackupPath -Force
      }
      Copy-Item -LiteralPath $PendingPath -Destination $TargetPath -Force
      Remove-Item -LiteralPath $PendingPath -Force
      Write-UpdateLog "installed update at $TargetPath"
      if ($stoppedProxy) {
        try {
          Write-UpdateLog "restarting proxy watchdog after update"
          Start-Process -FilePath $TargetPath -ArgumentList @("proxy", "--service", "run") -WindowStyle Hidden
        } catch {
          Write-UpdateLog ("proxy restart failed: {0}" -f $_.Exception.Message)
        }
      }
      exit 0
    } catch {
      Write-UpdateLog ("attempt {0} failed: {1}" -f $attempt, $_.Exception.Message)
      Start-Sleep -Seconds 1
    }
  }
  exit 1
} catch {
  Write-UpdateLog ("fatal: {0}" -f $_.Exception.Message)
  exit 1
}
`;
  fs.writeFileSync(helperPath, script, "utf8");
  return helperPath;
}

function startWindowsUpdaterHelper({
  targetPath,
  pendingPath,
  backupPath,
  nextVersion,
  processId = process.pid,
  helperPath = windowsUpdaterHelperPath(nextVersion, processId),
  logPath = path.join(os.tmpdir(), `gain-agent-updater-${nextVersion || AGENT_VERSION}.log`),
  spawnFn = spawn
} = {}) {
  if (!targetPath || !pendingPath || !backupPath) {
    throw new Error("targetPath, pendingPath, and backupPath are required for the Windows updater helper");
  }
  writeWindowsUpdaterHelper(helperPath);
  const shell = commandExists("pwsh.exe", ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"])
    ? "pwsh.exe"
    : "powershell.exe";
  const child = spawnFn(shell, [
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    helperPath,
    "-ProcessId",
    String(processId),
    "-TargetPath",
    targetPath,
    "-PendingPath",
    pendingPath,
    "-BackupPath",
    backupPath,
    "-LogPath",
    logPath
  ], {
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  if (child && typeof child.unref === "function") child.unref();
  return {
    helperPath,
    pendingPath,
    backupPath,
    logPath,
    helperPid: child && child.pid
  };
}

async function checkForUpdate({ currentVersion = AGENT_VERSION, config = {} } = {}) {
  const manifestUrl = latestManifestUrl();
  const guard = shouldCheckForHostedUpdate(config, manifestUrl);
  if (!guard.ok) {
    return {
      ...guard,
      manifest: null,
      currentVersion,
      latestVersion: currentVersion,
      updateAvailable: false
    };
  }
  const manifest = await getJson(manifestUrl);
  const latestVersion = manifest.version;
  if (!latestVersion) throw new Error("update manifest is missing version");
  return {
    manifest,
    currentVersion,
    latestVersion,
    updateAvailable: compareVersions(latestVersion, currentVersion) > 0
  };
}

function binaryEntry(manifest, key = platformKey()) {
  const binaries = manifest && typeof manifest === "object" ? manifest.binaries : null;
  if (!binaries || typeof binaries !== "object") return null;
  return binaries[key] || null;
}

async function installStandaloneBinaryUpdate(config, { update, version, stdio = "inherit" } = {}) {
  const manifest = update?.manifest || {};
  const key = platformKey();
  const binary = binaryEntry(manifest, key);
  if (!binary || !binary.url) {
    return {
      ok: false,
      fallback: true,
      message: `No standalone binary is published for ${key}. Re-run the installer to use the npm fallback.`
    };
  }

  const nextVersion = version || update?.latestVersion || manifest.version || AGENT_VERSION;
  const suffix = process.platform === "win32" ? ".exe" : "";
  const tempPath = path.join(os.tmpdir(), `gain-agent-${nextVersion}-${key}-${process.pid}-${Date.now()}${suffix}`);
  const downloadUrl = resolveDownloadUrl(binary.url);
  await downloadFile(downloadUrl, tempPath);
  const expected = String(binary.sha256 || "").toLowerCase();
  const actual = sha256File(tempPath);
  if (expected && actual !== expected) {
    fs.rmSync(tempPath, { force: true });
    throw new Error(`downloaded binary checksum mismatch. Expected ${expected} but got ${actual}`);
  }
  if (process.platform !== "win32") fs.chmodSync(tempPath, 0o755);

  const currentPath = process.execPath;
  if (process.platform === "win32") {
    const pendingPath = path.join(path.dirname(currentPath), `gain-agent-${nextVersion}-${key}.pending.exe`);
    const backupPath = path.join(path.dirname(currentPath), `gain-agent-${AGENT_VERSION}-${key}.previous.exe`);
    fs.copyFileSync(tempPath, pendingPath);
    fs.rmSync(tempPath, { force: true });
    const helper = startWindowsUpdaterHelper({
      targetPath: currentPath,
      pendingPath,
      backupPath,
      nextVersion
    });
    return {
      ok: true,
      pending: true,
      path: pendingPath,
      helper,
      message: `Downloaded verified G.A.I.N Agent ${nextVersion}. A separate updater helper will replace ${currentPath} after this process exits. Helper log: ${helper.logPath}`
    };
  }

  fs.copyFileSync(tempPath, currentPath);
  fs.chmodSync(currentPath, 0o755);
  fs.rmSync(tempPath, { force: true });
  if (stdio !== "ignore") {
    return { ok: true, message: `Installed G.A.I.N Agent ${nextVersion} at ${currentPath}.` };
  }
  return { ok: true };
}

async function runHostedInstaller(config, { update, version, stdio = "inherit" } = {}) {
  const guard = shouldCheckForHostedUpdate(config);
  if (!guard.ok) return guard;

  if (isStandaloneBinary()) {
    return installStandaloneBinaryUpdate(config, { update, version, stdio });
  }

  const env = {
    ...process.env,
    GAIN_ORG_API_KEY: config.org_api_key || process.env.GAIN_ORG_API_KEY || "",
    GAIN_ENFORCEMENT_MODE: config.enforcement_mode || "redact",
    GAIN_DEVICE_LABEL: config.device_label || "Developer workstation",
    GAIN_DEPARTMENT: config.department || "",
    GAIN_AGENT_VERSION: version || process.env.GAIN_AGENT_VERSION || "",
    GAIN_AGENT_AUTO_UPDATE: config.auto_update ? "true" : (process.env.GAIN_AGENT_AUTO_UPDATE || "")
  };

  if (process.platform === "win32") {
    const shell = commandExists("pwsh.exe", ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"]) ? "pwsh.exe" : "powershell.exe";
    const scriptUrl = installScriptUrl("win32").replace(/'/g, "''");
    execFileSync(shell, [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      `& { irm '${scriptUrl}' | iex }`
    ], { stdio, env });
    return { ok: true };
  }

  const scriptUrl = installScriptUrl(process.platform).replace(/'/g, "'\\''");
  execFileSync("sh", [
    "-c",
    `curl -fsSL '${scriptUrl}' | bash`
  ], { stdio, env });
  return { ok: true };
}

function commandExists(command, args = ["--version"]) {
  try {
    execFileSync(command, args, { stdio: "ignore" });
    return true;
  } catch (_error) {
    return false;
  }
}

module.exports = {
  DEFAULT_BASE_URL,
  compareVersions,
  binaryEntry,
  checkForUpdate,
  downloadFile,
  installScriptUrl,
  installStandaloneBinaryUpdate,
  isCyberWardionUpdateUrl,
  isStandaloneBinary,
  latestManifestUrl,
  platformKey,
  resolveDownloadUrl,
  runHostedInstaller,
  sha256File,
  startWindowsUpdaterHelper,
  shouldCheckForHostedUpdate
};
