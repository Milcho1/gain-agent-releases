"use strict";

const { detectSensitivePatterns } = require("./patterns");

const MAX_SCAN_CHARS = 120000;

// Returns grouped pattern metadata only: [{ type, count, risk, label }].
// Never returns the matched text itself.
function scanText(text) {
  const value = String(text || "");
  const scanValue = value.length > MAX_SCAN_CHARS ? value.slice(0, MAX_SCAN_CHARS) : value;
  const patterns = detectSensitivePatterns(scanValue);
  if (value.length > 20000) {
    patterns.push({ type: "large_paste", count: 1, risk: "medium", label: "Large content" });
  }
  return patterns;
}

module.exports = { scanText, MAX_SCAN_CHARS };
