"use strict";

// Walks a file or directory and scans text files for sensitive patterns.
// Returns metadata only: file paths (relative), char counts, and grouped
// pattern types. File CONTENTS and matched substrings are never returned or stored.

const fs = require("fs");
const path = require("path");
const { scanText } = require("./scanText");
const { DOCUMENT_EXTENSIONS, extractDocumentText } = require("./documentText");
const { isIgnored, normalizePath } = require("../config/gainignore");

const IGNORED_DIRS = new Set([
  ".git", "node_modules", "dist", "build", ".next", ".cache",
  "coverage", ".gain", ".venv", "venv", "__pycache__", ".idea", ".vscode"
]);

const BINARY_EXTENSIONS = new Set([
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".svg",
  ".zip", ".gz", ".tar", ".rar", ".7z", ".mp4", ".mov", ".mp3",
  ".wav", ".woff", ".woff2", ".ttf", ".eot", ".class", ".jar", ".exe",
  ".dll", ".so", ".dylib", ".bin", ".lock", ".min.js", ".map"
]);

const MAX_FILE_BYTES = 1.5 * 1024 * 1024; // skip very large files
const MAX_DOCUMENT_BYTES = 8 * 1024 * 1024;

function isProbablyBinary(buffer) {
  const sample = buffer.subarray(0, 4096);
  for (let i = 0; i < sample.length; i += 1) {
    if (sample[i] === 0) return true;
  }
  return false;
}

function shouldSkipPath(relativePath, disabledPaths) {
  if (!Array.isArray(disabledPaths)) return false;
  return disabledPaths.some((needle) => needle && relativePath.includes(needle));
}

function collectFiles(root, disabledPaths, ignorePatterns, ignoreRoot) {
  const results = [];
  const stack = [root];
  let skippedByGainignore = 0;

  while (stack.length) {
    const current = stack.pop();
    let stat;
    try {
      stat = fs.lstatSync(current);
    } catch (_error) {
      continue;
    }
    if (stat.isSymbolicLink()) continue;

    if (stat.isDirectory()) {
      const base = path.basename(current);
      if (IGNORED_DIRS.has(base)) continue;
      let entries = [];
      try {
        entries = fs.readdirSync(current);
      } catch (_error) {
        continue;
      }
      for (const entry of entries) stack.push(path.join(current, entry));
      continue;
    }

    if (stat.isFile()) {
      const ext = path.extname(current).toLowerCase();
      const isDocument = DOCUMENT_EXTENSIONS.has(ext);
      if (stat.size > (isDocument ? MAX_DOCUMENT_BYTES : MAX_FILE_BYTES)) continue;
      if (BINARY_EXTENSIONS.has(ext)) continue;
      const ignoreRel = normalizePath(path.relative(ignoreRoot || root, current));
      if (isIgnored(ignoreRel, ignorePatterns)) {
        skippedByGainignore += 1;
        continue;
      }
      results.push({ absolute: current, size: stat.size });
    }
  }

  const files = results.filter((file) => {
    const rel = path.relative(root, file.absolute) || path.basename(file.absolute);
    return !shouldSkipPath(rel, disabledPaths);
  });
  return { files, skippedByGainignore };
}

// Returns: { root, scannedFiles, skippedByGainignore, findings: [{ file, contentLength, patterns }] }
function scanFileMetadata(targetPath, options = {}) {
  const disabledPaths = options.disabledPaths || [];
  const ignorePatterns = options.ignorePatterns || [];
  const ignoreRoot = options.ignoreRoot ? path.resolve(options.ignoreRoot) : null;
  const root = path.resolve(targetPath);

  let rootStat;
  try {
    rootStat = fs.statSync(root);
  } catch (error) {
    throw new Error(`Path not found: ${root}`);
  }

  const baseDir = rootStat.isDirectory() ? root : path.dirname(root);
  let skippedByGainignore = 0;
  let files = [];
  if (rootStat.isDirectory()) {
    const collected = collectFiles(root, disabledPaths, ignorePatterns, ignoreRoot || root);
    files = collected.files;
    skippedByGainignore = collected.skippedByGainignore;
  } else {
    const ignoreRel = normalizePath(path.relative(ignoreRoot || baseDir, root));
    if (isIgnored(ignoreRel, ignorePatterns)) {
      skippedByGainignore = 1;
      files = [];
    } else {
      files = [{ absolute: root, size: rootStat.size }];
    }
  }

  const findings = [];
  const skippedDocuments = [];
  let scannedFiles = 0;

  for (const file of files) {
    let content;
    let documentInfo = null;
    try {
      const buffer = fs.readFileSync(file.absolute);
      const ext = path.extname(file.absolute).toLowerCase();
      if (DOCUMENT_EXTENSIONS.has(ext)) {
        documentInfo = extractDocumentText(file.absolute, options);
        if (!documentInfo.ok) {
          skippedDocuments.push({
            file: path.relative(baseDir, file.absolute) || path.basename(file.absolute),
            kind: documentInfo.kind,
            reason: documentInfo.reason
          });
          continue;
        }
        content = documentInfo.text;
      } else {
        if (file.size > MAX_FILE_BYTES) continue;
        if (isProbablyBinary(buffer)) continue;
        content = buffer.toString("utf8");
      }
    } catch (_error) {
      continue;
    }
    scannedFiles += 1;

    const patterns = scanText(content);
    if (patterns.length) {
      findings.push({
        file: path.relative(baseDir, file.absolute) || path.basename(file.absolute),
        contentLength: content.length,
        documentType: documentInfo?.kind || null,
        patterns
      });
    }
    // content goes out of scope here; never stored or reported.
  }

  return { root: baseDir, scannedFiles, skippedByGainignore, skippedDocuments, findings };
}

module.exports = { scanFileMetadata, IGNORED_DIRS, BINARY_EXTENSIONS, MAX_DOCUMENT_BYTES };
