"use strict";

// Single source of truth: the agent reuses the SAME detection logic the browser
// extension ships in shared/patterns.js. We load it in a VM context (exactly like
// scripts/scanner-harness.js) so the agent and extension can never drift apart.
//
// In a standalone/published build, a packaging step would vendor shared/patterns.js
// into the agent. For the in-repo MVP we resolve it relative to the repo root, and
// allow an override via GAIN_PATTERNS_PATH.

const fs = require("fs");
const path = require("path");
const vm = require("vm");

// Packaged build: vendor/patterns.js sits inside the published package. Dev
// checkout: fall back to the repo's shared/patterns.js. Override with env.
const VENDORED_PATTERNS_PATH = path.resolve(__dirname, "..", "..", "vendor", "patterns.js");
const REPO_PATTERNS_PATH = path.resolve(__dirname, "..", "..", "..", "shared", "patterns.js");
const PATTERNS_PATH = process.env.GAIN_PATTERNS_PATH
  || (fs.existsSync(VENDORED_PATTERNS_PATH) ? VENDORED_PATTERNS_PATH : REPO_PATTERNS_PATH);

function loadDetector(patternsPath) {
  const code = fs.readFileSync(patternsPath, "utf8");
  const context = { globalThis: {} };
  vm.createContext(context);
  vm.runInContext(code, context);
  const api = context.globalThis.SHADOW_AI_PATTERNS;
  if (!api || typeof api.detectSensitivePatterns !== "function") {
    throw new Error("shared/patterns.js did not expose SHADOW_AI_PATTERNS.detectSensitivePatterns");
  }
  return api;
}

let detector;
function getDetector() {
  if (!detector) {
    try {
      detector = loadDetector(PATTERNS_PATH);
    } catch (error) {
      throw new Error(`Could not load detection patterns from ${PATTERNS_PATH}: ${error.message}`);
    }
  }
  return detector;
}

function detectSensitivePatterns(text) {
  return getDetector().detectSensitivePatterns(String(text || ""));
}

module.exports = { detectSensitivePatterns, getDetector, PATTERNS_PATH };
