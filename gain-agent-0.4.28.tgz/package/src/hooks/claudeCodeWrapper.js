"use strict";

// Claude Code hook (Phase 2). Registered as a PreToolUse / UserPromptSubmit hook,
// it scans the text Claude Code is about to act on, applies project policy
// (.gain/policy.json) + org enforcement mode, blocks the highest-risk secrets,
// and reports METADATA ONLY. Prompt/file content is never stored or transmitted.
//
// Hook contract (version-agnostic): block -> write reason to stderr + exit 2;
// allow -> exit 0. Detection reuses the same shared/patterns.js as the extension.

const { scanText } = require("../scanners/scanText");
const { decide, HARD_BLOCK_TYPES } = require("../policies/decisionEngine");
const { actionLine, blockNotificationLine, patternLabel } = require("../ui/messages");

const RISK_ORDER = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };

// Gather the scannable text from the common Claude Code hook input shapes:
// UserPromptSubmit -> input.prompt; PreToolUse -> input.tool_input.{command,
// content, new_string, ...}. Returns text for local analysis only.
function extractHookText(input) {
  if (!input || typeof input !== "object") return "";
  const parts = [];
  if (typeof input.prompt === "string") parts.push(input.prompt);
  const toolInput = input.tool_input && typeof input.tool_input === "object" ? input.tool_input : {};
  for (const key of ["command", "content", "new_string", "old_string", "file_text", "text", "query", "description"]) {
    if (typeof toolInput[key] === "string") parts.push(toolInput[key]);
  }
  return parts.join("\n");
}

function strongestPattern(patterns = []) {
  return [...patterns].sort((a, b) => (RISK_ORDER[b.risk || "info"] || 0) - (RISK_ORDER[a.risk || "info"] || 0))[0] || null;
}

function articleFor(label) {
  return /^(api|aws|iban|ip|email|internal|environment)/i.test(String(label || "")) ? "an" : "a";
}

function claudeBlockMessage(patterns = []) {
  const pattern = strongestPattern(patterns);
  if (!pattern) return "G.A.I.N blocked this. Remove the sensitive data before sending.";
  const label = patternLabel(pattern.type);
  return `G.A.I.N blocked this: it contains ${articleFor(label)} ${label}. Remove it before sending.`;
}

function hasHardBlockPattern(patterns = []) {
  return (patterns || []).some((pattern) => HARD_BLOCK_TYPES.has(pattern.type));
}

function actionForClaudeHook(decision, patterns = [], options = {}) {
  const action = String(decision && decision.action || "allow");
  if (options.proxyServiceActive && !hasHardBlockPattern(patterns)) {
    return patterns.length ? "log_only" : "allow";
  }
  return action === "redact" || action === "block" ? "block" : action;
}

// Pure decision for a Claude Code hook event. No I/O, fully testable.
function runClaudeCodeHook({ input, projectPolicy = null, orgPolicyBundle = null, enforcementMode = "visibility_only", proxyServiceActive = false } = {}) {
  const text = extractHookText(input);
  const patterns = scanText(text);
  const decision = decide({
    patterns,
    projectPolicy,
    orgPolicyBundle,
    enforcementMode,
    context: { domain: "claude-code", toolName: "Claude Code", category: "coding_agent" }
  });

  const hookAction = actionForClaudeHook(decision, patterns, { proxyServiceActive });
  const event = {
    surface: "agent",
    event_type: "claude_code_hook",
    domain: "agent.local",
    tool_name: "claude-code",
    category: "coding_agent",
    action: hookAction,
    enforcement_action: hookAction,
    policy_action: decision.action,
    severity: decision.severity,
    content_length: text.length,
    patterns_detected: patterns,
    policy_triggered: proxyServiceActive && hookAction === "log_only" ? "proxy_service_handles_redaction" : decision.policy_triggered,
    detection_reason: decision.reason,
    created_at: new Date().toISOString()
  };

  const blocked = hookAction === "block";
  return {
    decision: { ...decision, action: hookAction, policy_action: decision.action },
    patterns,
    event,
    exitCode: blocked ? 2 : 0,
    notificationMessage: blocked ? blockNotificationLine(patterns, "Claude Code") : null,
    message: blocked
      ? claudeBlockMessage(patterns)
      : (hookAction === "warn" ? actionLine(decision, patterns, { context: "sending to Claude Code" }) : null)
  };
}

// Entry point when registered as a Claude Code hook. Reads the hook JSON from
// stdin, applies policy, reports metadata (best effort), and emits the decision.
async function interceptClaudeCode(io = {}) {
  const stdin = io.stdin || process.stdin;
  const stderr = io.stderr || process.stderr;
  const exit = io.exit || process.exit;

  const { loadConfig } = require("../config/loadPolicy");
  const { findProjectPolicy } = require("../config/projectConfig");
  const { getOrgPolicyBundle } = require("../config/orgPolicyCache");
  const localQueue = require("../reporters/localQueue");
  const { sendEvent, isConfigured } = require("../reporters/supabaseEdgeClient");
  const { isLocalProxyRoutingActive } = require("../system/proxyService");

  const raw = await readStream(stdin);
  let input = {};
  try { input = raw ? JSON.parse(raw) : {}; } catch (_error) { input = {}; }

  const config = loadConfig();
  const projectResult = findProjectPolicy(input.cwd || process.cwd());
  const projectPolicy = projectResult && !projectResult.error ? projectResult.policy : null;
  const orgPolicyResult = await getOrgPolicyBundle(config);
  const orgPolicyBundle = orgPolicyResult.ok ? orgPolicyResult.policy_bundle : null;
  const proxyRoutingActive = typeof io.proxyRoutingActive === "function"
    ? await io.proxyRoutingActive(config)
    : await isLocalProxyRoutingActive();

  const result = runClaudeCodeHook({
    input,
    projectPolicy,
    orgPolicyBundle,
    enforcementMode: config.enforcement_mode,
    proxyServiceActive: proxyRoutingActive
  });

  // Reporting must never break the developer's session. Swallow all errors.
  try {
    const event = { ...result.event, device_id: config.device_id };
    localQueue.enqueue(event);
    if (isConfigured(config)) {
      const sent = await sendEvent(config, event);
      if (sent.ok) {
        const remaining = localQueue.readAll();
        remaining.pop();
        localQueue.rewrite(remaining);
      }
    }
  } catch (_error) {
    // ignore reporting failures
  }

  if (result.message) stderr.write(`${result.message}\n`);
  if (result.notificationMessage) {
    try {
      const notify = io.notify || require("../desktop/nativeNotify").notify;
      notify(result.notificationMessage, { title: "G.A.I.N" });
    } catch (_error) {
      // Native notification is best effort. The terminal message remains authoritative.
    }
  }
  exit(result.exitCode);
}

function readStream(stream) {
  return new Promise((resolve) => {
    if (!stream || typeof stream.on !== "function") return resolve("");
    let data = "";
    if (stream.setEncoding) stream.setEncoding("utf8");
    stream.on("data", (chunk) => { data += chunk; });
    stream.on("end", () => resolve(data));
    stream.on("error", () => resolve(data));
  });
}

module.exports = { interceptClaudeCode, runClaudeCodeHook, extractHookText, claudeBlockMessage, actionForClaudeHook };
