"use strict";

const fs = require("fs");
const net = require("net");
const os = require("os");
const path = require("path");
const { spawn, execFileSync } = require("child_process");
const { AGENT_VERSION } = require("../reporters/supabaseEdgeClient");
const { configDir, readConfigFile, writeConfigFile } = require("../config/loadPolicy");
const {
  defaultCliPath,
  commandLine,
  writeWindowsHiddenRunner,
  windowsCreateTaskArgs,
  windowsDeleteTaskArgs,
  windowsQueryTaskArgs
} = require("./healthSchedule");

const DEFAULT_PROXY_HOST = "127.0.0.1";
const DEFAULT_PROXY_PORT = 8787;
const PROXY_URL = `http://${DEFAULT_PROXY_HOST}:${DEFAULT_PROXY_PORT}`;
const PROXY_TASK = {
  name: "G.A.I.N Agent Proxy",
  command: "proxy --service run",
  args: ["/SC", "ONLOGON"],
  description: "hidden local AI proxy at user logon with watchdog restart"
};
const ENV_VARS = ["ANTHROPIC_BASE_URL", "OPENAI_BASE_URL", "OPENAI_API_BASE", "COPILOT_PROVIDER_BASE_URL"];
const PROFILE_MARKER_START = "# >>> G.A.I.N proxy environment >>>";
const PROFILE_MARKER_END = "# <<< G.A.I.N proxy environment <<<";
const WINDOWS_STARTUP_LAUNCHER = "G.A.I.N Agent Proxy.vbs";

function proxyUrl(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT) {
  return `http://${host}:${port}`;
}

function proxyStatePath() {
  return path.join(configDir(), "proxy-service.json");
}

function readProxyState() {
  try {
    return JSON.parse(fs.readFileSync(proxyStatePath(), "utf8"));
  } catch (_error) {
    return {};
  }
}

function writeProxyState(patch = {}) {
  const next = {
    ...readProxyState(),
    ...patch,
    updated_at: new Date().toISOString()
  };
  fs.mkdirSync(path.dirname(proxyStatePath()), { recursive: true });
  fs.writeFileSync(proxyStatePath(), JSON.stringify(next, null, 2));
  return next;
}

const PROXY_REQUEST_MARK_INTERVAL_MS = 3000;
let lastMarkedRequestAtMs = 0;

// Called on every single proxied request (every Claude Code / Copilot CLI call).
// last_request_at only feeds a human-facing status/doctor display, so this is
// throttled to avoid a synchronous disk read+write (writeProxyState) on the
// hot path of every request in a busy agentic session.
function markProxyRequest(now = Date.now()) {
  if (now - lastMarkedRequestAtMs < PROXY_REQUEST_MARK_INTERVAL_MS) return null;
  lastMarkedRequestAtMs = now;
  return writeProxyState({ last_request_at: new Date(now).toISOString() });
}

function normalizeFailPolicy(value) {
  const normalized = String(value || "fail_closed").toLowerCase().trim().replace(/[\s-]+/g, "_");
  return normalized === "fail_open" ? "fail_open" : "fail_closed";
}

function serviceCommandLine({ nodePath = process.execPath, cliPath = defaultCliPath(), command = PROXY_TASK.command } = {}) {
  return commandLine(nodePath, cliPath, command);
}

function profilePaths(homeDir = os.homedir(), platform = process.platform) {
  const paths = [path.join(homeDir, ".profile"), path.join(homeDir, ".bashrc")];
  if (platform === "darwin") paths.push(path.join(homeDir, ".zprofile"));
  return [...new Set(paths)];
}

function updateProfileBlock(filePath, blockText) {
  let current = "";
  try { current = fs.readFileSync(filePath, "utf8"); } catch (_error) {}
  const escapedStart = PROFILE_MARKER_START.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const escapedEnd = PROFILE_MARKER_END.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const withoutBlock = current.replace(new RegExp(`\\n?${escapedStart}[\\s\\S]*?${escapedEnd}\\n?`, "m"), "\n").trimEnd();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${withoutBlock}${withoutBlock ? "\n\n" : ""}${blockText}\n`, "utf8");
}

function removeProfileBlock(filePath) {
  let current = "";
  try { current = fs.readFileSync(filePath, "utf8"); } catch (_error) { return false; }
  const escapedStart = PROFILE_MARKER_START.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const escapedEnd = PROFILE_MARKER_END.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const next = current.replace(new RegExp(`\\n?${escapedStart}[\\s\\S]*?${escapedEnd}\\n?`, "m"), "\n").trimEnd();
  fs.writeFileSync(filePath, next ? `${next}\n` : "", "utf8");
  return next !== current;
}

function setWindowsUserEnv(name, value, execFile = execFileSync) {
  execFile("setx", [name, value], { stdio: "pipe", windowsHide: true });
  process.env[name] = value;
}

function unsetWindowsUserEnv(name, execFile = execFileSync) {
  try {
    execFile("reg", ["delete", "HKCU\\Environment", "/V", name, "/F"], { stdio: "pipe", windowsHide: true });
  } catch (_error) {
    // Missing values are fine on uninstall.
  }
  delete process.env[name];
}

function persistProxyEnvironment({ enabled = true, platform = process.platform, homeDir = os.homedir(), execFile = execFileSync, url = PROXY_URL } = {}) {
  if (platform === "win32") {
    for (const name of ENV_VARS) {
      if (enabled) setWindowsUserEnv(name, url, execFile);
      else unsetWindowsUserEnv(name, execFile);
    }
    for (const name of ENV_VARS) {
      if (enabled) process.env[name] = url;
      else delete process.env[name];
    }
    return { ok: true, platform, variables: enabled ? ENV_VARS : [], url: enabled ? url : null };
  }

  const files = profilePaths(homeDir, platform);
  if (enabled) {
    const block = [
      PROFILE_MARKER_START,
      `export ANTHROPIC_BASE_URL="${url}"`,
      `export OPENAI_BASE_URL="${url}"`,
      `export OPENAI_API_BASE="${url}"`,
      `export COPILOT_PROVIDER_BASE_URL="${url}"`,
      PROFILE_MARKER_END
    ].join("\n");
    for (const file of files) updateProfileBlock(file, block);
  } else {
    for (const file of files) removeProfileBlock(file);
  }
  for (const name of ENV_VARS) {
    if (enabled) process.env[name] = url;
    else delete process.env[name];
  }
  return { ok: true, platform, files, variables: enabled ? ENV_VARS : [], url: enabled ? url : null };
}

function launchAgentPath(homeDir = os.homedir()) {
  return path.join(homeDir, "Library", "LaunchAgents", "com.cyberwardion.gain-agent.proxy.plist");
}

function windowsStartupDir({ homeDir = os.homedir(), appData = process.env.APPDATA } = {}) {
  return appData
    ? path.join(appData, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
    : path.join(homeDir, "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs", "Startup");
}

function windowsStartupLauncherPath(options = {}) {
  if (options.startupLauncherPath) return options.startupLauncherPath;
  return path.join(options.startupDir || windowsStartupDir(options), WINDOWS_STARTUP_LAUNCHER);
}

function windowsServiceRunArgs(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT) {
  return ["proxy", "--service", "run", "--host", host, "--port", String(port)];
}

function writeWindowsStartupLauncher({ nodePath = process.execPath, cliPath = defaultCliPath(), host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, launcherPath = windowsStartupLauncherPath() } = {}) {
  fs.mkdirSync(path.dirname(launcherPath), { recursive: true });
  const parts = cliPath
    ? [nodePath, cliPath, ...windowsServiceRunArgs(host, port)]
    : [nodePath, ...windowsServiceRunArgs(host, port)];
  const command = parts.map((part) => `Chr(34) & "${escapeVbs(part)}" & Chr(34)`).join(" & \" \" & ");
  const script = [
    "Option Explicit",
    "Dim shell, commandLine",
    "Set shell = CreateObject(\"WScript.Shell\")",
    `commandLine = ${command}`,
    "shell.Run commandLine, 0, False"
  ].join("\r\n");
  fs.writeFileSync(launcherPath, script, "utf8");
  return launcherPath;
}

function startWindowsWatchdogHidden({ hiddenRunnerPath: runnerPath, host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, execFile = execFileSync } = {}) {
  execFile("wscript.exe", [runnerPath, ...windowsServiceRunArgs(host, port)], { stdio: "ignore", windowsHide: true });
}

function startWindowsStartupLauncher({ launcherPath, execFile = execFileSync } = {}) {
  execFile("wscript.exe", [launcherPath], { stdio: "ignore", windowsHide: true });
}

function systemdUserUnitPath(homeDir = os.homedir()) {
  return path.join(homeDir, ".config", "systemd", "user", "gain-agent-proxy.service");
}

function installMacLaunchAgent(options = {}) {
  const homeDir = options.homeDir || os.homedir();
  const plistPath = options.plistPath || launchAgentPath(homeDir);
  const command = serviceCommandLine(options);
  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.cyberwardion.gain-agent.proxy</string>
  <key>ProgramArguments</key>
  <array><string>/bin/sh</string><string>-lc</string><string>${escapeXml(command)}</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>${escapeXml(path.join(configDir(), "proxy.log"))}</string>
  <key>StandardErrorPath</key><string>${escapeXml(path.join(configDir(), "proxy.err.log"))}</string>
</dict>
</plist>
`;
  fs.mkdirSync(path.dirname(plistPath), { recursive: true });
  fs.writeFileSync(plistPath, plist, "utf8");
  const execFile = options.execFile || execFileSync;
  try { execFile("launchctl", ["unload", plistPath], { stdio: "ignore" }); } catch (_error) {}
  try { execFile("launchctl", ["load", plistPath], { stdio: "pipe" }); } catch (_error) {}
  return { ok: true, installed: true, plistPath };
}

function uninstallMacLaunchAgent(options = {}) {
  const plistPath = options.plistPath || launchAgentPath(options.homeDir || os.homedir());
  const execFile = options.execFile || execFileSync;
  try { execFile("launchctl", ["unload", plistPath], { stdio: "ignore" }); } catch (_error) {}
  fs.rmSync(plistPath, { force: true });
  return { ok: true, removed: [plistPath] };
}

function installLinuxUserService(options = {}) {
  const homeDir = options.homeDir || os.homedir();
  const unitPath = options.unitPath || systemdUserUnitPath(homeDir);
  const command = serviceCommandLine(options);
  const unit = `[Unit]
Description=G.A.I.N Agent local AI proxy

[Service]
ExecStart=/bin/sh -lc '${command.replace(/'/g, "'\\''")}'
Restart=always
RestartSec=2

[Install]
WantedBy=default.target
`;
  fs.mkdirSync(path.dirname(unitPath), { recursive: true });
  fs.writeFileSync(unitPath, unit, "utf8");
  const execFile = options.execFile || execFileSync;
  try { execFile("systemctl", ["--user", "daemon-reload"], { stdio: "ignore" }); } catch (_error) {}
  try { execFile("systemctl", ["--user", "enable", "--now", "gain-agent-proxy.service"], { stdio: "pipe" }); } catch (_error) {}
  return { ok: true, installed: true, unitPath };
}

function uninstallLinuxUserService(options = {}) {
  const unitPath = options.unitPath || systemdUserUnitPath(options.homeDir || os.homedir());
  const execFile = options.execFile || execFileSync;
  try { execFile("systemctl", ["--user", "disable", "--now", "gain-agent-proxy.service"], { stdio: "ignore" }); } catch (_error) {}
  fs.rmSync(unitPath, { force: true });
  try { execFile("systemctl", ["--user", "daemon-reload"], { stdio: "ignore" }); } catch (_error) {}
  return { ok: true, removed: [unitPath] };
}

function stopRecordedProxyProcesses(state = readProxyState()) {
  const stopped = [];
  for (const key of ["proxy_pid", "watchdog_pid"]) {
    const pid = Number(state[key]);
    if (!Number.isFinite(pid) || pid <= 0 || pid === process.pid) continue;
    try {
      process.kill(pid);
      stopped.push({ key, pid });
    } catch (_error) {
      // The process may already be gone. Uninstall should still succeed.
    }
  }
  return stopped;
}

function installProxyService(options = {}) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();
  const host = options.host || DEFAULT_PROXY_HOST;
  const port = Number(options.port || DEFAULT_PROXY_PORT);
  const failPolicy = normalizeFailPolicy(options.failPolicy || readConfigFile().proxy_fail_policy);

  let serviceResult;
  if (platform === "win32") {
    const runnerPath = options.hiddenRunnerPath || writeWindowsHiddenRunner({ nodePath, cliPath });
    try {
      runner("schtasks", windowsCreateTaskArgs(PROXY_TASK, { nodePath, cliPath, hiddenRunnerPath: runnerPath }), { stdio: "pipe", windowsHide: true });
      try { startWindowsWatchdogHidden({ hiddenRunnerPath: runnerPath, host, port, execFile: runner }); } catch (_error) {}
      serviceResult = { ok: true, installed: true, variant: "scheduled_task", task: PROXY_TASK.name, hiddenRunnerPath: runnerPath };
    } catch (error) {
      const launcherPath = writeWindowsStartupLauncher({
        nodePath,
        cliPath,
        host,
        port,
        launcherPath: options.startupLauncherPath || windowsStartupLauncherPath(options)
      });
      try { startWindowsStartupLauncher({ launcherPath, execFile: runner }); } catch (_error) {}
      serviceResult = {
        ok: true,
        installed: true,
        variant: "startup_folder",
        startupLauncherPath: launcherPath,
        fallbackFrom: "scheduled_task",
        warning: error.message
      };
    }
  } else if (platform === "darwin") {
    serviceResult = installMacLaunchAgent({ ...options, nodePath, cliPath });
  } else {
    serviceResult = installLinuxUserService({ ...options, nodePath, cliPath });
  }

  const envResult = persistProxyEnvironment({
    enabled: failPolicy === "fail_closed",
    platform,
    homeDir: options.homeDir || os.homedir(),
    execFile: runner,
    url: proxyUrl(host, port)
  });

  const nextConfig = {
    ...readConfigFile(),
    proxy_service_enabled: true,
    proxy_service_host: host,
    proxy_service_port: port,
    proxy_fail_policy: failPolicy
  };
  writeConfigFile(nextConfig);
  writeProxyState({
    enabled: true,
    host,
    port,
    version: AGENT_VERSION,
    fail_policy: failPolicy,
    service_variant: serviceResult.variant || serviceResult.task || serviceResult.plistPath || serviceResult.unitPath || null,
    startup_launcher_path: serviceResult.startupLauncherPath || null
  });

  return {
    ok: serviceResult.ok && envResult.ok,
    host,
    port,
    failPolicy,
    env: envResult,
    service: serviceResult,
    message: failPolicy === "fail_closed"
      ? `Proxy service installed. Supported Anthropic and OpenAI-compatible tools route through ${proxyUrl(host, port)} after terminal restart.`
      : "Proxy service installed in fail-open mode. Client environment variables were not set."
  };
}

function uninstallProxyService(options = {}) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  const state = readProxyState();
  let serviceResult;
  if (platform === "win32") {
    const removed = [];
    let warning = null;
    try {
      runner("schtasks", windowsDeleteTaskArgs(PROXY_TASK), { stdio: "pipe", windowsHide: true });
      removed.push(PROXY_TASK.name);
    } catch (error) {
      warning = error.message;
    }
    const launcherPath = state.startup_launcher_path || windowsStartupLauncherPath(options);
    try {
      if (fs.existsSync(launcherPath)) {
        fs.rmSync(launcherPath, { force: true });
        removed.push(launcherPath);
      }
    } catch (error) {
      warning = warning ? `${warning}; ${error.message}` : error.message;
    }
    serviceResult = { ok: true, removed, warning };
  } else if (platform === "darwin") {
    serviceResult = uninstallMacLaunchAgent(options);
  } else {
    serviceResult = uninstallLinuxUserService(options);
  }

  const envResult = persistProxyEnvironment({
    enabled: false,
    platform,
    homeDir: options.homeDir || os.homedir(),
    execFile: runner
  });
  writeConfigFile({ ...readConfigFile(), proxy_service_enabled: false });
  const stopped = stopRecordedProxyProcesses(state);
  writeProxyState({ enabled: false, stopped_at: new Date().toISOString(), proxy_pid: null, watchdog_pid: null });
  return { ok: serviceResult.ok && envResult.ok, service: serviceResult, env: envResult, stopped };
}

function queryWindowsTask(options = {}) {
  const runner = options.execFileSync || execFileSync;
  try {
    const output = String(runner("schtasks", windowsQueryTaskArgs(PROXY_TASK), { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], windowsHide: true }) || "");
    const statusMatch = output.match(/Status:\s*(.+)/i);
    const status = statusMatch ? statusMatch[1].trim() : "";
    return { enabled: true, raw: output, running: /^Running$/i.test(status) };
  } catch (_error) {
    return { enabled: false, running: false, raw: "" };
  }
}

function queryWindowsStartupLauncher(options = {}) {
  const launcherPath = options.startupLauncherPath || windowsStartupLauncherPath(options);
  return { enabled: fs.existsSync(launcherPath), running: false, launcherPath };
}

function parseWmicMemoryCsv(output, numericPid) {
  const lines = String(output || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (lines.length < 2) return null;
  const header = lines[0].split(",").map((item) => item.trim().toLowerCase());
  for (const line of lines.slice(1)) {
    const values = line.split(",");
    const row = {};
    header.forEach((name, index) => { row[name] = values[index] ? values[index].trim() : ""; });
    const pid = Number(row.processid);
    if (pid !== numericPid) continue;
    const workingSetBytes = Number(row.workingsetsize);
    const pageFileKb = Number(row.pagefileusage);
    if (!Number.isFinite(workingSetBytes)) return null;
    return {
      pid,
      workingSetBytes,
      privateBytes: Number.isFinite(pageFileKb) ? pageFileKb * 1024 : null,
      name: row.name || null
    };
  }
  return null;
}

function readProcessMemory(pid, options = {}) {
  const numericPid = Number(pid);
  if (!Number.isFinite(numericPid) || numericPid <= 0) return null;
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  try {
    if (platform === "win32") {
      try {
        const wmicOutput = String(runner("wmic", [
          "process",
          "where",
          `processid=${numericPid}`,
          "get",
          "ProcessId,WorkingSetSize,PageFileUsage,Name",
          "/format:csv"
        ], {
          encoding: "utf8",
          stdio: ["ignore", "pipe", "ignore"],
          windowsHide: true
        }) || "");
        const parsed = parseWmicMemoryCsv(wmicOutput, numericPid);
        if (parsed) return parsed;
      } catch (_error) {
        // WMIC is absent on some Windows images. Fall back to PowerShell below.
      }
      const shell = options.powerShell || "powershell.exe";
      const command = [
        `$p = Get-Process -Id ${numericPid} -ErrorAction SilentlyContinue`,
        "if ($p) {",
        "  [pscustomobject]@{",
        "    pid = $p.Id;",
        "    workingSetBytes = [int64]$p.WorkingSet64;",
        "    privateBytes = [int64]$p.PrivateMemorySize64;",
        "    name = $p.ProcessName",
        "  } | ConvertTo-Json -Compress",
        "}"
      ].join("; ");
      const output = String(runner(shell, ["-NoProfile", "-Command", command], {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"],
        windowsHide: true
      }) || "").trim();
      if (!output) return null;
      return JSON.parse(output);
    }

    const output = String(runner("ps", ["-o", "rss=", "-p", String(numericPid)], {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"]
    }) || "").trim();
    const rssKb = Number(output.split(/\s+/)[0]);
    if (!Number.isFinite(rssKb)) return null;
    return { pid: numericPid, workingSetBytes: rssKb * 1024, privateBytes: null, name: null };
  } catch (_error) {
    return null;
  }
}

function serviceProcessMemory(state = readProxyState(), options = {}) {
  return {
    watchdog: readProcessMemory(state.watchdog_pid, options),
    proxy: readProcessMemory(state.proxy_pid, options)
  };
}

function probeProxyPort(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, timeoutMs = 500) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port });
    const done = (running) => {
      socket.removeAllListeners();
      socket.destroy();
      resolve(running);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => done(true));
    socket.once("timeout", () => done(false));
    socket.once("error", () => done(false));
  });
}

async function getProxyServiceStatus(options = {}) {
  const config = readConfigFile();
  const host = config.proxy_service_host || DEFAULT_PROXY_HOST;
  const port = Number(config.proxy_service_port || DEFAULT_PROXY_PORT);
  const state = readProxyState();
  const platform = options.platform || process.platform;
  const enabled = config.proxy_service_enabled === true;
  const running = options.probe
    ? await options.probe(host, port)
    : await probeProxyPort(host, port, options.timeoutMs || 500);
  const task = platform === "win32" ? queryWindowsTask(options) : { enabled, running };
  const startup = platform === "win32" ? queryWindowsStartupLauncher(options) : { enabled: false, running: false };
  const service = platform === "win32"
    ? { enabled: task.enabled || startup.enabled, running: task.running || running, task, startup }
    : { enabled, running };
  const processMemory = options.includeProcessMemory === false
    ? null
    : serviceProcessMemory(state, { ...options, platform });
  return {
    enabled,
    serviceEnabled: service.enabled,
    serviceVariant: platform === "win32"
      ? (task.enabled ? "scheduled_task" : (startup.enabled ? "startup_folder" : null))
      : (state.service_variant || null),
    running,
    version: state.version || AGENT_VERSION,
    host,
    port,
    url: `http://${host}:${port}`,
    failPolicy: normalizeFailPolicy(config.proxy_fail_policy),
    lastRequestAt: state.last_request_at || null,
    processMemory,
    env: {
      ANTHROPIC_BASE_URL: process.env.ANTHROPIC_BASE_URL || null,
      OPENAI_BASE_URL: process.env.OPENAI_BASE_URL || null,
      OPENAI_API_BASE: process.env.OPENAI_API_BASE || null,
      COPILOT_PROVIDER_BASE_URL: process.env.COPILOT_PROVIDER_BASE_URL || null
    }
  };
}

function parseLoopbackProxyUrl(value) {
  if (!value) return null;
  let parsed;
  try { parsed = new URL(String(value)); } catch (_error) { return null; }
  if (!/^https?:$/i.test(parsed.protocol)) return null;
  const host = String(parsed.hostname || "").replace(/^\[|\]$/g, "").toLowerCase();
  const isLoopback = host === "localhost" || host === "127.0.0.1" || host === "::1";
  if (!isLoopback) return null;
  const port = Number(parsed.port || (parsed.protocol === "https:" ? 443 : 80));
  if (!Number.isFinite(port) || port < 1 || port > 65535) return null;
  return { host: host === "localhost" ? "127.0.0.1" : host, port, url: parsed.toString() };
}

async function isLocalProxyRoutingActive(options = {}) {
  const env = options.env || process.env;
  const target = parseLoopbackProxyUrl(options.url || env.ANTHROPIC_BASE_URL);
  if (!target) return false;
  const probe = options.probe || probeProxyPort;
  try {
    return Boolean(await probe(target.host, target.port, options.timeoutMs || 250));
  } catch (_error) {
    return false;
  }
}

function samePath(left, right) {
  if (!left || !right) return false;
  try {
    return path.resolve(String(left)).toLowerCase() === path.resolve(String(right)).toLowerCase();
  } catch (_error) {
    return String(left).toLowerCase() === String(right).toLowerCase();
  }
}

function proxyChildCommand({ host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const binaryMode = !cliPath || samePath(nodePath, cliPath);
  return {
    command: nodePath,
    args: binaryMode
      ? ["proxy", "--host", host, "--port", String(port)]
      : [cliPath, "proxy", "--host", host, "--port", String(port)]
  };
}

function spawnProxyChild({ host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const { command, args } = proxyChildCommand({ host, port, nodePath, cliPath });
  const child = spawn(command, args, {
    detached: false,
    stdio: "ignore",
    windowsHide: true,
    env: { ...process.env, GAIN_PROXY_SERVICE_CHILD: "1" }
  });
  return child;
}

function runProxyServiceWatchdog(options = {}) {
  const host = options.host || DEFAULT_PROXY_HOST;
  const port = Number(options.port || DEFAULT_PROXY_PORT);
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();
  let stopping = false;
  let restartCount = 0;

  writeProxyState({ enabled: true, watchdog_pid: process.pid, host, port, version: AGENT_VERSION, started_at: new Date().toISOString() });

  const start = () => {
    if (stopping) return;
    const child = spawnProxyChild({ host, port, nodePath, cliPath });
    writeProxyState({ proxy_pid: child.pid, restart_count: restartCount, host, port, version: AGENT_VERSION });
    child.on("exit", () => {
      if (stopping) return;
      restartCount += 1;
      writeProxyState({ last_exit_at: new Date().toISOString(), restart_count: restartCount });
      setTimeout(start, Number(options.restartDelayMs || 2000));
    });
  };

  process.on("SIGTERM", () => {
    stopping = true;
    writeProxyState({ stopped_at: new Date().toISOString() });
    process.exit(0);
  });
  process.on("SIGINT", () => {
    stopping = true;
    writeProxyState({ stopped_at: new Date().toISOString() });
    process.exit(0);
  });

  start();
}

function escapeXml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function escapeVbs(value) {
  return String(value || "").replace(/"/g, "\"\"");
}

module.exports = {
  DEFAULT_PROXY_HOST,
  DEFAULT_PROXY_PORT,
  PROXY_URL,
  PROXY_TASK,
  ENV_VARS,
  proxyUrl,
  proxyStatePath,
  readProxyState,
  writeProxyState,
  markProxyRequest,
  normalizeFailPolicy,
  readProcessMemory,
  serviceProcessMemory,
  serviceCommandLine,
  persistProxyEnvironment,
  installProxyService,
  uninstallProxyService,
  stopRecordedProxyProcesses,
  getProxyServiceStatus,
  runProxyServiceWatchdog,
  isLocalProxyRoutingActive,
  parseLoopbackProxyUrl,
  probeProxyPort,
  proxyChildCommand,
  windowsStartupDir,
  windowsStartupLauncherPath,
  writeWindowsStartupLauncher,
  startWindowsWatchdogHidden,
  startWindowsStartupLauncher,
  launchAgentPath,
  systemdUserUnitPath,
  profilePaths
};
