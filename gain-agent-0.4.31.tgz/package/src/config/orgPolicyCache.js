"use strict";

const fs = require("fs");
const path = require("path");
const { configDir } = require("./loadPolicy");
const { fetchPolicyBundle, isConfigured } = require("../reporters/supabaseEdgeClient");

const CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const LIVE_POLICY_MEMORY_MAX_AGE_MS = 15 * 1000;
let memoryPolicyCache = null;

function cachePath() {
  return path.join(configDir(), "policy-cache.json");
}

function readPolicyCache(now = Date.now()) {
  try {
    const raw = JSON.parse(fs.readFileSync(cachePath(), "utf8"));
    const cachedAt = Number(raw.cached_at_ms || 0);
    const ageMs = cachedAt ? now - cachedAt : Number.POSITIVE_INFINITY;
    if (!raw.policy_bundle || ageMs > CACHE_MAX_AGE_MS) return { ok: false, reason: "stale_or_missing" };
    return { ok: true, source: "cache", ageMs, policy_bundle: raw.policy_bundle };
  } catch (_error) {
    return { ok: false, reason: "missing" };
  }
}

function writePolicyCache(policyBundle) {
  if (!policyBundle || typeof policyBundle !== "object") return false;
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(cachePath(), JSON.stringify({
    cached_at: new Date().toISOString(),
    cached_at_ms: Date.now(),
    bundle_version: policyBundle.bundle_version || null,
    policy_bundle: policyBundle
  }, null, 2));
  return true;
}

function policyCacheKey(config = {}) {
  return [
    config.supabase_url || "",
    config.org_api_key || "",
    config.device_id || ""
  ].join("|");
}

function readMemoryPolicyCache(config, now = Date.now()) {
  if (!memoryPolicyCache) return { ok: false, reason: "missing" };
  if (memoryPolicyCache.key !== policyCacheKey(config)) return { ok: false, reason: "different_device" };
  const ageMs = now - Number(memoryPolicyCache.cached_at_ms || 0);
  if (!memoryPolicyCache.policy_bundle || ageMs < 0 || ageMs > LIVE_POLICY_MEMORY_MAX_AGE_MS) {
    return { ok: false, reason: "stale_or_missing" };
  }
  return { ok: true, source: "memory", ageMs, policy_bundle: memoryPolicyCache.policy_bundle };
}

function writeMemoryPolicyCache(config, policyBundle, now = Date.now()) {
  if (!policyBundle || typeof policyBundle !== "object") return false;
  memoryPolicyCache = {
    key: policyCacheKey(config),
    cached_at_ms: now,
    policy_bundle: policyBundle
  };
  return true;
}

function clearMemoryPolicyCache() {
  memoryPolicyCache = null;
}

async function getOrgPolicyBundle(config, options = {}) {
  const { allowFetch = true, forceRefresh = false, now = Date.now() } = options;
  if (allowFetch && isConfigured(config)) {
    if (!forceRefresh) {
      const memory = readMemoryPolicyCache(config, now);
      if (memory.ok) return memory;
    }
    const live = await fetchPolicyBundle(config);
    if (live.ok && live.policy_bundle) {
      writePolicyCache(live.policy_bundle);
      writeMemoryPolicyCache(config, live.policy_bundle, now);
      return { ok: true, source: "live", policy_bundle: live.policy_bundle };
    }
    const cached = readPolicyCache(now);
    if (cached.ok) return { ...cached, liveError: live.error || live.reason || "fetch_failed" };
    return { ok: false, source: "none", reason: live.error || live.reason || "fetch_failed" };
  }
  return readPolicyCache(now);
}

module.exports = {
  cachePath,
  readPolicyCache,
  writePolicyCache,
  readMemoryPolicyCache,
  clearMemoryPolicyCache,
  getOrgPolicyBundle,
  CACHE_MAX_AGE_MS,
  LIVE_POLICY_MEMORY_MAX_AGE_MS
};
