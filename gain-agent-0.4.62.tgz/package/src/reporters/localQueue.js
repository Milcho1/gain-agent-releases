"use strict";

// Append-only local queue of metadata events (JSON lines) at ~/.gain/queue.jsonl.
// Events wait here until they are flushed to the Supabase Edge ingest.
// Stores metadata only. Never prompt or file content.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { configDir } = require("../config/loadPolicy");

const LOCK_WAIT_MS = 5000;
const STALE_LOCK_MS = 30000;

function isLockContentionError(error) {
  // Windows can report a transient sharing violation as EPERM or EACCES while
  // another agent process owns the exclusive lock. Treat it like EEXIST and
  // retry, rather than dropping the metadata event or failing packaging tests.
  return ["EEXIST", "EACCES", "EPERM", "EBUSY"].includes(error?.code);
}

function queuePath() {
  return path.join(configDir(), "queue.jsonl");
}

function lockPath() {
  return `${queuePath()}.lock`;
}

function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function withQueueLock(action) {
  const dir = configDir();
  fs.mkdirSync(dir, { recursive: true });
  const lock = lockPath();
  const deadline = Date.now() + LOCK_WAIT_MS;
  let descriptor = null;

  while (descriptor === null) {
    try {
      descriptor = fs.openSync(lock, "wx");
    } catch (error) {
      if (!isLockContentionError(error)) throw error;
      try {
        const ageMs = Date.now() - fs.statSync(lock).mtimeMs;
        if (ageMs > STALE_LOCK_MS) {
          fs.rmSync(lock, { force: true });
          continue;
        }
      } catch (_error) {
        // Another process released or refreshed the lock. Retry below.
      }
      if (Date.now() >= deadline) {
        throw new Error("Timed out waiting for the G.A.I.N metadata queue. Event remains local and protection continues.");
      }
      sleepSync(10);
    }
  }

  try {
    return action();
  } finally {
    try { fs.closeSync(descriptor); } catch (_error) { /* close best effort */ }
    try { fs.rmSync(lock, { force: true }); } catch (_error) { /* cleanup best effort */ }
  }
}

function enqueue(event) {
  const queueId = crypto.randomUUID();
  // This ID exists only in the local queue. It lets concurrent delivery remove
  // the exact event acknowledged by the backend, never a newer event.
  withQueueLock(() => {
    fs.appendFileSync(queuePath(), `${JSON.stringify({ ...event, __gain_queue_id: queueId })}\n`);
  });
  return queueId;
}

function readAll() {
  try {
    return fs.readFileSync(queuePath(), "utf8")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        try { return JSON.parse(line); } catch (_error) { return null; }
      })
      .filter(Boolean);
  } catch (_error) {
    return [];
  }
}

function count() {
  return readAll().length;
}

function rewriteUnsafe(events) {
  if (!events.length) {
    try { fs.rmSync(queuePath()); } catch (_error) { /* already gone */ }
    return;
  }
  const temporary = `${queuePath()}.${process.pid}.${crypto.randomUUID()}.tmp`;
  try {
    fs.writeFileSync(temporary, events.map((event) => JSON.stringify(event)).join("\n") + "\n");
    fs.renameSync(temporary, queuePath());
  } finally {
    try { fs.rmSync(temporary, { force: true }); } catch (_error) { /* rename succeeded */ }
  }
}

function rewrite(events) {
  return withQueueLock(() => rewriteUnsafe(events));
}

function sameDeliveryEvent(left, right) {
  return JSON.stringify(toDeliveryEvent(left)) === JSON.stringify(toDeliveryEvent(right));
}

function remove(queueId, legacyEvent = null) {
  if (!queueId) return false;
  return withQueueLock(() => {
    const events = readAll();
    let index = events.findIndex((event) => event && event.__gain_queue_id === queueId);
    // Queue files created before per-event IDs are still deliverable. Remove the
    // matching legacy line only when a caller is explicitly flushing that line.
    if (index < 0 && legacyEvent) {
      index = events.findIndex((event) => !event.__gain_queue_id && sameDeliveryEvent(event, legacyEvent));
    }
    if (index < 0) return false;
    events.splice(index, 1);
    rewriteUnsafe(events);
    return true;
  });
}

function toDeliveryEvent(event = {}) {
  const { __gain_queue_id: _localQueueId, ...deliveryEvent } = event;
  return deliveryEvent;
}

async function flush(deliver) {
  if (typeof deliver !== "function") throw new TypeError("localQueue.flush requires a delivery function");
  const events = readAll();
  let sent = 0;
  let failed = 0;
  for (const event of events) {
    try {
      const result = await deliver(toDeliveryEvent(event), event);
      if (result && result.ok) {
        remove(event.__gain_queue_id || "legacy", event);
        sent += 1;
      } else {
        failed += 1;
      }
    } catch (_error) {
      failed += 1;
    }
  }
  return { total: events.length, sent, failed, remaining: count() };
}

function clear() {
  rewrite([]);
}

module.exports = { enqueue, readAll, count, rewrite, remove, toDeliveryEvent, flush, clear, queuePath, isLockContentionError };
