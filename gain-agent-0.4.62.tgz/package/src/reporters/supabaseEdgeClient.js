"use strict";

// Posts metadata-only events to the Supabase Edge ingest, matching the contract in
// supabase/functions/extension-events/index.ts:
//   - POST {supabase_url}/functions/v1/extension-events
//   - org key via x-org-api-key header
//   - supabase anon key via apikey + Authorization headers
//   - body: { event: { event_type, domain, tool_name, ... } }
// data_source is forced to "live" server-side. Never sends prompt/file content.

const EVENTS_PATH = "/functions/v1/extension-events";
const BOOTSTRAP_PATH = "/functions/v1/extension-bootstrap";
const HEARTBEAT_PATH = "/functions/v1/extension-heartbeat";
const PRESENCE_PATH = "/functions/v1/extension-presence";
const TIMEOUT_MS = 8000;
const MAX_REQUEST_ATTEMPTS = 3;
const RETRY_BASE_DELAY_MS = 150;
const TRANSIENT_HTTP_STATUSES = new Set([408, 425, 429, 502, 503, 504]);
const AGENT_VERSION = require("../../package.json").version;
const { DEFAULT_SUPABASE_URL } = require("../config/loadPolicy");

function isConfigured(config) {
  return Boolean(config && config.org_api_key && config.supabase_url && config.supabase_key);
}

function isDefaultHostedBackend(url) {
  return String(url || "").replace(/\/+$/, "") === DEFAULT_SUPABASE_URL;
}

function shouldContactBackend(config) {
  if (!isConfigured(config)) return { ok: false, reason: "not_configured" };
  if (config.active === false) return { ok: false, reason: "device_removed_by_admin" };
  if (config.deployment_mode === "self_hosted" && config.telemetry_enabled === false && isDefaultHostedBackend(config.supabase_url)) {
    return { ok: false, reason: "self_hosted_no_vendor_telemetry" };
  }
  return { ok: true };
}

function buildHeaders(config) {
  return {
    "Content-Type": "application/json",
    "apikey": config.supabase_key,
    "Authorization": `Bearer ${config.supabase_key}`,
    "x-org-api-key": config.org_api_key
  };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function retryAfterMs(headers) {
  const value = typeof headers?.get === "function" ? headers.get("retry-after") : null;
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds < 0) return null;
  return Math.min(2000, Math.round(seconds * 1000));
}

function isTransientBackendFailure(result) {
  return Boolean(result && !result.ok && (
    result.transient || TRANSIENT_HTTP_STATUSES.has(Number(result.status))
  ));
}

async function postJsonWithRetry(config, url, body, options = {}) {
  const maxAttempts = Math.max(1, Number(options.maxAttempts || MAX_REQUEST_ATTEMPTS));
  let lastResult = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: buildHeaders(config),
        body: JSON.stringify(body),
        signal: controller.signal
      });
      const text = await response.text();
      let parsed = {};
      try { parsed = JSON.parse(text); } catch (_error) { parsed = { raw: text }; }
      lastResult = !response.ok || parsed.ok === false
        ? {
          ok: false,
          status: response.status,
          error: parsed.error || text || `HTTP ${response.status}`,
          code: parsed.code || null,
          retryAfterMs: retryAfterMs(response.headers)
        }
        : { ok: true, status: response.status, ...parsed };
    } catch (error) {
      lastResult = {
        ok: false,
        error: error.name === "AbortError" ? "timeout" : error.message,
        transient: true
      };
    } finally {
      clearTimeout(timer);
    }

    if (!isTransientBackendFailure(lastResult) || attempt === maxAttempts) {
      return { ...lastResult, attempts: attempt };
    }
    const backoffMs = lastResult.retryAfterMs ?? Math.min(1000, RETRY_BASE_DELAY_MS * (2 ** (attempt - 1)));
    await sleep(backoffMs);
  }
  return { ...lastResult, attempts: maxAttempts };
}

async function sendEvent(config, event) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  const url = config.supabase_url.replace(/\/+$/, "") + EVENTS_PATH;
  try {
    const result = await postJsonWithRetry(config, url, { event });
    // Some older hosted databases have not yet accepted the desktop_app surface.
    // Retry only that known schema mismatch as agent metadata; prompt content is never sent.
    if (
      !result.ok &&
      event && event.surface === "desktop_app" &&
      result.status === 500 &&
      /events_surface_check/i.test(String(result.error || ""))
    ) {
      const fallback = await postJsonWithRetry(config, url, { event: { ...event, surface: "agent" } });
      if (fallback.ok) {
        return { ...fallback, compatibility_fallback: "desktop_app_to_agent" };
      }
    }
    return result;
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  }
}

function buildAgentDevicePayload(config, extra = {}) {
  return {
    device_id: config.device_id,
    device_label: config.device_label || "G.A.I.N Agent",
    department: config.department || null,
    component: "agent",
    browser: "agent",
    extension_id: "gain-agent",
    extension_version: `agent-${AGENT_VERSION}`,
    deployment_mode: config.deployment_mode || "hosted",
    status: "active",
    ...extra
  };
}

async function postEdge(config, path, body) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  const url = config.supabase_url.replace(/\/+$/, "") + path;
  try {
    return await postJsonWithRetry(config, url, body);
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  }
}

async function enrollDevice(config, extra = {}) {
  return postEdge(config, BOOTSTRAP_PATH, {
    org_api_key: config.org_api_key,
    reactivate: true,
    enrollment_intent: "reactivate",
    ...buildAgentDevicePayload(config, extra)
  });
}

async function sendHeartbeat(config, extra = {}) {
  return postEdge(config, HEARTBEAT_PATH, {
    org_api_key: config.org_api_key,
    ...buildAgentDevicePayload(config, extra)
  });
}

async function sendPresence(config, extra = {}) {
  return postEdge(config, PRESENCE_PATH, {
    org_api_key: config.org_api_key,
    ...buildAgentDevicePayload(config, extra)
  });
}

async function checkConnection(config) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  try {
    const result = await postEdge(config, BOOTSTRAP_PATH, {
      preview_only: true,
      org_api_key: config.org_api_key,
      device_id: config.device_id,
      device_label: config.device_label || "G.A.I.N Agent",
      component: "agent",
      browser: "agent",
      extension_version: "agent",
      deployment_mode: config.deployment_mode || "hosted"
    });
    if (!result.ok) return result;
    return {
      ok: true,
      status: result.status,
      attempts: result.attempts,
      org: result.org || (result.policy_bundle && result.policy_bundle.org) || null,
      license: result.policy_bundle && result.policy_bundle.license ? result.policy_bundle.license : null
    };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  }
}

async function fetchPolicyBundle(config) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  try {
    const result = await postEdge(config, BOOTSTRAP_PATH, {
      preview_only: true,
      org_api_key: config.org_api_key,
      device_id: config.device_id,
      device_label: config.device_label || "G.A.I.N Agent",
      component: "agent",
      browser: "agent",
      extension_version: "agent",
      deployment_mode: config.deployment_mode || "hosted"
    });
    if (!result.ok || !result.policy_bundle) {
      return result.ok
        ? { ok: false, status: result.status, error: "Policy bundle missing from backend response", attempts: result.attempts }
        : result;
    }
    return {
      ok: true,
      status: result.status,
      attempts: result.attempts,
      policy_bundle: result.policy_bundle,
      org: result.org || result.policy_bundle.org || null,
      license: result.policy_bundle.license || null
    };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  }
}

module.exports = {
  sendEvent,
  checkConnection,
  fetchPolicyBundle,
  enrollDevice,
  sendHeartbeat,
  sendPresence,
  postJsonWithRetry,
  isTransientBackendFailure,
  isConfigured,
  shouldContactBackend,
  EVENTS_PATH,
  BOOTSTRAP_PATH,
  HEARTBEAT_PATH,
  PRESENCE_PATH,
  AGENT_VERSION
};
