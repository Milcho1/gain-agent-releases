"use strict";

// Offline license verification for self-hosted / air-gapped deployments.
//
// A G.A.I.N. license is a signed, self-describing token. No phone-home needed:
//   GAINLIC1.<base64url(payload)>.<base64url(ed25519 signature)>
// CyberWardion signs it with a PRIVATE key (kept off this repo, see
// scripts/issue-license.js). The agent verifies it with the matching PUBLIC key
// (safe to ship). Because verification is signature-based, a license cannot be
// forged or edited without the private key, and it works fully offline.
//
// The public key is resolved from, in order:
//   1. an explicit pem passed to verifyLicense()
//   2. the GAIN_LICENSE_PUBLIC_KEY env var (literal PEM; \n allowed)
//   3. src/license/public-key.pem (commit your PUBLIC key here for a build)
// With no public key configured, verification fails closed.

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const LICENSE_PREFIX = "GAINLIC1";
// The embedded public key is optional for hosted customers. Keep the filename
// runtime-resolved so packaged builds do not treat an intentionally absent key
// as a missing required asset.
const PUBLIC_KEY_FILE = path.resolve(
  __dirname,
  process.env.GAIN_LICENSE_PUBLIC_KEY_FILE || ["public", "key.pem"].join("-")
);

function resolvePublicKeyPem(explicit) {
  if (explicit) return explicit;
  if (process.env.GAIN_LICENSE_PUBLIC_KEY) return process.env.GAIN_LICENSE_PUBLIC_KEY.replace(/\\n/g, "\n");
  try {
    const pem = fs.readFileSync(PUBLIC_KEY_FILE, "utf8").trim();
    if (pem) return pem;
  } catch (_error) { /* no embedded key */ }
  return null;
}

function parseLicense(licenseString) {
  const parts = String(licenseString || "").trim().split(".");
  if (parts.length !== 3 || parts[0] !== LICENSE_PREFIX) return null;
  try {
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    return { message: `${parts[0]}.${parts[1]}`, sigB64: parts[2], payload };
  } catch (_error) {
    return null;
  }
}

// Sign a license payload (used by scripts/issue-license.js with the PRIVATE key).
function signLicense(payload, privateKeyPem) {
  const body = { v: 1, iat: Date.now(), ...payload };
  const payloadB64 = Buffer.from(JSON.stringify(body), "utf8").toString("base64url");
  const message = `${LICENSE_PREFIX}.${payloadB64}`;
  const signature = crypto.sign(null, Buffer.from(message, "utf8"), crypto.createPrivateKey(privateKeyPem));
  return `${message}.${signature.toString("base64url")}`;
}

function validatePayload(payload, now = Date.now()) {
  if (!payload || typeof payload !== "object") return { valid: false, reason: "missing payload", payload: null };

  const required = ["org_id", "customer", "plan", "allowed_updates_until"];
  const missing = required.filter((field) => payload[field] === undefined || payload[field] === null || payload[field] === "");
  if (missing.length) return { valid: false, reason: `missing required claim(s): ${missing.join(", ")}`, payload };

  const maxSeats = Number(payload.max_seats ?? payload.seats);
  if (!Number.isFinite(maxSeats) || maxSeats < 1) {
    return { valid: false, reason: "max_seats must be at least 1", payload };
  }
  payload.max_seats = maxSeats;
  payload.seats = maxSeats;

  const lifetime = payload.lifetime === true;
  const exp = payload.exp === undefined || payload.exp === null ? null : Number(payload.exp);
  if (!lifetime && (!Number.isFinite(exp) || exp <= 0)) {
    return { valid: false, reason: "expiry is required unless lifetime is true", payload };
  }
  if (!lifetime && now > exp) {
    return { valid: false, reason: `expired ${new Date(exp).toISOString().slice(0, 10)}`, payload };
  }

  const updatesUntil = Number(payload.allowed_updates_until);
  if (!Number.isFinite(updatesUntil) || updatesUntil <= 0) {
    return { valid: false, reason: "allowed_updates_until must be a timestamp", payload };
  }

  return { valid: true, reason: "ok", payload };
}

// Verify a license string. Returns { valid, reason, payload }.
function verifyLicense(licenseString, options = {}) {
  const parsed = parseLicense(licenseString);
  if (!parsed) return { valid: false, reason: "malformed license", payload: null };

  const pem = resolvePublicKeyPem(options.publicKeyPem);
  if (!pem) return { valid: false, reason: "no public key configured", payload: parsed.payload };

  let signatureOk = false;
  try {
    signatureOk = crypto.verify(
      null,
      Buffer.from(parsed.message, "utf8"),
      crypto.createPublicKey(pem),
      Buffer.from(parsed.sigB64, "base64url")
    );
  } catch (error) {
    return { valid: false, reason: `signature check failed: ${error.message}`, payload: parsed.payload };
  }
  if (!signatureOk) return { valid: false, reason: "invalid signature (tampered or wrong key)", payload: parsed.payload };

  return validatePayload(parsed.payload, options.now || Date.now());
}

function enforceLicenseSeatCount(licenseResult, activeSeats) {
  if (!licenseResult || licenseResult.valid !== true) {
    return { ok: false, reason: licenseResult?.reason || "invalid license" };
  }
  const used = Math.max(0, Number(activeSeats || 0));
  const maxSeats = Number(licenseResult.payload?.max_seats ?? licenseResult.payload?.seats ?? 0);
  if (!Number.isFinite(maxSeats) || maxSeats < 1) return { ok: false, reason: "license has no usable seats" };
  if (used > maxSeats) return { ok: false, reason: `seat limit exceeded: ${used} of ${maxSeats}` };
  return { ok: true, used, max_seats: maxSeats };
}

module.exports = { verifyLicense, signLicense, parseLicense, enforceLicenseSeatCount, LICENSE_PREFIX };
