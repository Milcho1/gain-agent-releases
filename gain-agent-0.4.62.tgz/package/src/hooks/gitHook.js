"use strict";

// Git pre-commit hook (Phase 2). Scans STAGED files for secrets/credentials
// before they are committed, blocks the commit when a critical secret is found,
// and reports metadata only (surface: "agent"). File contents are never stored.
//
// Install: `gain-agent install-git-hook` writes .git/hooks/pre-commit ->
//   node <path>/gitHook.js   (exit 2 aborts the commit)

const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync, execSync } = require("child_process");
const { scanFileMetadata } = require("../scanners/scanFileMetadata");
const { decide } = require("../policies/decisionEngine");
const { applyBaseline } = require("../config/baseline");
const { isIgnored, loadGainignore, normalizePath } = require("../config/gainignore");
const { actionLine, blockNotificationLine } = require("../ui/messages");

function mergePatterns(findings) {
  const merged = new Map();
  for (const finding of findings || []) {
    for (const pattern of finding.patterns || []) {
      const key = pattern.policy_id ? `${pattern.type}:${pattern.policy_id}` : pattern.type;
      const current = merged.get(key);
      if (current) current.count += pattern.count || 1;
      else merged.set(key, {
        type: pattern.type,
        count: pattern.count || 1,
        risk: pattern.risk,
        ...(pattern.policy_id ? { policy_id: pattern.policy_id } : {})
      });
    }
  }
  return [...merged.values()];
}

function highestRisk(patterns) {
  const order = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };
  return (patterns || []).reduce((best, p) => (order[p.risk] || 0) > (order[best] || 0) ? p.risk : best, "info");
}

// Pure, testable. scanFile(path) -> [{ patterns, contentLength }]; defaults to
// the agent's metadata-only file scanner.
function scanStagedFiles(filePaths, {
  projectPolicy = null,
  orgPolicyBundle = null,
  enforcementMode = "visibility_only",
  baseline = null,
  gainignorePatterns = [],
  department = "",
  scanFile
} = {}) {
  const context = { domain: "git", toolName: "git", category: "developer_workflow", department };
  const scanner = scanFile || ((p) => {
    const result = scanFileMetadata(p, { scanOptions: { orgPolicyBundle, context } });
    const findings = (result.findings || []).map((finding) => ({ ...finding, file: p }));
    for (const file of result.unscannableFiles || result.unscannableDocuments || []) {
      findings.push({
        file: p,
        contentLength: 0,
        documentType: file.kind || null,
        patterns: [{ type: "document_scan_failed", count: 1, risk: "high", label: "Unscannable file" }]
      });
    }
    return findings;
  });
  const findings = [];
  let scannedFiles = 0;
  let skippedByGainignore = 0;
  const candidateFiles = [];

  for (const file of filePaths || []) {
    if (isIgnored(normalizePath(file), gainignorePatterns)) {
      skippedByGainignore += 1;
    } else {
      candidateFiles.push(file);
    }
  }

  for (const file of candidateFiles) {
    try {
      const result = scanner(file);
      if (Array.isArray(result)) {
        findings.push(...result.map((finding) => ({ ...finding, file: finding.file || file })));
        scannedFiles += 1;
      }
    } catch (_error) {
      // binary/unreadable/deleted file -> skip
    }
  }

  const baselineResult = applyBaseline(findings, baseline);
  const effectiveFindings = baselineResult.findings;
  const patterns = mergePatterns(effectiveFindings);
  const orgDecision = decide({
    patterns,
    projectPolicy,
    orgPolicyBundle,
    enforcementMode,
    context
  });

  let action = orgDecision.action;
  let reason = orgDecision.reason;
  let policyTriggered = orgDecision.policy_triggered;
  if (action === "allow") {
    reason = "No sensitive patterns in staged files.";
  } else if (action === "redact") {
    action = "block";
    reason = "Organization policy requires this sensitive data to be removed before commit.";
  } else if (action !== "block" && !orgPolicyBundle && patterns.length) {
    action = "log_only";
    reason = "Sensitive patterns detected in staged files.";
  }

  const severity = action === "block" && !patterns.length ? "high" : highestRisk(patterns);
  const event = {
    surface: "agent",
    event_type: "git_pre_commit",
    domain: "agent.local",
    tool_name: "git",
    category: "developer_workflow",
    action,
    enforcement_action: action,
    severity,
    content_length: 0,
    patterns_detected: patterns,
    policy_triggered: policyTriggered,
    detection_reason: `${reason} (${scannedFiles} staged file${scannedFiles === 1 ? "" : "s"} scanned` +
      (baselineResult.suppressed ? `, ${baselineResult.suppressed} baseline finding${baselineResult.suppressed === 1 ? "" : "s"} suppressed` : "") +
      `, ${skippedByGainignore} path${skippedByGainignore === 1 ? "" : "s"} skipped by .gainignore)`,
    created_at: new Date().toISOString()
  };
  const summaryLine = `G.A.I.N pre-commit: ${action} (${scannedFiles} staged file${scannedFiles === 1 ? "" : "s"} scanned` +
    (baselineResult.suppressed ? `, ${baselineResult.suppressed} baseline finding${baselineResult.suppressed === 1 ? "" : "s"} suppressed` : "") +
    `, ${skippedByGainignore} path${skippedByGainignore === 1 ? "" : "s"} skipped by .gainignore)`;

  return {
    blocked: action === "block",
    action,
    patterns,
    event,
    scannedFiles,
    skippedByGainignore,
    baselineSuppressed: baselineResult.suppressed,
    exitCode: action === "block" ? 2 : 0,
    notificationMessage: action === "block" ? blockNotificationLine(patterns, "Git") : null,
    message: action === "allow" ? null : actionLine({ action, reason }, patterns, { context: "committing" }),
    summaryLine
  };
}

function getStagedFiles(exec = execSync) {
  try {
    const out = exec("git diff --cached --name-only --diff-filter=ACM", { encoding: "utf8" });
    return String(out || "").split("\n").map((s) => s.trim()).filter(Boolean);
  } catch (_error) {
    return [];
  }
}

function globalHooksDir(homeDir = os.homedir()) {
  return path.join(homeDir, ".gain", "git-hooks");
}

function globalPreCommitPath(homeDir = os.homedir()) {
  return path.join(globalHooksDir(homeDir), "pre-commit");
}

function defaultCliPath() {
  return process.pkg ? process.execPath : path.resolve(__dirname, "..", "cli", "index.js");
}

function gainHookScript(cliPath) {
  const normalized = String(cliPath || "").replace(/\\/g, "/");
  const command = /\.js$/i.test(normalized)
    ? `node "${normalized}" git-hook`
    : `"${normalized}" git-hook`;
  return `#!/bin/sh\n# Installed by G.A.I.N Agent. Scans staged files for secrets before commit.\n${command}\n`;
}

function installRepoGitHook(repoRoot = process.cwd(), { cliPath = defaultCliPath() } = {}) {
  const gitDir = path.join(repoRoot, ".git");
  if (!fs.existsSync(gitDir)) {
    return { ok: false, reason: "not_git_repo", message: "Not a git repository (no .git directory). Run this from your repo root." };
  }
  const hooksDir = path.join(gitDir, "hooks");
  if (!fs.existsSync(hooksDir)) fs.mkdirSync(hooksDir, { recursive: true });
  const hookPath = path.join(hooksDir, "pre-commit");
  fs.writeFileSync(hookPath, gainHookScript(cliPath), { mode: 0o755 });
  return { ok: true, hookPath };
}

function currentGlobalHooksPath(execFile = execFileSync) {
  try {
    return String(execFile("git", ["config", "--global", "--get", "core.hooksPath"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }) || "").trim();
  } catch (_error) {
    return "";
  }
}

function installGlobalGitHook({
  homeDir = os.homedir(),
  cliPath = defaultCliPath(),
  force = false,
  execFile = execFileSync
} = {}) {
  const hooksDir = globalHooksDir(homeDir);
  const hookPath = globalPreCommitPath(homeDir);
  const existing = currentGlobalHooksPath(execFile);
  const existingResolved = existing ? path.resolve(homeDir, existing) : "";
  const targetResolved = path.resolve(hooksDir);

  if (existing && existingResolved !== targetResolved && !force) {
    return {
      ok: false,
      reason: "existing_global_hookspath",
      existing,
      message: `Git already has a global core.hooksPath (${existing}). Re-run with --force to replace it, or keep using repo-specific hooks.`
    };
  }

  fs.mkdirSync(hooksDir, { recursive: true });
  fs.writeFileSync(hookPath, gainHookScript(cliPath), { mode: 0o755 });
  execFile("git", ["config", "--global", "core.hooksPath", hooksDir], { stdio: "pipe" });
  return { ok: true, hooksDir, hookPath, replaced: Boolean(existing && existingResolved !== targetResolved) };
}

function uninstallGlobalGitHook({ homeDir = os.homedir(), execFile = execFileSync } = {}) {
  const hooksDir = globalHooksDir(homeDir);
  const existing = currentGlobalHooksPath(execFile);
  const existingResolved = existing ? path.resolve(homeDir, existing) : "";
  const targetResolved = path.resolve(hooksDir);
  if (existingResolved === targetResolved) {
    execFile("git", ["config", "--global", "--unset", "core.hooksPath"], { stdio: "pipe" });
  }
  return { ok: true, removedConfig: existingResolved === targetResolved, hooksDir };
}

// Runtime entry for the installed pre-commit hook.
async function runGitPreCommit(io = {}) {
  const stderr = io.stderr || process.stderr;
  const exit = io.exit || process.exit;
  const { loadConfig } = require("../config/loadPolicy");
  const { findProjectPolicy } = require("../config/projectConfig");
  const { getOrgPolicyBundle } = require("../config/orgPolicyCache");
  const { loadBaseline } = require("../config/baseline");
  const localQueue = require("../reporters/localQueue");
  const { sendEvent, isConfigured } = require("../reporters/supabaseEdgeClient");
  const { sendSiemEvent } = require("../reporters/siem");

  const config = loadConfig();
  if (config.active === false) {
    exit(0);
    return;
  }
  const projectResult = findProjectPolicy(process.cwd());
  const projectPolicy = projectResult && !projectResult.error ? projectResult.policy : null;
  const orgPolicyResult = await getOrgPolicyBundle(config, { allowFetch: false });
  const orgPolicyBundle = orgPolicyResult.ok ? orgPolicyResult.policy_bundle : null;

  const baselineResult = loadBaseline(process.cwd());
  const gainignoreResult = loadGainignore(process.cwd());
  const result = scanStagedFiles(getStagedFiles(), {
    projectPolicy,
    orgPolicyBundle,
    enforcementMode: config.enforcement_mode,
    baseline: baselineResult ? baselineResult.baseline : null,
    gainignorePatterns: gainignoreResult ? gainignoreResult.patterns : [],
    department: config.department
  });

  // Keep commits independent from dashboard and SIEM latency. This persists the
  // metadata event locally before delivery is attempted in the background.
  void (async () => {
    const event = { ...result.event, device_id: config.device_id };
    const queueId = localQueue.enqueue(event);
    if (isConfigured(config)) {
      const sent = await sendEvent(config, event);
      if (sent.ok) localQueue.remove(queueId);
    }
    await sendSiemEvent(config, event);
  })().catch(() => {});

  if (result.message) stderr.write(`${result.message}\n`);
  stderr.write(`${result.summaryLine}\n`);
  if (result.notificationMessage) {
    try {
      const notify = io.notify || require("../desktop/nativeNotify").notify;
      notify(result.notificationMessage, { title: "G.A.I.N" });
    } catch (_error) {
      // Native notification is best effort. The terminal message remains authoritative.
    }
  }
  exit(result.exitCode);
}

module.exports = {
  scanStagedFiles,
  getStagedFiles,
  runGitPreCommit,
  globalHooksDir,
  globalPreCommitPath,
  currentGlobalHooksPath,
  defaultCliPath,
  installRepoGitHook,
  installGlobalGitHook,
  uninstallGlobalGitHook,
  _deps: { scanFileMetadata }
};
