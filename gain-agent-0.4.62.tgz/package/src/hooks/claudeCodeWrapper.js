"use strict";

// Claude Code hook. Registered as UserPromptSubmit, PreToolUse, and PostToolUse;
// it scans the text Claude Code is about to act on, applies project policy
// (.gain/policy.json) + org enforcement mode, blocks the highest-risk secrets,
// and reports METADATA ONLY. Prompt/file content is never stored or transmitted.
//
// Hook contract (version-agnostic): block -> write reason to stderr + exit 2;
// allow -> exit 0. Detection reuses the same shared/patterns.js as the extension.

const { scanText } = require("../scanners/scanText");
const { scanFileMetadata } = require("../scanners/scanFileMetadata");
const { decide, HARD_BLOCK_TYPES } = require("../policies/decisionEngine");
const { actionLine, blockNotificationLine, patternLabel } = require("../ui/messages");
const fs = require("fs");
const path = require("path");

const RISK_ORDER = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };

const POST_TOOL_USE_EVENT = "PostToolUse";
const MAX_HOOK_TEXT_CHARS = 120000;
const MAX_PRE_TOOL_SCAN_FILES = 32;
const MAX_PRE_TOOL_SCAN_ENTRIES = 128;
const PRE_TOOL_FILE_READERS = new Set(["read", "grep", "glob"]);

function hookEventName(input) {
  return String(input && (input.hook_event_name || input.hookEventName || input.event_name) || "");
}

function appendTextLeaves(value, parts, budget) {
  if (budget.remaining <= 0 || value === null || value === undefined) return;
  if (typeof value === "string") {
    const chunk = value.slice(0, budget.remaining);
    if (chunk) parts.push(chunk);
    budget.remaining -= chunk.length;
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) appendTextLeaves(item, parts, budget);
    return;
  }
  if (typeof value !== "object") return;
  for (const key of ["command", "content", "new_string", "old_string", "file_text", "text", "query", "description", "output", "stdout", "stderr", "result", "message"]) {
    appendTextLeaves(value[key], parts, budget);
  }
}

// Gather text from the supported Claude Code hook input shapes. UserPromptSubmit
// provides input.prompt, PreToolUse provides tool_input, and PostToolUse can
// provide tool_input plus tool_response/tool_result. The text stays local and is
// capped before it reaches the detector.
function extractHookText(input) {
  if (!input || typeof input !== "object") return "";
  const parts = [];
  const budget = { remaining: MAX_HOOK_TEXT_CHARS };
  appendTextLeaves(input.prompt, parts, budget);
  appendTextLeaves(input.tool_input, parts, budget);
  if (hookEventName(input) === POST_TOOL_USE_EVENT) {
    appendTextLeaves(input.tool_response, parts, budget);
    appendTextLeaves(input.tool_result, parts, budget);
    appendTextLeaves(input.tool_output, parts, budget);
  }
  return parts.join("\n");
}

function hookToolName(input) {
  return String(input && (input.tool_name || input.toolName || input.name) || "").trim();
}

function preToolTargetPath(input) {
  if (hookEventName(input) !== "PreToolUse") return null;
  const toolName = hookToolName(input).toLowerCase();
  if (!PRE_TOOL_FILE_READERS.has(toolName)) return null;
  const toolInput = input && input.tool_input && typeof input.tool_input === "object" ? input.tool_input : {};
  const candidate = toolName === "read"
    ? (toolInput.file_path || toolInput.path)
    : (toolInput.path || toolInput.directory || toolInput.search_path);
  if (typeof candidate !== "string" || !candidate.trim() || /[*?{}]/.test(candidate)) return null;
  return candidate.trim();
}

function mergePatterns(patternGroups = []) {
  const grouped = new Map();
  for (const pattern of patternGroups.flat()) {
    if (!pattern || !pattern.type) continue;
    const key = `${pattern.type}:${pattern.policy_id || ""}`;
    const previous = grouped.get(key);
    grouped.set(key, previous
      ? { ...previous, count: Number(previous.count || 0) + Number(pattern.count || 1) }
      : { ...pattern, count: Number(pattern.count || 1) });
  }
  return [...grouped.values()];
}

// PreToolUse has the path before Claude Code reads it. This scanner is bounded
// for Grep/Glob directories and returns metadata only; paths and file contents
// deliberately stay out of the event payload.
function scanPreToolFile(input, options = {}) {
  const requestedPath = preToolTargetPath(input);
  if (!requestedPath) return null;
  const cwd = path.resolve(options.cwd || input.cwd || process.cwd());
  const targetPath = path.resolve(cwd, requestedPath);
  const toolName = hookToolName(input) || "unknown";
  try {
    if (!fs.existsSync(targetPath)) {
      return { toolName, status: "unavailable", reason: "path_not_found", scannedFiles: 0, scannedCharacters: 0, patterns: [] };
    }
    const scan = scanFileMetadata(targetPath, {
      maxFiles: options.maxFiles || MAX_PRE_TOOL_SCAN_FILES,
      maxEntries: options.maxEntries || MAX_PRE_TOOL_SCAN_ENTRIES,
      scanOptions: options.scanOptions
    });
    const patterns = mergePatterns(scan.findings.map((finding) => finding.patterns));
    const scannedCharacters = scan.findings.reduce((sum, finding) => sum + Number(finding.contentLength || 0), 0);
    const unscannable = scan.unscannableFiles.length > 0 || scan.limitReached;
    return {
      toolName,
      status: unscannable ? "partial" : "scanned",
      reason: scan.limitReached ? "scan_limit" : (scan.unscannableFiles[0] && scan.unscannableFiles[0].reason) || null,
      scannedFiles: scan.scannedFiles,
      scannedCharacters,
      unscannableFiles: scan.unscannableFiles.length,
      patterns
    };
  } catch (_error) {
    // PreToolUse must preserve direct tool behavior if a local scan itself is
    // unavailable. Doctor and metadata identify the issue without exposing it.
    return { toolName, status: "unavailable", reason: "scan_error", scannedFiles: 0, scannedCharacters: 0, patterns: [] };
  }
}

function strongestPattern(patterns = []) {
  return [...patterns].sort((a, b) => (RISK_ORDER[b.risk || "info"] || 0) - (RISK_ORDER[a.risk || "info"] || 0))[0] || null;
}

function articleFor(label) {
  return /^(api|aws|iban|ip|email|internal|environment)/i.test(String(label || "")) ? "an" : "a";
}

function claudeBlockMessage(patterns = []) {
  const pattern = strongestPattern(patterns);
  if (!pattern) return "G.A.I.N blocked this. Remove the sensitive data before sending.";
  const label = patternLabel(pattern.type);
  return `G.A.I.N blocked this: it contains ${articleFor(label)} ${label}. Remove it before sending.`;
}

function hasHardBlockPattern(patterns = []) {
  return (patterns || []).some((pattern) => HARD_BLOCK_TYPES.has(pattern.type));
}

function actionForClaudeHook(decision, patterns = [], options = {}) {
  const action = String(decision && decision.action || "allow");
  // Claude hooks can reject a prompt but cannot replace its text. Redaction is
  // therefore delegated to the local proxy only when that proxy is reachable.
  // A broken or not-yet-restarted proxy must never turn a Redact policy into an
  // unexpected block: warn and let the developer continue unchanged instead.
  if (hasHardBlockPattern(patterns)) return "block";
  if (action === "block") return "block";
  if (action === "redact") return options.proxyServiceActive ? "log_only" : "warn";
  return action;
}

function redactionUnavailableMessage(patterns = [], options = {}) {
  const summary = (patterns || []).length ? ` (${(patterns || []).map((pattern) => patternLabel(pattern.type)).filter(Boolean).join(", ")})` : "";
  const subject = options.fileRead ? "the file Claude Code is about to read" : "sensitive data";
  return `G.A.I.N detected sensitive data in ${subject}, but local redaction is unavailable because the proxy is not active. ` +
    `This ${options.fileRead ? "read" : "prompt"} was allowed unchanged. Restart Claude Code after running \`gain-agent proxy --service install\` to enable Redact.` + summary;
}

// Pure decision for a Claude Code hook event. No I/O, fully testable.
function inactiveHookResult() {
  return {
    decision: {
      action: "allow",
      policy_action: "allow",
      severity: "info",
      policy_triggered: "agent_inactive",
      reason: "G.A.I.N Agent is disabled locally."
    },
    patterns: [],
    event: null,
    exitCode: 0,
    notificationMessage: null,
    message: null
  };
}

function runClaudeCodeHook({ input, projectPolicy = null, orgPolicyBundle = null, enforcementMode = "visibility_only", proxyServiceActive = false, agentActive = true, department = "", preToolMaxFiles = MAX_PRE_TOOL_SCAN_FILES } = {}) {
  if (agentActive === false) return inactiveHookResult();

  const text = extractHookText(input);
  const postToolObservation = hookEventName(input) === POST_TOOL_USE_EVENT;
  const preToolFile = scanPreToolFile(input, {
    maxFiles: preToolMaxFiles,
    maxEntries: Math.max(MAX_PRE_TOOL_SCAN_ENTRIES, preToolMaxFiles * 4),
    scanOptions: { orgPolicyBundle, context: { domain: "claude-code", toolName: "Claude Code", category: "coding_agent", department } }
  });
  const context = { domain: "claude-code", toolName: "Claude Code", category: "coding_agent", department };
  const patterns = mergePatterns([scanText(text, { orgPolicyBundle, context }), preToolFile ? preToolFile.patterns : []]);
  const decision = decide({
    patterns,
    projectPolicy,
    orgPolicyBundle,
    enforcementMode,
    context
  });

  const requestedHookAction = actionForClaudeHook(decision, patterns, { proxyServiceActive });
  // PostToolUse runs after Claude has executed a tool. It cannot safely alter or
  // reject output that may already be entering Claude's context, so it records a
  // metadata-only observation and always returns success. Prevention is handled
  // before execution by UserPromptSubmit and PreToolUse.
  const hookAction = postToolObservation && requestedHookAction !== "allow" ? "log_only" : requestedHookAction;
  const proxyHandlesRedaction = proxyServiceActive && decision.action === "redact" && hookAction === "log_only";
  const redactionUnavailable = !proxyServiceActive && decision.action === "redact" && hookAction === "warn";
  const event = {
    surface: "agent",
    event_type: preToolFile ? "claude_code_pretool_file_scan" : "claude_code_hook",
    domain: "agent.local",
    tool_name: "claude-code",
    category: "coding_agent",
    action: hookAction,
    enforcement_action: hookAction,
    requested_enforcement_action: requestedHookAction,
    policy_action: decision.action,
    severity: decision.severity,
    content_length: text.length,
    file_scan: preToolFile ? {
      tool: preToolFile.toolName,
      status: preToolFile.status,
      reason: preToolFile.reason,
      scanned_files: preToolFile.scannedFiles,
      scanned_characters: preToolFile.scannedCharacters,
      unscannable_files: preToolFile.unscannableFiles || 0
    } : null,
    patterns_detected: patterns,
    policy_triggered: proxyHandlesRedaction ? "proxy_service_handles_redaction" : decision.policy_triggered,
    detection_reason: decision.reason,
    redaction_unavailable: redactionUnavailable,
    pretool_file_scan_unavailable: Boolean(preToolFile && preToolFile.status !== "scanned"),
    post_tool_observation: postToolObservation,
    created_at: new Date().toISOString()
  };

  const blocked = !postToolObservation && hookAction === "block";
  return {
    decision: { ...decision, action: hookAction, policy_action: decision.action },
    patterns,
    event,
    exitCode: blocked ? 2 : 0,
    notificationMessage: blocked ? blockNotificationLine(patterns, "Claude Code") : null,
    message: preToolFile && preToolFile.status !== "scanned" && !blocked
      ? "G.A.I.N could not fully scan the file path before Claude Code read it. The tool was allowed unchanged to keep work moving; review `gain-agent doctor` before relying on file-read protection."
      : postToolObservation && patterns.length
      ? "G.A.I.N detected sensitive data in Claude Code tool output. The result was recorded as metadata only; PostToolUse does not block output that has already been returned."
      : blocked
      ? claudeBlockMessage(patterns)
      : (redactionUnavailable
        ? redactionUnavailableMessage(patterns, { fileRead: Boolean(preToolFile) })
        : (hookAction === "warn" ? actionLine(decision, patterns, { context: "sending to Claude Code" }) : null))
  };
}

// Entry point when registered as a Claude Code hook. Reads the hook JSON from
// stdin, applies policy, reports metadata (best effort), and emits the decision.
async function interceptClaudeCode(io = {}) {
  const stdin = io.stdin || process.stdin;
  const stderr = io.stderr || process.stderr;
  const exit = io.exit || process.exit;

  const { loadConfig } = require("../config/loadPolicy");
  const { findProjectPolicy } = require("../config/projectConfig");
  const { getOrgPolicyBundle } = require("../config/orgPolicyCache");
  const localQueue = require("../reporters/localQueue");
  const { sendEvent, isConfigured } = require("../reporters/supabaseEdgeClient");
  const { isLocalProxyRoutingActive } = require("../system/proxyService");

  const raw = await readStream(stdin);
  let input = {};
  try { input = raw ? JSON.parse(raw) : {}; } catch (_error) { input = {}; }

  const config = loadConfig();
  if (config.active === false) {
    exit(0);
    return;
  }
  const projectResult = findProjectPolicy(input.cwd || process.cwd());
  const projectPolicy = projectResult && !projectResult.error ? projectResult.policy : null;
  const orgPolicyResult = await getOrgPolicyBundle(config, { allowFetch: false });
  const orgPolicyBundle = orgPolicyResult.ok ? orgPolicyResult.policy_bundle : null;
  const proxyRoutingActive = typeof io.proxyRoutingActive === "function"
    ? await io.proxyRoutingActive(config)
    : await isLocalProxyRoutingActive();

  const result = runClaudeCodeHook({
    input,
    projectPolicy,
    orgPolicyBundle,
    enforcementMode: config.enforcement_mode,
    proxyServiceActive: proxyRoutingActive,
    agentActive: config.active !== false,
    department: config.department
  });

  // The hook must return immediately. Queue locally first, then deliver in the
  // background so a dashboard outage cannot hold up Claude Code.
  if (result.event) {
    void (async () => {
      const event = { ...result.event, device_id: config.device_id };
      const queueId = localQueue.enqueue(event);
      if (isConfigured(config)) {
        const sent = await sendEvent(config, event);
        if (sent.ok) localQueue.remove(queueId);
      }
    })().catch(() => {
      // The durable local queue is already written. Never break the hook.
    });
  }

  if (result.message) stderr.write(`${result.message}\n`);
  if (result.notificationMessage) {
    try {
      const notify = io.notify || require("../desktop/nativeNotify").notify;
      notify(result.notificationMessage, { title: "G.A.I.N" });
    } catch (_error) {
      // Native notification is best effort. The terminal message remains authoritative.
    }
  }
  exit(result.exitCode);
}

function readStream(stream) {
  return new Promise((resolve) => {
    if (!stream || typeof stream.on !== "function") return resolve("");
    let data = "";
    if (stream.setEncoding) stream.setEncoding("utf8");
    stream.on("data", (chunk) => { data += chunk; });
    stream.on("end", () => resolve(data));
    stream.on("error", () => resolve(data));
  });
}

module.exports = {
  interceptClaudeCode,
  runClaudeCodeHook,
  extractHookText,
  preToolTargetPath,
  scanPreToolFile,
  claudeBlockMessage,
  actionForClaudeHook,
  redactionUnavailableMessage,
  POST_TOOL_USE_EVENT,
  MAX_PRE_TOOL_SCAN_FILES
};
