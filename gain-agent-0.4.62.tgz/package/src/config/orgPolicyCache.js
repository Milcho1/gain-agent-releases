"use strict";

const fs = require("fs");
const path = require("path");
const { configDir, writeJsonFileAtomically } = require("./loadPolicy");
const { fetchPolicyBundle, isConfigured } = require("../reporters/supabaseEdgeClient");

const CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const LIVE_POLICY_MEMORY_MAX_AGE_MS = 15 * 1000;
const HOT_PATH_POLICY_CACHE_MAX_AGE_MS = 2 * 60 * 60 * 1000;
const DISK_POLICY_RECHECK_MS = 1000;
let memoryPolicyCache = null;
let diskPolicyCache = null;
const pendingPolicyFetches = new Map();

function cachePath() {
  return path.join(configDir(), "policy-cache.json");
}

function resultFromDiskCache(raw, now = Date.now()) {
  const cachedAt = Number(raw.cached_at_ms || 0);
  const ageMs = cachedAt ? now - cachedAt : Number.POSITIVE_INFINITY;
  if (!raw.policy_bundle || typeof raw.policy_bundle !== "object" || Array.isArray(raw.policy_bundle) || !Array.isArray(raw.policy_bundle.policies)) {
    return { ok: false, reason: "invalid_bundle" };
  }
  if (ageMs < 0 || ageMs > CACHE_MAX_AGE_MS) return { ok: false, reason: "stale_or_missing" };
  return {
    ok: true,
    source: "cache",
    ageMs,
    bundleVersion: raw.bundle_version || raw.policy_bundle.bundle_version || null,
    policy_bundle: raw.policy_bundle
  };
}

function clearDiskPolicyCache() {
  diskPolicyCache = null;
}

function readPolicyCache(now = Date.now()) {
  const filePath = cachePath();
  if (diskPolicyCache && diskPolicyCache.path === filePath && now - diskPolicyCache.checkedAt < DISK_POLICY_RECHECK_MS) {
    return resultFromDiskCache(diskPolicyCache.raw, now);
  }
  try {
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8"));
    const result = resultFromDiskCache(raw, now);
    if (result.ok) diskPolicyCache = { path: filePath, checkedAt: now, raw };
    else clearDiskPolicyCache();
    return result;
  } catch (_error) {
    clearDiskPolicyCache();
    return { ok: false, reason: "missing" };
  }
}

function writePolicyCache(policyBundle) {
  if (!policyBundle || typeof policyBundle !== "object" || !Array.isArray(policyBundle.policies)) return false;
  const raw = {
    cached_at: new Date().toISOString(),
    cached_at_ms: Date.now(),
    bundle_version: policyBundle.bundle_version || null,
    policy_bundle: policyBundle
  };
  writeJsonFileAtomically(cachePath(), raw);
  diskPolicyCache = { path: cachePath(), checkedAt: raw.cached_at_ms, raw };
  return true;
}

function policyCacheKey(config = {}) {
  return [
    config.supabase_url || "",
    config.org_api_key || "",
    config.device_id || ""
  ].join("|");
}

function readMemoryPolicyCache(config, now = Date.now()) {
  if (!memoryPolicyCache) return { ok: false, reason: "missing" };
  if (memoryPolicyCache.key !== policyCacheKey(config)) return { ok: false, reason: "different_device" };
  const ageMs = now - Number(memoryPolicyCache.cached_at_ms || 0);
  if (!memoryPolicyCache.policy_bundle || ageMs < 0 || ageMs > LIVE_POLICY_MEMORY_MAX_AGE_MS) {
    return { ok: false, reason: "stale_or_missing" };
  }
  return { ok: true, source: "memory", ageMs, policy_bundle: memoryPolicyCache.policy_bundle };
}

function writeMemoryPolicyCache(config, policyBundle, now = Date.now()) {
  if (!policyBundle || typeof policyBundle !== "object") return false;
  memoryPolicyCache = {
    key: policyCacheKey(config),
    cached_at_ms: now,
    policy_bundle: policyBundle
  };
  return true;
}

function clearMemoryPolicyCache() {
  memoryPolicyCache = null;
}

function describePolicyCache(now = Date.now()) {
  const cached = readPolicyCache(now);
  if (!cached.ok) return cached;
  return {
    ...cached,
    freshForHotPath: cached.ageMs <= HOT_PATH_POLICY_CACHE_MAX_AGE_MS,
    ageSeconds: Math.floor(cached.ageMs / 1000)
  };
}

async function fetchAndCachePolicyBundle(config, now) {
  const key = policyCacheKey(config);
  const pending = pendingPolicyFetches.get(key);
  if (pending) return pending;

  const request = (async () => {
    const live = await fetchPolicyBundle(config);
    if (live.ok && live.policy_bundle) {
      if (!Array.isArray(live.policy_bundle.policies)) {
        const cached = readPolicyCache(now);
        if (cached.ok) return { ...cached, liveError: "invalid_policy_bundle" };
        return { ok: false, source: "none", reason: "invalid_policy_bundle" };
      }
      try {
        if (!writePolicyCache(live.policy_bundle)) {
          const cached = readPolicyCache(now);
          if (cached.ok) return { ...cached, liveError: "invalid_policy_bundle" };
          return { ok: false, source: "none", reason: "invalid_policy_bundle" };
        }
      } catch (error) {
        // A locked or read-only cache must not weaken this running process. Keep
        // the live bundle in memory and surface the persistence fault to doctor.
        writeMemoryPolicyCache(config, live.policy_bundle, now);
        return {
          ok: true,
          source: "live_memory_only",
          cacheError: error.message,
          policy_bundle: live.policy_bundle
        };
      }
      writeMemoryPolicyCache(config, live.policy_bundle, now);
      return { ok: true, source: "live", policy_bundle: live.policy_bundle };
    }
    const cached = readPolicyCache(now);
    if (cached.ok) return { ...cached, liveError: live.error || live.reason || "fetch_failed" };
    return { ok: false, source: "none", reason: live.error || live.reason || "fetch_failed" };
  })();

  pendingPolicyFetches.set(key, request);
  try {
    return await request;
  } finally {
    if (pendingPolicyFetches.get(key) === request) pendingPolicyFetches.delete(key);
  }
}

async function getOrgPolicyBundle(config, options = {}) {
  const { allowFetch = true, forceRefresh = false, preferCacheMaxAgeMs = 0, now = Date.now() } = options;
  if (allowFetch && isConfigured(config)) {
    if (!forceRefresh) {
      const memory = readMemoryPolicyCache(config, now);
      if (memory.ok) return memory;
      if (preferCacheMaxAgeMs > 0) {
        const cached = readPolicyCache(now);
        if (cached.ok && cached.ageMs <= preferCacheMaxAgeMs) return cached;
      }
    }
    return fetchAndCachePolicyBundle(config, now);
  }
  return readPolicyCache(now);
}

module.exports = {
  cachePath,
  readPolicyCache,
  writePolicyCache,
  clearDiskPolicyCache,
  readMemoryPolicyCache,
  clearMemoryPolicyCache,
  describePolicyCache,
  fetchAndCachePolicyBundle,
  getOrgPolicyBundle,
  CACHE_MAX_AGE_MS,
  LIVE_POLICY_MEMORY_MAX_AGE_MS,
  HOT_PATH_POLICY_CACHE_MAX_AGE_MS,
  DISK_POLICY_RECHECK_MS
};
