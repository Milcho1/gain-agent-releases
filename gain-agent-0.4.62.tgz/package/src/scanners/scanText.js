"use strict";

const { detectSensitivePatterns } = require("./patterns");
const { detectCustomPolicyPatterns } = require("../policies/customVocabulary");

// The proxy accepts requests up to 8 MiB. Scan the whole accepted request so a
// secret in the middle of a long incident dump is not silently skipped. File
// scanning has its own tighter size limits before it calls this module.
const MAX_SCAN_CHARS = 8 * 1024 * 1024;

// Returns grouped pattern metadata only: [{ type, count, risk, label }].
// Never returns the matched text itself.
function scanText(text, options = {}) {
  const value = String(text || "");
  const scanValue = value.length > MAX_SCAN_CHARS
    ? `${value.slice(0, Math.floor(MAX_SCAN_CHARS / 2))}\n${value.slice(-Math.ceil(MAX_SCAN_CHARS / 2))}`
    : value;
  const patterns = detectSensitivePatterns(scanValue);
  patterns.push(...detectCustomPolicyPatterns(scanValue, options.orgPolicyBundle, options.context));
  if (value.length > 20000) {
    patterns.push({ type: "large_paste", count: 1, risk: "medium", label: "Large content" });
  }
  return patterns;
}

module.exports = { scanText, MAX_SCAN_CHARS };
