"use strict";

// Walks a file or directory and scans text files for sensitive patterns.
// Returns metadata only: file paths (relative), char counts, and grouped
// pattern types. File CONTENTS and matched substrings are never returned or stored.

const fs = require("fs");
const path = require("path");
const { scanText } = require("./scanText");
const { DOCUMENT_EXTENSIONS, extractDocumentText } = require("./documentText");
const { isIgnored, normalizePath } = require("../config/gainignore");

const IGNORED_DIRS = new Set([
  ".git", "node_modules", "dist", "build", ".next", ".cache",
  "coverage", ".gain", ".venv", "venv", "__pycache__", ".idea", ".vscode"
]);

const BINARY_EXTENSIONS = new Set([
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".svg",
  ".zip", ".gz", ".tar", ".rar", ".7z", ".mp4", ".mov", ".mp3",
  ".wav", ".woff", ".woff2", ".ttf", ".eot", ".class", ".jar", ".exe",
  ".dll", ".so", ".dylib", ".bin", ".lock", ".min.js", ".map"
]);

const MAX_FILE_BYTES = 1.5 * 1024 * 1024;
const MAX_DOCUMENT_BYTES = 8 * 1024 * 1024;

function isProbablyBinary(buffer) {
  const sample = buffer.subarray(0, 4096);
  for (let i = 0; i < sample.length; i += 1) {
    if (sample[i] === 0) return true;
  }
  return false;
}

function textEncodingFor(buffer) {
  const sample = Buffer.from(buffer || []).subarray(0, 4096);
  if (sample.length >= 3 && sample[0] === 0xef && sample[1] === 0xbb && sample[2] === 0xbf) return "utf8_bom";
  if (sample.length >= 2 && sample[0] === 0xff && sample[1] === 0xfe) return "utf16le";
  if (sample.length >= 2 && sample[0] === 0xfe && sample[1] === 0xff) return "utf16be";

  let evenNulls = 0;
  let oddNulls = 0;
  const pairCount = Math.floor(sample.length / 2);
  for (let i = 0; i < pairCount * 2; i += 2) {
    if (sample[i] === 0) evenNulls += 1;
    if (sample[i + 1] === 0) oddNulls += 1;
  }
  if (pairCount >= 4 && oddNulls >= 3 && oddNulls >= evenNulls * 3) return "utf16le";
  if (pairCount >= 4 && evenNulls >= 3 && evenNulls >= oddNulls * 3) return "utf16be";
  return "utf8";
}

function decodeTextBuffer(buffer, encoding) {
  const value = Buffer.from(buffer || []);
  if (encoding === "utf8_bom") return value.subarray(3).toString("utf8");
  if (encoding === "utf16le") {
    const offset = value.length >= 2 && value[0] === 0xff && value[1] === 0xfe ? 2 : 0;
    return value.subarray(offset, offset + ((value.length - offset) & ~1)).toString("utf16le");
  }
  if (encoding === "utf16be") {
    const offset = value.length >= 2 && value[0] === 0xfe && value[1] === 0xff ? 2 : 0;
    const source = value.subarray(offset, offset + ((value.length - offset) & ~1));
    const swapped = Buffer.allocUnsafe(source.length);
    for (let i = 0; i < source.length; i += 2) {
      swapped[i] = source[i + 1];
      swapped[i + 1] = source[i];
    }
    return swapped.toString("utf16le");
  }
  return value.toString("utf8");
}

function readBinaryProbe(filePath) {
  const fd = fs.openSync(filePath, "r");
  try {
    const probe = Buffer.alloc(4096);
    const bytesRead = fs.readSync(fd, probe, 0, probe.length, 0);
    return probe.subarray(0, bytesRead);
  } finally {
    fs.closeSync(fd);
  }
}

function shouldSkipPath(relativePath, disabledPaths) {
  if (!Array.isArray(disabledPaths)) return false;
  return disabledPaths.some((needle) => needle && relativePath.includes(needle));
}

function relativeFile(baseDir, absolutePath) {
  return path.relative(baseDir, absolutePath) || path.basename(absolutePath);
}

function readTextSample(filePath, size, encoding) {
  if (size <= MAX_FILE_BYTES) {
    return { text: decodeTextBuffer(fs.readFileSync(filePath), encoding), truncated: false };
  }

  const fd = fs.openSync(filePath, "r");
  try {
    const half = Math.floor(MAX_FILE_BYTES / 2);
    const first = Buffer.alloc(half);
    const firstRead = fs.readSync(fd, first, 0, half, 0);
    const secondSize = Math.min(half, Math.max(0, size - half));
    const second = Buffer.alloc(secondSize);
    const secondOffset = Math.max(0, size - secondSize - (encoding.startsWith("utf16") ? (size - secondSize) % 2 : 0));
    const secondRead = fs.readSync(fd, second, 0, secondSize, secondOffset);
    return {
      text: `${decodeTextBuffer(first.subarray(0, firstRead), encoding)}\n${decodeTextBuffer(second.subarray(0, secondRead), encoding)}`,
      truncated: true
    };
  } finally {
    fs.closeSync(fd);
  }
}

function collectFiles(root, disabledPaths, ignorePatterns, ignoreRoot, options = {}) {
  const results = [];
  const skippedFiles = [];
  const stack = [root];
  const maxFiles = Number.isFinite(Number(options.maxFiles)) && Number(options.maxFiles) > 0
    ? Math.floor(Number(options.maxFiles))
    : null;
  const maxEntries = Number.isFinite(Number(options.maxEntries)) && Number(options.maxEntries) > 0
    ? Math.floor(Number(options.maxEntries))
    : null;
  let skippedByGainignore = 0;
  let limitReached = false;
  let inspectedEntries = 0;

  while (stack.length) {
    const current = stack.pop();
    if (maxEntries !== null && inspectedEntries >= maxEntries) {
      skippedFiles.push({ file: ".", reason: "scan_limit", maxFiles, maxEntries });
      limitReached = true;
      break;
    }
    inspectedEntries += 1;
    let stat;
    try {
      stat = fs.lstatSync(current);
    } catch (_error) {
      continue;
    }
    if (stat.isSymbolicLink()) continue;

    if (stat.isDirectory()) {
      const base = path.basename(current);
      if (IGNORED_DIRS.has(base)) continue;
      let entries = [];
      try {
        entries = fs.readdirSync(current);
      } catch (_error) {
        continue;
      }
      for (const entry of entries) stack.push(path.join(current, entry));
      continue;
    }

    if (stat.isFile()) {
      const ext = path.extname(current).toLowerCase();
      const isDocument = DOCUMENT_EXTENSIONS.has(ext);
      if (BINARY_EXTENSIONS.has(ext)) {
        skippedFiles.push({ file: relativeFile(root, current), reason: "binary_extension" });
        continue;
      }
      const ignoreRel = normalizePath(path.relative(ignoreRoot || root, current));
      if (isIgnored(ignoreRel, ignorePatterns)) {
        skippedByGainignore += 1;
        continue;
      }
      if (maxFiles !== null && results.length >= maxFiles) {
        // A caller that needs a bounded hot-path scan must be told that the
        // directory was not fully covered. Do not silently treat its unseen
        // files as clean.
        skippedFiles.push({ file: relativeFile(root, current), reason: "scan_limit", maxFiles });
        limitReached = true;
        break;
      }
      results.push({ absolute: current, size: stat.size });
    }
  }

  const files = results.filter((file) => {
    const rel = path.relative(root, file.absolute) || path.basename(file.absolute);
    return !shouldSkipPath(rel, disabledPaths);
  });
  return { files, skippedByGainignore, skippedFiles, limitReached, maxFiles, maxEntries, inspectedEntries };
}

// Returns: { root, scannedFiles, skippedByGainignore, findings: [{ file, contentLength, patterns }] }
function scanFileMetadata(targetPath, options = {}) {
  const disabledPaths = options.disabledPaths || [];
  const ignorePatterns = options.ignorePatterns || [];
  const ignoreRoot = options.ignoreRoot ? path.resolve(options.ignoreRoot) : null;
  const root = path.resolve(targetPath);

  let rootStat;
  try {
    rootStat = fs.statSync(root);
  } catch (error) {
    throw new Error(`Path not found: ${root}`);
  }

  const baseDir = rootStat.isDirectory() ? root : path.dirname(root);
  let skippedByGainignore = 0;
  let preSkippedFiles = [];
  let files = [];
  let limitReached = false;
  let maxFiles = null;
  let maxEntries = null;
  if (rootStat.isDirectory()) {
    const collected = collectFiles(root, disabledPaths, ignorePatterns, ignoreRoot || root, {
      maxFiles: options.maxFiles,
      maxEntries: options.maxEntries
    });
    files = collected.files;
    skippedByGainignore = collected.skippedByGainignore;
    preSkippedFiles = collected.skippedFiles;
    limitReached = collected.limitReached;
    maxFiles = collected.maxFiles;
    maxEntries = collected.maxEntries;
  } else {
    const ignoreRel = normalizePath(path.relative(ignoreRoot || baseDir, root));
    if (isIgnored(ignoreRel, ignorePatterns)) {
      skippedByGainignore = 1;
      files = [];
    } else {
      files = [{ absolute: root, size: rootStat.size }];
    }
  }

  const findings = [];
  const skippedDocuments = [];
  const unscannableDocuments = [];
  const skippedFiles = [...preSkippedFiles];
  const unscannableFiles = [...preSkippedFiles];
  const truncatedFiles = [];
  let scannedFiles = 0;

  for (const file of files) {
    let content;
    let documentInfo = null;
    try {
      const ext = path.extname(file.absolute).toLowerCase();
      // collectFiles handles this for directory scans. Keep the same explicit
      // unsafe result for callers that scan one archive/image path directly.
      if (BINARY_EXTENSIONS.has(ext)) {
        const detail = { file: relativeFile(baseDir, file.absolute), reason: "binary_extension" };
        skippedFiles.push(detail);
        unscannableFiles.push(detail);
        continue;
      }
      if (DOCUMENT_EXTENSIONS.has(ext)) {
        if (file.size > MAX_DOCUMENT_BYTES) {
          const detail = {
            file: relativeFile(baseDir, file.absolute),
            reason: "document_too_large",
            size: file.size,
            maxBytes: MAX_DOCUMENT_BYTES
          };
          skippedFiles.push(detail);
          unscannableDocuments.push(detail);
          unscannableFiles.push(detail);
          continue;
        }
        documentInfo = extractDocumentText(file.absolute, options);
        if (!documentInfo.ok) {
          const detail = {
            file: relativeFile(baseDir, file.absolute),
            kind: documentInfo.kind,
            reason: documentInfo.reason
          };
          skippedDocuments.push(detail);
          unscannableDocuments.push(detail);
          unscannableFiles.push(detail);
          continue;
        }
        content = documentInfo.text;
      } else {
        const probe = readBinaryProbe(file.absolute);
        const encoding = textEncodingFor(probe);
        if (isProbablyBinary(probe) && encoding === "utf8") {
          const detail = { file: relativeFile(baseDir, file.absolute), reason: "binary_content" };
          skippedFiles.push(detail);
          unscannableFiles.push(detail);
          continue;
        }
        const sample = readTextSample(file.absolute, file.size, encoding);
        content = sample.text;
        if (sample.truncated) {
          truncatedFiles.push({
            file: relativeFile(baseDir, file.absolute),
            reason: "text_file_sampled",
            size: file.size,
            scannedBytes: Math.min(file.size, MAX_FILE_BYTES)
          });
        }
      }
    } catch (_error) {
      const detail = {
        file: relativeFile(baseDir, file.absolute),
        reason: "read_failed"
      };
      skippedFiles.push(detail);
      unscannableFiles.push(detail);
      continue;
    }
    scannedFiles += 1;

    const patterns = scanText(content, options.scanOptions);
    if (patterns.length) {
      findings.push({
        file: relativeFile(baseDir, file.absolute),
        contentLength: content.length,
        documentType: documentInfo?.kind || null,
        patterns
      });
    }
    // content goes out of scope here; never stored or reported.
  }

  return {
    root: baseDir,
    scannedFiles,
    skippedByGainignore,
    skippedDocuments,
    unscannableDocuments,
    unscannableFiles,
    skippedFiles,
    truncatedFiles,
    findings,
    limitReached,
    maxFiles,
    maxEntries
  };
}

module.exports = { scanFileMetadata, IGNORED_DIRS, BINARY_EXTENSIONS, MAX_DOCUMENT_BYTES, MAX_FILE_BYTES, _internal: { textEncodingFor, decodeTextBuffer } };
