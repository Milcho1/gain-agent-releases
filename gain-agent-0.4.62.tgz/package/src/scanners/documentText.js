"use strict";

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const { spawnSync } = require("child_process");

const DOCUMENT_EXTENSIONS = new Set([".pdf", ".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"]);
const MAX_EXTRACTED_TEXT_CHARS = 2 * 1024 * 1024;
const MAX_DOCUMENT_ENTRY_BYTES = 2 * 1024 * 1024;
const MAX_PDF_PAGES = 100;
const PDF_WORKER_TIMEOUT_MS = 15000;
const DOCX_TEXT_ENTRY = /^word\/(?:document|header\d+|footer\d+|footnotes|endnotes|comments)\.xml$/i;
const XLSX_TEXT_ENTRY = /^xl\/(?:sharedStrings|worksheets\/sheet\d+|comments\d+)\.xml$/i;
const PPTX_TEXT_ENTRY = /^ppt\/(?:slides\/slide\d+|notesSlides\/notesSlide\d+|comments\/comment\d+)\.xml$/i;

function documentKind(filePath) {
  const ext = path.extname(String(filePath || "")).toLowerCase();
  if (ext === ".pdf") return "pdf";
  if (ext === ".docx") return "docx";
  if (ext === ".docm") return "docm";
  if (ext === ".xlsx") return "xlsx";
  if (ext === ".xlsm") return "xlsm";
  if (ext === ".pptx") return "pptx";
  if (ext === ".pptm") return "pptm";
  return null;
}

function extractDocumentText(filePath, options = {}) {
  const kind = documentKind(filePath);
  if (kind === "docx" || kind === "docm") return extractOfficeXmlText(filePath, kind, DOCX_TEXT_ENTRY);
  if (kind === "xlsx" || kind === "xlsm") return extractOfficeXmlText(filePath, kind, XLSX_TEXT_ENTRY);
  if (kind === "pptx" || kind === "pptm") return extractOfficeXmlText(filePath, kind, PPTX_TEXT_ENTRY);
  if (kind === "pdf") return extractPdfText(filePath, options);
  return { ok: false, kind: null, text: "", reason: "unsupported_document_type" };
}

function extractDocxText(filePath) {
  return extractOfficeXmlText(filePath, "docx", DOCX_TEXT_ENTRY);
}

function extractXlsxText(filePath) {
  return extractOfficeXmlText(filePath, "xlsx", XLSX_TEXT_ENTRY);
}

function extractPptxText(filePath) {
  return extractOfficeXmlText(filePath, "pptx", PPTX_TEXT_ENTRY);
}

function extractOfficeXmlText(filePath, kind, textEntryMatcher) {
  try {
    const buffer = fs.readFileSync(filePath);
    const entries = readOfficeTextEntries(buffer, textEntryMatcher, kind);
    if (!entries.length) return { ok: false, kind, text: "", reason: `${kind}_text_parts_missing` };
    return extractedTextResult(kind, entries.map((entry) => stripDocxXmlText(entry.toString("utf8"))).join("\n"));
  } catch (error) {
    return { ok: false, kind, text: "", reason: error.message || `${kind}_extract_failed` };
  }
}

function extractPdfText(filePath, options = {}) {
  if (typeof options.pdfTextExtractor === "function") {
    try {
      return extractedTextResult("pdf", options.pdfTextExtractor(filePath));
    } catch (error) {
      return { ok: false, kind: "pdf", text: "", reason: error.message || "pdf_extract_failed" };
    }
  }
  const commands = Array.isArray(options.pdftotextCommands) && options.pdftotextCommands.length
    ? options.pdftotextCommands
    : ["pdftotext"];
  let lastFailure = "pdftotext_not_found";
  for (const command of commands) {
    const result = spawnSync(command, ["-layout", filePath, "-"], {
      encoding: "utf8",
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true
    });
    if (result.error && result.error.code === "ENOENT") continue;
    if (result.error) {
      lastFailure = result.error.message || "pdf_extract_failed";
      continue;
    }
    if (result.status === 0) {
      const parsed = extractedTextResult("pdf", result.stdout || "");
      if (parsed.ok) return parsed;
      lastFailure = parsed.reason;
      continue;
    }
    const detail = String(result.stderr || "").trim();
    lastFailure = detail || `pdftotext_exit_${result.status}`;
  }
  const fallback = extractPdfTextWithBundledWorker(filePath, options);
  if (fallback.ok) return fallback;
  return {
    ok: false,
    kind: "pdf",
    text: "",
    reason: fallback.reason === "pdfjs_unavailable" ? lastFailure : fallback.reason
  };
}

function extractedTextResult(kind, value) {
  const text = limitText(value);
  if (!text.trim()) return { ok: false, kind, text: "", reason: "document_text_unavailable" };
  return { ok: true, kind, text, reason: null };
}

function bundledPdfParserStatus() {
  const pdfJsPath = path.resolve(__dirname, "..", "..", "vendor", "pdf.min.js");
  const workerPath = path.resolve(__dirname, "..", "..", "vendor", "pdf.worker.js");
  if (!fs.existsSync(pdfJsPath) || !fs.existsSync(workerPath)) {
    return { ok: false, reason: "pdfjs_unavailable", pdfJsPath, workerPath };
  }
  return { ok: true, pdfJsPath, workerPath };
}

// The outer scanner is intentionally synchronous because git hooks and CLI
// enforcement use it directly. Run PDF.js in a short-lived local child process
// so the public scanner contract stays synchronous while PDFs need no system
// dependency. The child returns text only to this parent process; nothing is
// logged, queued, or sent to the backend.
function extractPdfTextWithBundledWorker(filePath, options = {}) {
  if (options.disableBundledPdfParser) return { ok: false, kind: "pdf", text: "", reason: "pdfjs_unavailable" };
  const support = bundledPdfParserStatus();
  if (!support.ok) return { ok: false, kind: "pdf", text: "", reason: support.reason };

  // pkg exposes its embedded Node launcher as process.execPath. The executable
  // a customer launched is process.argv[0], and that is the only value which
  // can recursively invoke this internal command in the packaged build.
  const runningPackagedExecutable = Boolean(process.pkg);
  // @yao-pkg rewrites child processes whose command exactly equals process.execPath.
  // That rewrite loses the internal command argument. An equivalent path with a
  // harmless dot segment bypasses the rewrite while still launching this binary.
  const packagedExecutablePath = `${path.dirname(process.execPath)}${path.sep}.${path.sep}${path.basename(process.execPath)}`;
  const workerExecutable = runningPackagedExecutable ? packagedExecutablePath : process.execPath;
  const workerArgs = runningPackagedExecutable
    ? ["_pdf-text", filePath]
    : [path.resolve(__dirname, "..", "cli", "index.js"), "_pdf-text", filePath];
  const result = spawnSync(workerExecutable, workerArgs, {
    encoding: "utf8",
    maxBuffer: 8 * 1024 * 1024,
    timeout: Number(options.pdfWorkerTimeoutMs || PDF_WORKER_TIMEOUT_MS),
    windowsHide: true
  });
  if (result.error) {
    return {
      ok: false,
      kind: "pdf",
      text: "",
      reason: result.error.code === "ETIMEDOUT" ? "pdf_parser_timeout" : (result.error.message || "pdf_parser_failed")
    };
  }
  const lines = String(result.stdout || "").trim().split(/\r?\n/).filter(Boolean);
  const payload = lines.reverse().map((line) => {
    try { return JSON.parse(line); } catch (_error) { return null; }
  }).find(Boolean);
  if (payload && typeof payload === "object") return payload;
  return {
    ok: false,
    kind: "pdf",
    text: "",
    reason: String(result.stderr || "").trim() || `pdfjs_exit_${result.status}`
  };
}

async function extractPdfTextWithBundledPdfJs(filePath) {
  const support = bundledPdfParserStatus();
  if (!support.ok) return { ok: false, kind: "pdf", text: "", reason: support.reason };

  let pdf = null;
  try {
    // This is a pinned, locally vendored copy of the same PDF.js release used
    // by the browser extension. It never fetches a document or calls a remote service.
    // eslint-disable-next-line global-require, import/no-dynamic-require
    const pdfjs = require(support.pdfJsPath);
    const data = new Uint8Array(fs.readFileSync(filePath));
    const loadingTask = pdfjs.getDocument({ data, isEvalSupported: false, verbosity: 0 });
    pdf = await loadingTask.promise;
    if (!pdf.numPages) return { ok: false, kind: "pdf", text: "", reason: "document_text_unavailable" };
    if (pdf.numPages > MAX_PDF_PAGES) return { ok: false, kind: "pdf", text: "", reason: "pdf_page_limit_exceeded" };

    const pages = [];
    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber);
      try {
        const content = await page.getTextContent();
        pages.push((content.items || []).map((item) => item.str || "").join(" "));
      } finally {
        try { page.cleanup(); } catch (_error) {}
      }
    }
    return extractedTextResult("pdf", pages.join("\n"));
  } catch (error) {
    const message = String(error?.message || "pdf_parser_failed");
    if (/password|encrypted/i.test(message)) return { ok: false, kind: "pdf", text: "", reason: "pdf_password_protected" };
    if (/invalid|corrupt|xref|format/i.test(message)) return { ok: false, kind: "pdf", text: "", reason: "pdf_invalid_or_corrupt" };
    return { ok: false, kind: "pdf", text: "", reason: "pdf_parser_failed" };
  } finally {
    try { await pdf?.destroy?.(); } catch (_error) {}
  }
}

function readZipEntry(buffer, targetName) {
  const eocdOffset = findEndOfCentralDirectory(buffer);
  if (eocdOffset < 0) throw new Error("zip_central_directory_missing");
  const totalEntries = readUInt16(buffer, eocdOffset + 10);
  let offset = readUInt32(buffer, eocdOffset + 16);
  for (let i = 0; i < totalEntries; i += 1) {
    if (readUInt32(buffer, offset) !== 0x02014b50) throw new Error("zip_central_directory_invalid");
    const compression = readUInt16(buffer, offset + 10);
    const compressedSize = readUInt32(buffer, offset + 20);
    const fileNameLength = readUInt16(buffer, offset + 28);
    const extraLength = readUInt16(buffer, offset + 30);
    const commentLength = readUInt16(buffer, offset + 32);
    const localHeaderOffset = readUInt32(buffer, offset + 42);
    const nameStart = offset + 46;
    const name = buffer.subarray(nameStart, nameStart + fileNameLength).toString("utf8").replace(/\\/g, "/");
    if (name === targetName) return readLocalZipEntry(buffer, localHeaderOffset, compressedSize, compression);
    offset = nameStart + fileNameLength + extraLength + commentLength;
  }
  return null;
}

function readDocxTextEntries(buffer) {
  return readOfficeTextEntries(buffer, DOCX_TEXT_ENTRY, "docx");
}

function readOfficeTextEntries(buffer, textEntryMatcher, kind) {
  const eocdOffset = findEndOfCentralDirectory(buffer);
  if (eocdOffset < 0) throw new Error("zip_central_directory_missing");
  const totalEntries = readUInt16(buffer, eocdOffset + 10);
  let offset = readUInt32(buffer, eocdOffset + 16);
  const entries = [];
  let totalUncompressed = 0;
  for (let i = 0; i < totalEntries; i += 1) {
    if (readUInt32(buffer, offset) !== 0x02014b50) throw new Error("zip_central_directory_invalid");
    const compression = readUInt16(buffer, offset + 10);
    const compressedSize = readUInt32(buffer, offset + 20);
    const uncompressedSize = readUInt32(buffer, offset + 24);
    const fileNameLength = readUInt16(buffer, offset + 28);
    const extraLength = readUInt16(buffer, offset + 30);
    const commentLength = readUInt16(buffer, offset + 32);
    const localHeaderOffset = readUInt32(buffer, offset + 42);
    const nameStart = offset + 46;
    const name = buffer.subarray(nameStart, nameStart + fileNameLength).toString("utf8").replace(/\\/g, "/");
    if (textEntryMatcher.test(name)) {
      totalUncompressed += uncompressedSize;
      if (uncompressedSize > MAX_DOCUMENT_ENTRY_BYTES || totalUncompressed > MAX_DOCUMENT_ENTRY_BYTES) {
        throw new Error(`${kind}_text_too_large`);
      }
      entries.push(readLocalZipEntry(buffer, localHeaderOffset, compressedSize, compression));
    }
    offset = nameStart + fileNameLength + extraLength + commentLength;
  }
  return entries;
}

function readLocalZipEntry(buffer, localHeaderOffset, compressedSize, compression) {
  if (readUInt32(buffer, localHeaderOffset) !== 0x04034b50) throw new Error("zip_local_header_invalid");
  const fileNameLength = readUInt16(buffer, localHeaderOffset + 26);
  const extraLength = readUInt16(buffer, localHeaderOffset + 28);
  const dataStart = localHeaderOffset + 30 + fileNameLength + extraLength;
  if (dataStart < 0 || dataStart + compressedSize > buffer.length) throw new Error("zip_entry_out_of_range");
  const data = buffer.subarray(dataStart, dataStart + compressedSize);
  if (compression === 0) return data;
  if (compression === 8) return zlib.inflateRawSync(data);
  throw new Error(`zip_compression_${compression}_unsupported`);
}

function findEndOfCentralDirectory(buffer) {
  const min = Math.max(0, buffer.length - 22 - 65535);
  for (let i = buffer.length - 22; i >= min; i -= 1) {
    if (readUInt32(buffer, i) === 0x06054b50) return i;
  }
  return -1;
}

function stripDocxXmlText(xml) {
  return decodeXmlEntities(String(xml || "")
    .replace(/<w:tab\b[^>]*\/>/g, "\t")
    .replace(/<w:br\b[^>]*\/>/g, "\n")
    .replace(/<\/w:p>/g, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim());
}

function decodeXmlEntities(value) {
  const named = { amp: "&", lt: "<", gt: ">", quot: "\"", apos: "'" };
  return String(value || "").replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (match, entity) => {
    if (entity[0] === "#") {
      const isHex = entity[1] && entity[1].toLowerCase() === "x";
      const code = Number.parseInt(entity.slice(isHex ? 2 : 1), isHex ? 16 : 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    }
    return Object.prototype.hasOwnProperty.call(named, entity) ? named[entity] : match;
  });
}

function limitText(value) {
  return String(value || "").slice(0, MAX_EXTRACTED_TEXT_CHARS);
}

function readUInt16(buffer, offset) {
  if (offset < 0 || offset + 2 > buffer.length) throw new Error("zip_read_out_of_range");
  return buffer.readUInt16LE(offset);
}

function readUInt32(buffer, offset) {
  if (offset < 0 || offset + 4 > buffer.length) throw new Error("zip_read_out_of_range");
  return buffer.readUInt32LE(offset);
}

module.exports = {
  DOCUMENT_EXTENSIONS,
  MAX_EXTRACTED_TEXT_CHARS,
  documentKind,
  extractDocumentText,
  extractDocxText,
  extractPdfText,
  extractPdfTextWithBundledPdfJs,
  bundledPdfParserStatus,
  stripDocxXmlText,
  _internal: { readZipEntry, readDocxTextEntries, readOfficeTextEntries, findEndOfCentralDirectory }
};
