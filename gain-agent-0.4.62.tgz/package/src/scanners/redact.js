"use strict";

// Single source of truth: the agent reuses the SAME redaction logic the browser
// extension ships in shared/redact.js, loaded in a VM context exactly like
// scanners/patterns.js. The extension, the dashboard simulator, and the agent
// therefore redact identically. scripts/scanner-harness.js asserts the
// canonical redactor matches the extension's inline copy over the full corpus.
//
// Override the path with GAIN_REDACT_PATH (used in a packaged/vendored build).

const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { redactCustomVocabulary } = require("../policies/customVocabulary");

// Dev checkouts must use the canonical shared redactor. Packaged builds do not
// include ../../../shared and therefore use vendor/redact.js. This prevents a
// stale vendor copy from detecting a value with new patterns but leaking it
// during redaction.
const VENDORED_REDACT_PATH = path.resolve(__dirname, "..", "..", "vendor", "redact.js");
const REPO_REDACT_PATH = path.resolve(__dirname, "..", "..", "..", "shared", "redact.js");

function resolveRedactPath({
  env = process.env,
  fsImpl = fs,
  repoRedactPath = REPO_REDACT_PATH,
  vendorRedactPath = VENDORED_REDACT_PATH
} = {}) {
  if (env.GAIN_REDACT_PATH) return env.GAIN_REDACT_PATH;
  if (fsImpl.existsSync(repoRedactPath)) return repoRedactPath;
  return vendorRedactPath;
}

const REDACT_PATH = resolveRedactPath();

function loadRedactor(redactPath) {
  const code = fs.readFileSync(redactPath, "utf8");
  const context = { globalThis: {}, module: { exports: {} } };
  vm.createContext(context);
  vm.runInContext(code, context);
  const api = context.globalThis.SHADOW_AI_REDACT;
  if (!api || typeof api.redactSensitiveText !== "function") {
    throw new Error("shared/redact.js did not expose SHADOW_AI_REDACT.redactSensitiveText");
  }
  return api;
}

let redactor;
function getRedactor() {
  if (!redactor) {
    try {
      redactor = loadRedactor(REDACT_PATH);
    } catch (error) {
      throw new Error(`Could not load redactor from ${REDACT_PATH}: ${error.message}`);
    }
  }
  return redactor;
}

function redactSensitiveText(text, patterns) {
  return getRedactor().redactSensitiveText(String(text || ""), Array.isArray(patterns) ? patterns : []);
}

function redactTextWithPolicies(text, patterns, policyBundle) {
  const standard = redactSensitiveText(text, patterns);
  const custom = redactCustomVocabulary(standard.text, patterns, policyBundle);
  return {
    text: custom.text,
    changed: standard.changed || custom.changed,
    count: Number(standard.count || 0) + Number(custom.count || 0)
  };
}

module.exports = { redactSensitiveText, redactTextWithPolicies, getRedactor, REDACT_PATH, resolveRedactPath };
