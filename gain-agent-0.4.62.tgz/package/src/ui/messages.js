"use strict";

const LABELS = {
  api_key: "API key",
  aws_access_key: "AWS access key",
  azure_storage_connection_string: "Azure storage connection string",
  bulk_pii: "customer data",
  confidential_markers: "confidential marker",
  connection_string: "connection string",
  credit_card: "credit card number",
  crypto_private_key: "crypto wallet private key",
  custom_phrase: "custom sensitive term",
  custom_regex: "custom sensitive pattern",
  email: "email address",
  file_upload: "file upload",
  iban: "IBAN",
  internal_url: "internal URL",
  ip_address: "IP address",
  jwt: "token",
  large_paste: "large paste",
  national_id_context: "national ID mention",
  password_mention: "password",
  phone: "phone number",
  private_key: "private key",
  prompt_injection: "prompt injection",
  secret_env: "environment secret",
  seed_phrase: "seed phrase",
  source_code: "source code"
};

const RISK_ORDER = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };

function plural(word, count) {
  return Number(count || 0) === 1 ? word : `${word}s`;
}

function patternLabel(type) {
  return LABELS[type] || String(type || "sensitive value").replace(/_/g, " ");
}

function patternSummary(patterns = []) {
  const entries = [...new Set((patterns || []).map((pattern) => patternLabel(pattern.type)).filter(Boolean))];
  if (!entries.length) return "";
  if (entries.length <= 3) return entries.join(", ");
  return `${entries.slice(0, 3).join(", ")}, and ${entries.length - 3} more`;
}

function patternCount(patterns = []) {
  return (patterns || []).reduce((sum, pattern) => sum + Number(pattern.count || 1), 0);
}

function hasPattern(patterns, type) {
  return (patterns || []).some((pattern) => pattern.type === type);
}

function strongestPattern(patterns = []) {
  return [...patterns].sort((a, b) => (RISK_ORDER[b.risk || "info"] || 0) - (RISK_ORDER[a.risk || "info"] || 0))[0] || null;
}

function articleForLabel(label) {
  return /^(api|aws|iban|ip|email|internal|environment)/i.test(String(label || "")) ? "an" : "a";
}

function blockNotificationLine(patterns = [], toolName = "the tool") {
  const pattern = strongestPattern(patterns);
  if (!pattern) return null;
  const label = patternLabel(pattern.type);
  const tool = String(toolName || "the tool").trim() || "the tool";
  return `G.A.I.N blocked ${articleForLabel(label)} ${label} before it reached ${tool}.`;
}

function actionLine(decision = {}, patterns = [], options = {}) {
  const action = String(decision.action || "allow");
  const context = options.context || "this action";
  const summary = patternSummary(patterns);
  const count = patternCount(patterns);
  const suffix = summary ? ` (${summary})` : "";

  if (action === "allow") return "Clean: no sensitive data found.";

  if (action === "block") {
    if (hasPattern(patterns, "private_key") && hasPattern(patterns, "seed_phrase")) {
      return "Blocked: private keys and seed phrases can never be shared with AI.";
    }
    if (hasPattern(patterns, "private_key")) return "Blocked: a private key can never be shared with AI.";
    if (hasPattern(patterns, "crypto_private_key")) return "Blocked: a crypto wallet private key can never be shared with AI.";
    if (hasPattern(patterns, "seed_phrase")) return "Blocked: a seed phrase can never be shared with AI.";
    return `Blocked: remove the sensitive ${plural("item", count)} before continuing${suffix}.`;
  }

  if (action === "redact") {
    return `Removed ${count || "the"} sensitive ${plural("item", count)} before ${context}${suffix}.`;
  }

  if (action === "warn") {
    return `Heads up: sensitive data was detected. Review before sharing${suffix}.`;
  }

  if (action === "log_only") {
    return `Logged metadata only for ${count || "the"} sensitive ${plural("item", count)}. Nothing was changed${suffix}.`;
  }

  return `${action}: sensitive data detected${suffix}.`;
}

module.exports = {
  actionLine,
  blockNotificationLine,
  patternCount,
  patternLabel,
  patternSummary
};
