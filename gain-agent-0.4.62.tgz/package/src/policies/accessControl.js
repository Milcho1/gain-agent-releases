"use strict";

const ACCESS_MODES = new Set(["monitor", "allow_all", "allow_only_approved"]);

function normalizeToken(value) {
  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/^https?:\/\//, "")
    .split(/[/?#]/)[0]
    .replace(/^www\./, "");
}

function normalizeList(value) {
  if (Array.isArray(value)) return value.map(normalizeToken).filter(Boolean);
  return String(value || "")
    .split(",")
    .map(normalizeToken)
    .filter(Boolean);
}

function hostMatches(host, target) {
  if (!host || !target) return false;
  return host === target || host.endsWith(`.${target}`) || target.endsWith(`.${host}`);
}

function tokenMatchesTool(token, tool) {
  if (!token) return false;
  const domain = normalizeToken(tool.domain);
  const name = normalizeToken(tool.toolName || tool.name);
  return hostMatches(domain, token) || name === token || name.includes(token) || token.includes(name);
}

function findToolStatus(orgPolicyBundle, tool) {
  const rows = Array.isArray(orgPolicyBundle?.ai_tools) ? orgPolicyBundle.ai_tools : [];
  const match = rows.find((row) => tokenMatchesTool(normalizeToken(row.domain || row.name), {
    domain: tool.domain,
    toolName: tool.toolName
  }));
  const status = String(match?.status || "").toLowerCase();
  return ["approved", "monitored", "restricted", "blocked"].includes(status) ? status : null;
}

function accessMode(config = {}, orgPolicyBundle = null) {
  const raw = config.access_mode ||
    orgPolicyBundle?.access_control?.mode ||
    orgPolicyBundle?.deployment?.access_mode ||
    "monitor";
  const mode = String(raw || "").toLowerCase().trim().replace(/-/g, "_");
  return ACCESS_MODES.has(mode) ? mode : "monitor";
}

function decideAccess({ toolName, domain, config = {}, orgPolicyBundle = null } = {}) {
  const tool = { toolName, domain };
  // This is the organization availability failsafe. It must take precedence
  // over local allow-only and blocked-tool rules so a dashboard pause never
  // prevents an AI app from working.
  if (String(orgPolicyBundle?.protection?.status || "").toLowerCase() === "paused") {
    return {
      allowed: true,
      action: "allow",
      status: "paused",
      is_approved_tool: false,
      policy_triggered: "org_protection_paused",
      reason: "Organization protection is paused by an administrator."
    };
  }
  const blocked = normalizeList(config.blocked_tools);
  const approved = normalizeList(config.approved_tools);
  const status = findToolStatus(orgPolicyBundle, tool) || (
    approved.some((token) => tokenMatchesTool(token, tool)) ? "approved" :
    blocked.some((token) => tokenMatchesTool(token, tool)) ? "blocked" :
    "monitored"
  );

  if (blocked.some((token) => tokenMatchesTool(token, tool)) || status === "blocked") {
    return {
      allowed: false,
      action: "block",
      status: "blocked",
      is_approved_tool: false,
      policy_triggered: "tool_blocked",
      reason: `${toolName || domain} is blocked by device access policy.`
    };
  }

  const mode = accessMode(config, orgPolicyBundle);
  const isApproved = status === "approved" || approved.some((token) => tokenMatchesTool(token, tool));
  if (mode === "allow_only_approved" && !isApproved) {
    return {
      allowed: false,
      action: "block",
      status,
      is_approved_tool: false,
      policy_triggered: "allow_only_approved",
      reason: `${toolName || domain} is not on the approved AI tools list.`
    };
  }

  return {
    allowed: true,
    action: "allow",
    status,
    is_approved_tool: isApproved,
    policy_triggered: null,
    reason: "Tool allowed by device access policy."
  };
}

module.exports = { decideAccess, accessMode, normalizeList };
