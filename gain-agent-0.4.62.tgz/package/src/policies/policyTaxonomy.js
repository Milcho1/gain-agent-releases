"use strict";

const path = require("path");

function loadTaxonomy() {
  const candidates = [
    path.resolve(__dirname, "..", "..", "..", "shared", "policy-taxonomy.js"),
    path.resolve(__dirname, "..", "..", "vendor", "policy-taxonomy.js")
  ];
  for (const candidate of candidates) {
    try {
      // eslint-disable-next-line global-require, import/no-dynamic-require
      const api = require(candidate);
      if (api && typeof api.coveredPatternsForPolicy === "function") return api;
    } catch (_error) {
      // Try the next location. Dev checkouts use shared, published builds use vendor.
    }
  }
  return {
    coveredPatternsForPolicy(policy) {
      const explicit = Array.isArray(policy && policy.covered_patterns)
        ? policy.covered_patterns.map((value) => String(value || "").trim()).filter(Boolean)
        : [];
      if (explicit.length) return [...new Set(explicit)];
      const trigger = String(policy && policy.trigger_pattern || "").trim();
      return trigger ? [trigger] : [];
    }
  };
}

module.exports = loadTaxonomy();
