"use strict";

// Maps detected patterns + project policy + organization policy to an action.
// Mirrors the browser extension's intent: local analysis, org policy first,
// project bans win, hard-block only the most dangerous patterns.

const RISK_ORDER = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };
const ENFORCEMENT_MODES = ["visibility_only", "warn", "redact", "block"];
const ACTION_PRIORITY = { block: 4, redact: 3, warn: 2, log_only: 1, allow: 0, allowed: 0 };
const { coveredPatternsForPolicy } = require("./policyTaxonomy");
const { CUSTOM_PHRASE, CUSTOM_REGEX, isCustomPolicy, policyAppliesToContext } = require("./customVocabulary");

// Patterns that should hard-block regardless of mode. These leaks are irreversible.
const HARD_BLOCK_TYPES = new Set(["private_key", "crypto_private_key", "seed_phrase", "document_scan_failed"]);

function highestSeverity(patterns) {
  if (!Array.isArray(patterns) || !patterns.length) return "info";
  return patterns.reduce((best, pattern) => {
    const risk = String(pattern.risk || "info");
    return (RISK_ORDER[risk] || 0) > (RISK_ORDER[best] || 0) ? risk : best;
  }, "info");
}

function actionForMode(mode) {
  switch (mode) {
    case "block": return "block";
    case "redact": return "redact";
    case "warn": return "warn";
    case "visibility_only":
    default: return "log_only";
  }
}

function normalizePolicyAction(action) {
  const value = String(action || "log_only").toLowerCase().trim().replace(/[\s-]+/g, "_");
  const aliases = {
    allowed: "allow",
    log: "log_only",
    logged: "log_only",
    logonly: "log_only",
    warn_user: "warn",
    warning: "warn",
    redact_user: "redact",
    redacted: "redact",
    block_user: "block",
    blocked: "block"
  };
  const normalized = aliases[value] || value;
  return Object.prototype.hasOwnProperty.call(ACTION_PRIORITY, normalized) ? normalized : "log_only";
}

function policyMatchesContext(policy, context) {
  return policyAppliesToContext(policy, context);
}

function policyMatchesPattern(policy, pattern) {
  if (isCustomPolicy(policy)) {
    return [CUSTOM_PHRASE, CUSTOM_REGEX].includes(pattern.type) &&
      String(pattern.policy_id || "") === String(policy.id || "");
  }
  const coveredPatterns = coveredPatternsForPolicy(policy);
  return coveredPatterns.includes(pattern.type);
}

function matchingOrgPolicies(policyBundle, patterns, context = {}) {
  const policies = Array.isArray(policyBundle && policyBundle.policies) ? policyBundle.policies : [];
  return policies.filter((policy) => {
    if (!policy || policy.enabled === false) return false;
    const trigger = String(policy.trigger_pattern || "").trim();
    if (!trigger) return false;
    if (!policyMatchesContext(policy, context)) return false;
    const threshold = Math.max(1, Number(policy.trigger_threshold || 1));
    const matchedCount = patterns
      .filter((pattern) => policyMatchesPattern(policy, pattern))
      .reduce((sum, pattern) => sum + Number(pattern.count || 1), 0);
    return matchedCount >= threshold;
  }).map((policy) => {
    const trigger = String(policy.trigger_pattern || "").trim();
    const requestedAction = normalizePolicyAction(policy.action);
    return {
      ...policy,
      action: requestedAction,
      trigger_pattern: trigger
    };
  });
}

function highestActionPolicy(policies) {
  return [...(policies || [])].sort((a, b) => (ACTION_PRIORITY[b.action] || 0) - (ACTION_PRIORITY[a.action] || 0))[0] || null;
}

function isOrganizationProtectionPaused(policyBundle) {
  return String(policyBundle?.protection?.status || "").toLowerCase() === "paused";
}

// decide({ patterns, projectPolicy, orgPolicyBundle, enforcementMode, context }) -> decision
function decide({ patterns = [], projectPolicy = null, orgPolicyBundle = null, enforcementMode = "visibility_only", context = {} } = {}) {
  const mode = ENFORCEMENT_MODES.includes(enforcementMode) ? enforcementMode : "visibility_only";
  const severity = highestSeverity(patterns);

  // 1. An admin pause is an availability failsafe. It deliberately overrides
  // every local and organization rule, including hard blocks, until resumed.
  if (isOrganizationProtectionPaused(orgPolicyBundle)) {
    return {
      action: "allow",
      severity: "info",
      policy_triggered: "org_protection_paused",
      reason: "Organization protection is paused by an administrator."
    };
  }

  // 2. Project-level AI ban always wins (e.g. customer source code repo).
  if (projectPolicy && projectPolicy.ai_allowed === false) {
    return {
      action: projectPolicy.action || "block",
      severity: severity === "info" ? "high" : severity,
      policy_triggered: "project_ai_forbidden",
      reason: projectPolicy.reason || "AI use is not allowed for this project."
    };
  }

  // 3. No findings -> allow.
  if (!patterns.length) {
    return { action: "allow", severity: "info", policy_triggered: null, reason: "No sensitive patterns detected." };
  }

  // 4. Hard-block dangerous types regardless of mode.
  const hardBlockPattern = patterns.find((pattern) => HARD_BLOCK_TYPES.has(pattern.type));
  if (hardBlockPattern) {
    const reason = hardBlockPattern.type === "document_scan_failed"
      ? "A file could not be safely scanned; remove it or provide a text-readable version before sharing."
      : hardBlockPattern.type === "seed_phrase"
      ? "A seed phrase was detected; this can never be shared with AI tools."
      : hardBlockPattern.type === "crypto_private_key"
        ? "A crypto wallet private key was detected; this can never be shared with AI tools."
        : "A private key was detected; this can never be shared with AI tools.";
    return {
      action: "block",
      severity: "critical",
      policy_triggered: "hard_block_pattern",
      reason
    };
  }

  // 5. Prefer the live/cached organization policy bundle when available.
  if (orgPolicyBundle && orgPolicyBundle.license && orgPolicyBundle.license.enforcement_enabled === false) {
    return {
      action: "log_only",
      severity,
      policy_triggered: "org_enforcement_disabled",
      reason: "Sensitive data detected; organization enforcement is disabled."
    };
  }
  const orgPolicy = highestActionPolicy(matchingOrgPolicies(orgPolicyBundle, patterns, context));
  if (orgPolicy) {
    return {
      action: orgPolicy.action,
      severity,
      // The edge stores policy_triggered as a UUID. Prefer the stable policy id
      // so agent, browser, and desktop events can be tied to the same rule.
      policy_triggered: orgPolicy.id || orgPolicy.name || orgPolicy.trigger_pattern,
      policy_name: orgPolicy.name || orgPolicy.trigger_pattern,
      reason: `Sensitive data matched organization policy "${orgPolicy.name || orgPolicy.trigger_pattern}".`
    };
  }

  // 5. Otherwise follow the configured enforcement mode.
  return {
    action: actionForMode(mode),
    severity,
    policy_triggered: `enforcement_${mode}`,
    reason: `Sensitive data detected; org enforcement mode is "${mode}".`
  };
}

module.exports = {
  decide,
  highestSeverity,
  matchingOrgPolicies,
  normalizePolicyAction,
  RISK_ORDER,
  ENFORCEMENT_MODES,
  HARD_BLOCK_TYPES,
  isOrganizationProtectionPaused
};
