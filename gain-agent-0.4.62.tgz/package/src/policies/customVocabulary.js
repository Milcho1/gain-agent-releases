"use strict";

// Custom vocabulary is saved in a policy bundle as literal terms or guarded
// regex sources. Keep the matched values on-device: callers only receive a
// policy id, type, count, and severity for telemetry.

const CUSTOM_PHRASE = "custom_phrase";
const CUSTOM_REGEX = "custom_regex";
const CUSTOM_PHRASE_PREFIX = `${CUSTOM_PHRASE}:`;
const CUSTOM_REGEX_PREFIX = `${CUSTOM_REGEX}:`;

const TOOL_TARGET_ALIASES = {
  chatgpt: ["chatgpt.com", "chat.openai.com", "api.openai.com", "openai.com"],
  claude: ["claude.ai", "api.anthropic.com", "anthropic.com", "claude-code"],
  gemini: ["gemini.google.com", "aistudio.google.com", "generativelanguage.googleapis.com"],
  copilot: ["copilot.microsoft.com", "githubcopilot.com", "api.githubcopilot.com"],
  perplexity: ["perplexity.ai"],
  cursor: ["cursor.com"],
};

function normalize(value) {
  return String(value || "").toLowerCase().trim();
}

function normalizeHost(value) {
  return normalize(value)
    .replace(/^https?:\/\//, "")
    .split(/[/?#]/)[0]
    .replace(/^www\./, "");
}

function normalizeList(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map(normalize).filter(Boolean))];
}

function hostMatches(host, target) {
  if (!host || !target) return false;
  return host === target || host.endsWith(`.${target}`) || target.endsWith(`.${host}`);
}

function expandToolTarget(target) {
  const value = normalizeHost(target);
  if (!value || value === "all" || value === "all_tools") return [];
  return TOOL_TARGET_ALIASES[value] || [value];
}

function normalCategories(policy) {
  return normalizeList(policy?.target_categories).filter((category) =>
    !category.startsWith(CUSTOM_PHRASE_PREFIX) && !category.startsWith(CUSTOM_REGEX_PREFIX),
  );
}

function isCustomPolicy(policy) {
  const trigger = normalize(policy?.trigger_pattern);
  return trigger === CUSTOM_PHRASE || trigger === CUSTOM_REGEX;
}

function policyAppliesToContext(policy, context = {}) {
  const targetTools = normalizeList(policy?.target_tools).flatMap(expandToolTarget);
  const targetDepartments = normalizeList(policy?.target_departments);
  const host = normalizeHost(context.domain || context.toolName || "agent.local");
  const category = normalize(context.category);
  const department = normalize(context.department);
  const categories = normalCategories(policy);

  const toolMatch = !targetTools.length || targetTools.some((target) => hostMatches(host, target));
  const categoryMatch = isCustomPolicy(policy) || !categories.length || (category && categories.includes(category));
  const departmentMatch = !targetDepartments.length || (department && targetDepartments.includes(department));
  return toolMatch && categoryMatch && departmentMatch;
}

function literalTerms(policy) {
  const explicit = Array.isArray(policy?.custom_terms) ? policy.custom_terms : [];
  const encoded = Array.isArray(policy?.target_categories) ? policy.target_categories : [];
  const values = [...explicit, ...encoded
    .map((item) => String(item || "").trim())
    .filter((item) => normalize(item).startsWith(CUSTOM_PHRASE_PREFIX))
    .map((item) => item.slice(CUSTOM_PHRASE_PREFIX.length).trim())];
  return [...new Set(values.map((item) => String(item || "").trim()).filter((item) => item.length >= 2))];
}

function isSafeRegexSource(source) {
  const value = String(source || "").trim();
  if (!value || value.length > 300 || /[\u0000-\u001F]/.test(value)) return false;
  if (/\((?:\?:)?[^)]*[+*][^)]*\)[+*{]/.test(value)) return false;
  if (hasOverlappingQuantifiedAlternation(value)) return false;
  try {
    const regex = new RegExp(value, "i");
    return !["", "GAIN_REGEX_PROBE", "AAAA"].some((sample) => {
      const match = regex.exec(sample);
      regex.lastIndex = 0;
      return match && match[0] === "";
    });
  } catch (_error) {
    return false;
  }
}

function hasOverlappingQuantifiedAlternation(source) {
  // `(a|aa)+` and similar alternatives can backtrack exponentially. We keep
  // ordinary alternatives valid and reject only branches where one starts
  // with another inside a quantified group.
  const groups = String(source || "").matchAll(/\((?:\?:)?((?:\\.|[^()])*)\)(?:[+*]|\{\d+(?:,\d*)?\})/g);
  for (const group of groups) {
    const branches = group[1].split("|").map((branch) => branch.replace(/\\(.)/g, "$1"));
    if (branches.length < 2) continue;
    for (let index = 0; index < branches.length; index += 1) {
      for (let other = index + 1; other < branches.length; other += 1) {
        if (branches[index] && branches[other] && (branches[index].startsWith(branches[other]) || branches[other].startsWith(branches[index]))) return true;
      }
    }
  }
  return false;
}

function regexSources(policy) {
  const explicit = Array.isArray(policy?.custom_regexes) ? policy.custom_regexes : [];
  const encoded = Array.isArray(policy?.target_categories) ? policy.target_categories : [];
  const values = [...explicit, ...encoded
    .map((item) => String(item || "").trim())
    .filter((item) => normalize(item).startsWith(CUSTOM_REGEX_PREFIX))
    .map((item) => item.slice(CUSTOM_REGEX_PREFIX.length).trim())];
  return [...new Set(values.map((item) => String(item || "").trim()).filter(isSafeRegexSource))];
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function countMatches(text, regex) {
  let count = 0;
  regex.lastIndex = 0;
  let match = null;
  while ((match = regex.exec(text)) !== null) {
    count += 1;
    if (match[0] === "") regex.lastIndex += 1;
  }
  regex.lastIndex = 0;
  return count;
}

function policyMatchers(policy) {
  if (!isCustomPolicy(policy)) return { literalRegexes: [], customRegexes: [] };
  return {
    literalRegexes: literalTerms(policy).map((term) => new RegExp(escapeRegExp(term), "gi")),
    customRegexes: regexSources(policy).map((source) => new RegExp(source, "gi"))
  };
}

function detectCustomPolicyPatterns(text, policyBundle, context = {}) {
  const value = String(text || "");
  if (!value) return [];
  const policies = Array.isArray(policyBundle?.policies) ? policyBundle.policies : [];
  const patterns = [];
  for (const policy of policies) {
    if (!policy || policy.enabled === false || !isCustomPolicy(policy) || !policy.id || !policyAppliesToContext(policy, context)) continue;
    const matchers = policyMatchers(policy);
    const literalCount = matchers.literalRegexes.reduce((sum, matcher) => sum + countMatches(value, matcher), 0);
    const regexCount = matchers.customRegexes.reduce((sum, matcher) => sum + countMatches(value, matcher), 0);
    const count = literalCount + regexCount;
    const threshold = Math.max(1, Number(policy.trigger_threshold || 1));
    if (count < threshold) continue;
    if (literalCount) {
      patterns.push({
        type: CUSTOM_PHRASE,
        count: literalCount,
        risk: policy.severity || "high",
        label: "Custom word or phrase",
        policy_id: String(policy.id)
      });
    }
    if (regexCount) {
      patterns.push({
        type: CUSTOM_REGEX,
        count: regexCount,
        risk: policy.severity || "high",
        label: "Custom regex",
        policy_id: String(policy.id)
      });
    }
  }
  return patterns;
}

function redactCustomVocabulary(text, patterns, policyBundle) {
  const matched = new Set((patterns || [])
    .filter((pattern) => (pattern.type === CUSTOM_PHRASE || pattern.type === CUSTOM_REGEX) && pattern.policy_id)
    .map((pattern) => String(pattern.policy_id)));
  if (!matched.size) return { text: String(text || ""), changed: false, count: 0 };

  let value = String(text || "");
  let count = 0;
  const policies = Array.isArray(policyBundle?.policies) ? policyBundle.policies : [];
  for (const policy of policies) {
    if (!policy || !matched.has(String(policy.id)) || !isCustomPolicy(policy)) continue;
    const matchers = policyMatchers(policy);
    for (const matcher of [...matchers.literalRegexes, ...matchers.customRegexes]) {
      value = value.replace(matcher, () => {
        count += 1;
        return "[REDACTED]";
      });
    }
  }
  return { text: value, changed: count > 0, count };
}

module.exports = {
  CUSTOM_PHRASE,
  CUSTOM_REGEX,
  detectCustomPolicyPatterns,
  redactCustomVocabulary,
  policyAppliesToContext,
  isCustomPolicy,
  literalTerms,
  regexSources,
  isSafeRegexSource
};
