"use strict";

const fs = require("fs");
const http = require("http");
const net = require("net");
const os = require("os");
const path = require("path");
const { spawn, execFileSync } = require("child_process");
const { AGENT_VERSION } = require("../reporters/supabaseEdgeClient");
const { configDir, readConfigFile, writeConfigFile } = require("../config/loadPolicy");
const {
  defaultCliPath,
  commandLine,
  writeWindowsHiddenRunner,
  windowsCreateTaskArgs,
  windowsDeleteTaskArgs,
  windowsQueryTaskArgs,
  windowsDirectCommand,
  startWindowsDirectCommand,
  windowsRunValueArgs,
  windowsDeleteRunValueArgs,
  queryWindowsRunValue
} = require("./healthSchedule");

const DEFAULT_PROXY_HOST = "127.0.0.1";
const DEFAULT_PROXY_PORT = 8787;
const PROXY_URL = `http://${DEFAULT_PROXY_HOST}:${DEFAULT_PROXY_PORT}`;
const PROXY_HEALTH_PATH = "/_gain/health";
const PORT_CONFLICT_RETRY_MS = 30 * 1000;
const PROXY_TASK = {
  name: "G.A.I.N Agent Proxy",
  command: "proxy --service run",
  args: ["/SC", "ONLOGON"],
  description: "hidden local AI proxy at user logon with watchdog restart"
};
const ENV_VARS = ["ANTHROPIC_BASE_URL", "OPENAI_BASE_URL", "OPENAI_API_BASE", "COPILOT_PROVIDER_BASE_URL"];
const PROFILE_MARKER_START = "# >>> G.A.I.N proxy environment >>>";
const PROFILE_MARKER_END = "# <<< G.A.I.N proxy environment <<<";
const WINDOWS_STARTUP_LAUNCHER = "G.A.I.N Agent Proxy.vbs";
const PROXY_RUN_VALUE = "G.A.I.N Agent Proxy";
const MAC_PROXY_LABEL = "com.cyberwardion.gain-agent.proxy";

function proxyUrl(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT) {
  return `http://${host}:${port}`;
}

function proxyStatePath() {
  return path.join(configDir(), "proxy-service.json");
}

function readProxyState() {
  try {
    return JSON.parse(fs.readFileSync(proxyStatePath(), "utf8"));
  } catch (_error) {
    return {};
  }
}

function writeProxyState(patch = {}) {
  const next = {
    ...readProxyState(),
    ...patch,
    updated_at: new Date().toISOString()
  };
  fs.mkdirSync(path.dirname(proxyStatePath()), { recursive: true });
  fs.writeFileSync(proxyStatePath(), JSON.stringify(next, null, 2));
  return next;
}

const PROXY_REQUEST_MARK_INTERVAL_MS = 3000;
let lastMarkedRequestAtMs = 0;

// Called on every single proxied request (every Claude Code / Copilot CLI call).
// last_request_at only feeds a human-facing status/doctor display, so this is
// throttled to avoid a synchronous disk read+write (writeProxyState) on the
// hot path of every request in a busy agentic session.
function markProxyRequest(now = Date.now()) {
  if (now - lastMarkedRequestAtMs < PROXY_REQUEST_MARK_INTERVAL_MS) return null;
  lastMarkedRequestAtMs = now;
  return writeProxyState({ last_request_at: new Date(now).toISOString() });
}

function normalizeFailPolicy(value) {
  const normalized = String(value || "fail_open").toLowerCase().trim().replace(/[\s-]+/g, "_");
  return normalized === "fail_open" ? "fail_open" : "fail_closed";
}

function serviceCommandLine({ nodePath = process.execPath, cliPath = defaultCliPath(), command = PROXY_TASK.command } = {}) {
  return commandLine(nodePath, cliPath, command);
}

function profilePaths(homeDir = os.homedir(), platform = process.platform) {
  const paths = [path.join(homeDir, ".profile"), path.join(homeDir, ".bashrc")];
  if (platform === "darwin") paths.push(path.join(homeDir, ".zprofile"));
  return [...new Set(paths)];
}

function updateProfileBlock(filePath, blockText) {
  let current = "";
  try { current = fs.readFileSync(filePath, "utf8"); } catch (_error) {}
  const escapedStart = PROFILE_MARKER_START.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const escapedEnd = PROFILE_MARKER_END.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const withoutBlock = current.replace(new RegExp(`\\n?${escapedStart}[\\s\\S]*?${escapedEnd}\\n?`, "m"), "\n").trimEnd();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${withoutBlock}${withoutBlock ? "\n\n" : ""}${blockText}\n`, "utf8");
}

function removeProfileBlock(filePath) {
  let current = "";
  try { current = fs.readFileSync(filePath, "utf8"); } catch (_error) { return false; }
  const escapedStart = PROFILE_MARKER_START.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const escapedEnd = PROFILE_MARKER_END.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const next = current.replace(new RegExp(`\\n?${escapedStart}[\\s\\S]*?${escapedEnd}\\n?`, "m"), "\n").trimEnd();
  fs.writeFileSync(filePath, next ? `${next}\n` : "", "utf8");
  return next !== current;
}

function setWindowsUserEnv(name, value, execFile = execFileSync) {
  execFile("setx", [name, value], { stdio: "pipe", windowsHide: true });
  process.env[name] = value;
}

function unsetWindowsUserEnv(name, execFile = execFileSync) {
  try {
    execFile("reg", ["delete", "HKCU\\Environment", "/V", name, "/F"], { stdio: "pipe", windowsHide: true });
  } catch (_error) {
    // Missing values are fine on uninstall.
  }
  delete process.env[name];
}

function sameProxyUrl(value, expectedUrl) {
  const current = parseLoopbackProxyUrl(value);
  const expected = parseLoopbackProxyUrl(expectedUrl);
  return Boolean(current && expected && current.host === expected.host && current.port === expected.port);
}

function readWindowsUserEnv(name, execFile = execFileSync) {
  try {
    const output = String(execFile("reg", ["query", "HKCU\\Environment", "/V", name], {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      windowsHide: true
    }) || "");
    const line = output.split(/\r?\n/).find((item) => new RegExp(`^\\s*${name.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\\\$&")}\\s+REG_`, "i").test(item));
    if (!line) return null;
    const match = line.match(/\sREG_\w+\s+(.*)$/i);
    return match ? match[1].trim() : null;
  } catch (_error) {
    return null;
  }
}

function clearGainProxyEnvironment({ platform = process.platform, homeDir = os.homedir(), execFile = execFileSync, url = PROXY_URL } = {}) {
  const removed = [];
  if (platform === "win32") {
    for (const name of ENV_VARS) {
      const persisted = readWindowsUserEnv(name, execFile);
      if (sameProxyUrl(persisted, url)) {
        unsetWindowsUserEnv(name, execFile);
        removed.push(name);
      } else if (sameProxyUrl(process.env[name], url)) {
        // A terminal may retain a prior G.A.I.N route until it is restarted.
        // Remove it from this process, but never delete an unrelated user value.
        delete process.env[name];
        removed.push(name);
      }
    }
    return { ok: true, platform, variables: [...new Set(removed)], url: null };
  }

  for (const file of profilePaths(homeDir, platform)) removeProfileBlock(file);
  for (const name of ENV_VARS) {
    if (sameProxyUrl(process.env[name], url)) {
      delete process.env[name];
      removed.push(name);
    }
  }
  return { ok: true, platform, variables: removed, url: null };
}

function persistProxyEnvironment({ enabled = true, platform = process.platform, homeDir = os.homedir(), execFile = execFileSync, url = PROXY_URL } = {}) {
  if (!enabled) return clearGainProxyEnvironment({ platform, homeDir, execFile, url });
  if (platform === "win32") {
    for (const name of ENV_VARS) {
      setWindowsUserEnv(name, url, execFile);
    }
    return { ok: true, platform, variables: ENV_VARS, url };
  }

  const files = profilePaths(homeDir, platform);
  const block = [
    PROFILE_MARKER_START,
    `export ANTHROPIC_BASE_URL="${url}"`,
    `export OPENAI_BASE_URL="${url}"`,
    `export OPENAI_API_BASE="${url}"`,
    `export COPILOT_PROVIDER_BASE_URL="${url}"`,
    PROFILE_MARKER_END
  ].join("\n");
  for (const file of files) updateProfileBlock(file, block);
  for (const name of ENV_VARS) {
    process.env[name] = url;
  }
  return { ok: true, platform, files, variables: ENV_VARS, url };
}

function launchAgentPath(homeDir = os.homedir()) {
  return path.join(homeDir, "Library", "LaunchAgents", "com.cyberwardion.gain-agent.proxy.plist");
}

function macLaunchDomain(options = {}) {
  const userId = options.userId !== undefined
    ? Number(options.userId)
    : (typeof process.getuid === "function" ? Number(process.getuid()) : Number(os.userInfo().uid));
  if (!Number.isFinite(userId) || userId < 0) return null;
  return `gui/${userId}`;
}

function windowsStartupDir({ homeDir = os.homedir(), appData = process.env.APPDATA } = {}) {
  return appData
    ? path.join(appData, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
    : path.join(homeDir, "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs", "Startup");
}

function windowsStartupLauncherPath(options = {}) {
  if (options.startupLauncherPath) return options.startupLauncherPath;
  return path.join(options.startupDir || windowsStartupDir(options), WINDOWS_STARTUP_LAUNCHER);
}

function windowsServiceRunArgs(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT) {
  return ["proxy", "--service", "run", "--host", host, "--port", String(port)];
}

function writeWindowsStartupLauncher({ nodePath = process.execPath, cliPath = defaultCliPath(), host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, launcherPath = windowsStartupLauncherPath() } = {}) {
  fs.mkdirSync(path.dirname(launcherPath), { recursive: true });
  // In a packaged build nodePath and cliPath are both gain-agent.exe. Invoke
  // that binary only once, but start the watchdog rather than a one-shot proxy
  // child so the Startup fallback also recovers from a later proxy crash.
  const binaryMode = !cliPath || samePath(nodePath, cliPath) || isPackagedSnapshotPath(cliPath);
  const parts = binaryMode
    ? [nodePath, ...windowsServiceRunArgs(host, port)]
    : [nodePath, cliPath, ...windowsServiceRunArgs(host, port)];
  const command = parts.map((part) => `Chr(34) & "${escapeVbs(part)}" & Chr(34)`).join(" & \" \" & ");
  const script = [
    "Option Explicit",
    "Dim shell, commandLine",
    "Set shell = CreateObject(\"WScript.Shell\")",
    `commandLine = ${command}`,
    "shell.Run commandLine, 0, False"
  ].join("\r\n");
  fs.writeFileSync(launcherPath, script, "utf8");
  return launcherPath;
}

function startWindowsWatchdogHidden({ hiddenRunnerPath: runnerPath, host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, execFile = execFileSync } = {}) {
  execFile("wscript.exe", [runnerPath, ...windowsServiceRunArgs(host, port)], { stdio: "ignore", windowsHide: true, env: packageSafeLaunchEnvironment() });
}

function startWindowsStartupLauncher({ launcherPath, execFile = execFileSync } = {}) {
  execFile("wscript.exe", [launcherPath], { stdio: "ignore", windowsHide: true, env: packageSafeLaunchEnvironment() });
}

function systemdUserUnitPath(homeDir = os.homedir()) {
  return path.join(homeDir, ".config", "systemd", "user", "gain-agent-proxy.service");
}

function installMacLaunchAgent(options = {}) {
  const homeDir = options.homeDir || os.homedir();
  const plistPath = options.plistPath || launchAgentPath(homeDir);
  const domain = macLaunchDomain(options);
  const command = serviceCommandLine(options);
  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${MAC_PROXY_LABEL}</string>
  <key>ProgramArguments</key>
  <array><string>/bin/sh</string><string>-lc</string><string>${escapeXml(command)}</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>${escapeXml(path.join(configDir(), "proxy.log"))}</string>
  <key>StandardErrorPath</key><string>${escapeXml(path.join(configDir(), "proxy.err.log"))}</string>
</dict>
</plist>
`;
  fs.mkdirSync(path.dirname(plistPath), { recursive: true });
  fs.writeFileSync(plistPath, plist, "utf8");
  const execFile = options.execFile || options.execFileSync || execFileSync;
  if (!domain) {
    return { ok: false, installed: false, plistPath, error: "Could not determine the logged-in macOS user. Run the installer from the developer's signed-in Terminal session." };
  }
  try { execFile("launchctl", ["bootout", domain, plistPath], { stdio: "ignore" }); } catch (_error) {}
  try {
    execFile("launchctl", ["bootstrap", domain, plistPath], { stdio: "pipe" });
    try { execFile("launchctl", ["kickstart", "-k", `${domain}/${MAC_PROXY_LABEL}`], { stdio: "ignore" }); } catch (_error) {}
    return { ok: true, installed: true, plistPath, domain, variant: "launchd" };
  } catch (bootstrapError) {
    // `bootstrap` is the supported path on current macOS. Retain a fallback for
    // older developer machines, but never claim success if both registrations fail.
    try {
      execFile("launchctl", ["load", plistPath], { stdio: "pipe" });
      return { ok: true, installed: true, plistPath, domain, variant: "launchd_legacy", warning: `bootstrap failed: ${bootstrapError.message}` };
    } catch (loadError) {
      try { fs.rmSync(plistPath, { force: true }); } catch (_error) {}
      return {
        ok: false,
        installed: false,
        plistPath,
        domain,
        error: `Could not register the macOS LaunchAgent: ${loadError.message}. Fix: run the installer from the logged-in user's Terminal, then rerun \`gain-agent proxy --service install\`.`
      };
    }
  }
}

function uninstallMacLaunchAgent(options = {}) {
  const plistPath = options.plistPath || launchAgentPath(options.homeDir || os.homedir());
  const domain = macLaunchDomain(options);
  const execFile = options.execFile || options.execFileSync || execFileSync;
  if (domain) {
    try { execFile("launchctl", ["bootout", domain, plistPath], { stdio: "ignore" }); } catch (_error) {}
  }
  try { execFile("launchctl", ["unload", plistPath], { stdio: "ignore" }); } catch (_error) {}
  fs.rmSync(plistPath, { force: true });
  return { ok: true, removed: [plistPath], domain };
}

function installLinuxUserService(options = {}) {
  const homeDir = options.homeDir || os.homedir();
  const unitPath = options.unitPath || systemdUserUnitPath(homeDir);
  const command = serviceCommandLine(options);
  const unit = `[Unit]
Description=G.A.I.N Agent local AI proxy

[Service]
ExecStart=/bin/sh -lc '${command.replace(/'/g, "'\\''")}'
Restart=always
RestartSec=2

[Install]
WantedBy=default.target
`;
  fs.mkdirSync(path.dirname(unitPath), { recursive: true });
  fs.writeFileSync(unitPath, unit, "utf8");
  const execFile = options.execFile || execFileSync;
  try { execFile("systemctl", ["--user", "daemon-reload"], { stdio: "ignore" }); } catch (_error) {}
  try { execFile("systemctl", ["--user", "enable", "--now", "gain-agent-proxy.service"], { stdio: "pipe" }); } catch (_error) {}
  return { ok: true, installed: true, unitPath };
}

function uninstallLinuxUserService(options = {}) {
  const unitPath = options.unitPath || systemdUserUnitPath(options.homeDir || os.homedir());
  const execFile = options.execFile || execFileSync;
  try { execFile("systemctl", ["--user", "disable", "--now", "gain-agent-proxy.service"], { stdio: "ignore" }); } catch (_error) {}
  fs.rmSync(unitPath, { force: true });
  try { execFile("systemctl", ["--user", "daemon-reload"], { stdio: "ignore" }); } catch (_error) {}
  return { ok: true, removed: [unitPath] };
}

function stopRecordedProxyProcesses(state = readProxyState()) {
  const stopped = [];
  for (const key of ["proxy_pid", "watchdog_pid"]) {
    const pid = Number(state[key]);
    if (!Number.isFinite(pid) || pid <= 0 || pid === process.pid) continue;
    try {
      process.kill(pid);
      stopped.push({ key, pid });
    } catch (_error) {
      // The process may already be gone. Uninstall should still succeed.
    }
  }
  return stopped;
}

function installProxyService(options = {}) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();
  const host = options.host || DEFAULT_PROXY_HOST;
  const port = Number(options.port || DEFAULT_PROXY_PORT);
  const failPolicy = normalizeFailPolicy(options.failPolicy || readConfigFile().proxy_fail_policy);

  let serviceResult;
  if (platform === "win32") {
    try {
      const args = windowsServiceRunArgs(host, port);
      const direct = windowsDirectCommand({ nodePath, cliPath, args });
      const command = serviceCommandLine({ nodePath: direct.command, cliPath: "", command: direct.args.join(" ") });
      // Do not depend on wscript.exe or a generated VBS file. A direct HKCU Run
      // value survives sign-in and is readable by doctor on every Windows SKU.
      runner("reg", windowsRunValueArgs(PROXY_RUN_VALUE, command), { stdio: "pipe", windowsHide: true });
      const legacyLauncherPath = options.startupLauncherPath || windowsStartupLauncherPath(options);
      try { fs.rmSync(legacyLauncherPath, { force: true }); } catch (_error) {}
      try { runner("schtasks", windowsDeleteTaskArgs(PROXY_TASK), { stdio: "ignore", windowsHide: true }); } catch (_error) {}
      if (options.startNow !== false) {
        startWindowsDirectCommand({ nodePath, cliPath, args, spawnFn: options.spawnFn });
      }
      serviceResult = { ok: true, installed: true, variant: "registry_run", runValueName: PROXY_RUN_VALUE, command };
    } catch (error) {
      serviceResult = {
        ok: false,
        installed: false,
        variant: null,
        error: `Could not register Windows sign-in startup: ${error.message}. Fix: verify the agent is installed under your user account, then run \`gain-agent proxy --service install\` again.`
      };
    }
  } else if (platform === "darwin") {
    serviceResult = installMacLaunchAgent({ ...options, nodePath, cliPath });
  } else {
    serviceResult = installLinuxUserService({ ...options, nodePath, cliPath });
  }

  const envResult = persistProxyEnvironment({
    // Never point a coding tool at localhost when the service registration
    // failed. This preserves the fail-open contract for a broken install.
    enabled: serviceResult.ok && failPolicy === "fail_closed",
    platform,
    homeDir: options.homeDir || os.homedir(),
    execFile: runner,
    url: proxyUrl(host, port)
  });

  const nextConfig = {
    ...readConfigFile(),
    proxy_service_enabled: serviceResult.ok,
    proxy_service_host: host,
    proxy_service_port: port,
    proxy_fail_policy: failPolicy
  };
  writeConfigFile(nextConfig);
  writeProxyState({
    enabled: serviceResult.ok,
    host,
    port,
    version: AGENT_VERSION,
    fail_policy: failPolicy,
    service_variant: serviceResult.variant || serviceResult.task || serviceResult.plistPath || serviceResult.unitPath || null,
    startup_launcher_path: serviceResult.startupLauncherPath || null,
    registry_run_value: serviceResult.runValueName || null
  });

  return {
    ok: serviceResult.ok && envResult.ok,
    host,
    port,
    failPolicy,
    env: envResult,
    service: serviceResult,
    message: !serviceResult.ok
      ? serviceResult.error
      : (failPolicy === "fail_closed"
      ? `Proxy service installed. Supported Anthropic and OpenAI-compatible tools route through ${proxyUrl(host, port)} after terminal restart.`
      : "Proxy service installed in fail-open mode. Client environment variables were not set.")
  };
}

function uninstallProxyService(options = {}) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  const state = readProxyState();
  let serviceResult;
  if (platform === "win32") {
    const removed = [];
    let warning = null;
    try {
      runner("schtasks", windowsDeleteTaskArgs(PROXY_TASK), { stdio: "pipe", windowsHide: true });
      removed.push(PROXY_TASK.name);
    } catch (error) {
      warning = error.message;
    }
    try {
      runner("reg", windowsDeleteRunValueArgs(PROXY_RUN_VALUE), { stdio: "ignore", windowsHide: true });
      removed.push(PROXY_RUN_VALUE);
    } catch (_error) {
      // The direct Run entry may not exist on installs created before 0.4.44.
    }
    const launcherPath = state.startup_launcher_path || windowsStartupLauncherPath(options);
    try {
      if (fs.existsSync(launcherPath)) {
        fs.rmSync(launcherPath, { force: true });
        removed.push(launcherPath);
      }
    } catch (error) {
      warning = warning ? `${warning}; ${error.message}` : error.message;
    }
    serviceResult = { ok: true, removed, warning };
  } else if (platform === "darwin") {
    serviceResult = uninstallMacLaunchAgent(options);
  } else {
    serviceResult = uninstallLinuxUserService(options);
  }

  const config = readConfigFile();
  const envResult = persistProxyEnvironment({
    enabled: false,
    platform,
    homeDir: options.homeDir || os.homedir(),
    execFile: runner,
    url: proxyUrl(config.proxy_service_host || state.host || DEFAULT_PROXY_HOST, config.proxy_service_port || state.port || DEFAULT_PROXY_PORT)
  });
  writeConfigFile({ ...readConfigFile(), proxy_service_enabled: false });
  const stopped = stopRecordedProxyProcesses(state);
  writeProxyState({ enabled: false, stopped_at: new Date().toISOString(), proxy_pid: null, watchdog_pid: null });
  return { ok: serviceResult.ok && envResult.ok, service: serviceResult, env: envResult, stopped };
}

function queryWindowsTask(options = {}) {
  const runner = options.execFileSync || execFileSync;
  try {
    const output = String(runner("schtasks", windowsQueryTaskArgs(PROXY_TASK), { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], windowsHide: true }) || "");
    const statusMatch = output.match(/Status:\s*(.+)/i);
    const status = statusMatch ? statusMatch[1].trim() : "";
    return { enabled: true, raw: output, running: /^Running$/i.test(status) };
  } catch (_error) {
    return { enabled: false, running: false, raw: "" };
  }
}

function queryWindowsStartupLauncher(options = {}) {
  const launcherPath = options.startupLauncherPath || windowsStartupLauncherPath(options);
  return { enabled: fs.existsSync(launcherPath), running: false, launcherPath };
}

function queryMacLaunchAgent(options = {}) {
  const plistPath = options.plistPath || launchAgentPath(options.homeDir || os.homedir());
  const domain = macLaunchDomain(options);
  const installed = fs.existsSync(plistPath);
  if (!installed || !domain) return { enabled: false, registered: false, plistPath, domain };
  const runner = options.execFileSync || options.execFile || execFileSync;
  try {
    runner("launchctl", ["print", `${domain}/${MAC_PROXY_LABEL}`], { stdio: ["ignore", "pipe", "ignore"] });
    return { enabled: true, registered: true, plistPath, domain };
  } catch (_error) {
    return { enabled: true, registered: false, plistPath, domain };
  }
}

function parseWmicMemoryCsv(output, numericPid) {
  const lines = String(output || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (lines.length < 2) return null;
  const header = lines[0].split(",").map((item) => item.trim().toLowerCase());
  for (const line of lines.slice(1)) {
    const values = line.split(",");
    const row = {};
    header.forEach((name, index) => { row[name] = values[index] ? values[index].trim() : ""; });
    const pid = Number(row.processid);
    if (pid !== numericPid) continue;
    const workingSetBytes = Number(row.workingsetsize);
    const pageFileKb = Number(row.pagefileusage);
    if (!Number.isFinite(workingSetBytes)) return null;
    return {
      pid,
      workingSetBytes,
      privateBytes: Number.isFinite(pageFileKb) ? pageFileKb * 1024 : null,
      name: row.name || null
    };
  }
  return null;
}

function readProcessMemory(pid, options = {}) {
  const numericPid = Number(pid);
  if (!Number.isFinite(numericPid) || numericPid <= 0) return null;
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  try {
    if (platform === "win32") {
      try {
        const wmicOutput = String(runner("wmic", [
          "process",
          "where",
          `processid=${numericPid}`,
          "get",
          "ProcessId,WorkingSetSize,PageFileUsage,Name",
          "/format:csv"
        ], {
          encoding: "utf8",
          stdio: ["ignore", "pipe", "ignore"],
          windowsHide: true
        }) || "");
        const parsed = parseWmicMemoryCsv(wmicOutput, numericPid);
        if (parsed) return parsed;
      } catch (_error) {
        // WMIC is absent on some Windows images. Fall back to PowerShell below.
      }
      const shell = options.powerShell || "powershell.exe";
      const command = [
        `$p = Get-Process -Id ${numericPid} -ErrorAction SilentlyContinue`,
        "if ($p) {",
        "  [pscustomobject]@{",
        "    pid = $p.Id;",
        "    workingSetBytes = [int64]$p.WorkingSet64;",
        "    privateBytes = [int64]$p.PrivateMemorySize64;",
        "    name = $p.ProcessName",
        "  } | ConvertTo-Json -Compress",
        "}"
      ].join("; ");
      const output = String(runner(shell, ["-NoProfile", "-Command", command], {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"],
        windowsHide: true
      }) || "").trim();
      if (!output) return null;
      return JSON.parse(output);
    }

    const output = String(runner("ps", ["-o", "rss=", "-p", String(numericPid)], {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"]
    }) || "").trim();
    const rssKb = Number(output.split(/\s+/)[0]);
    if (!Number.isFinite(rssKb)) return null;
    return { pid: numericPid, workingSetBytes: rssKb * 1024, privateBytes: null, name: null };
  } catch (_error) {
    return null;
  }
}

function serviceProcessMemory(state = readProxyState(), options = {}) {
  return {
    watchdog: readProcessMemory(state.watchdog_pid, options),
    proxy: readProcessMemory(state.proxy_pid, options)
  };
}

function probeProxyPort(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, timeoutMs = 500) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port });
    const done = (running) => {
      socket.removeAllListeners();
      socket.destroy();
      resolve(running);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => done(true));
    socket.once("timeout", () => done(false));
    socket.once("error", () => done(false));
  });
}

// A port can be open because of an unrelated local program. Only report a
// healthy proxy to hooks and status once the listener identifies itself as the
// G.A.I.N proxy. This prevents a redaction policy from being silently skipped
// because a different process happened to bind 127.0.0.1:8787.
function probeGainProxy(host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, timeoutMs = 500) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (healthy) => {
      if (settled) return;
      settled = true;
      resolve(healthy);
    };
    const request = http.get({ host, port, path: PROXY_HEALTH_PATH }, (response) => {
      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => {
        body += chunk;
        if (body.length > 4096) request.destroy();
      });
      response.on("end", () => {
        try {
          const parsed = JSON.parse(body);
          done(response.statusCode === 200 && parsed?.ok === true && parsed?.service === "gain-agent-proxy");
        } catch (_error) {
          done(false);
        }
      });
      response.on("error", () => done(false));
    });
    request.setTimeout(timeoutMs, () => request.destroy());
    request.on("error", () => done(false));
    request.on("close", () => done(false));
  });
}

async function getProxyServiceStatus(options = {}) {
  const config = readConfigFile();
  const host = config.proxy_service_host || DEFAULT_PROXY_HOST;
  const port = Number(config.proxy_service_port || DEFAULT_PROXY_PORT);
  const state = readProxyState();
  const platform = options.platform || process.platform;
  const enabled = config.proxy_service_enabled === true;
  const running = options.probe
    ? await options.probe(host, port)
    : await probeGainProxy(host, port, options.timeoutMs || 500);
  const task = platform === "win32" ? queryWindowsTask(options) : { enabled, running };
  const startup = platform === "win32" ? queryWindowsStartupLauncher(options) : { enabled: false, running: false };
  const registry = platform === "win32" ? queryWindowsRunValue(PROXY_RUN_VALUE, { execFileSync: options.execFileSync || execFileSync }) : { enabled: false };
  const macLaunchAgent = platform === "darwin" ? queryMacLaunchAgent(options) : { enabled: false, registered: false };
  const service = platform === "win32"
    ? { enabled: task.enabled || startup.enabled || registry.enabled, running: task.running || running, task, startup, registry }
    : (platform === "darwin"
      ? { enabled: macLaunchAgent.enabled, running, macLaunchAgent }
      : { enabled, running });
  const processMemory = options.includeProcessMemory === false
    ? null
    : serviceProcessMemory(state, { ...options, platform });
  return {
    enabled,
    serviceEnabled: service.enabled,
    serviceVariant: platform === "win32"
      ? (registry.enabled ? "registry_run" : (task.enabled ? "scheduled_task" : (startup.enabled ? "startup_folder" : null)))
      : (platform === "darwin" ? (macLaunchAgent.enabled ? "launchd" : null) : (state.service_variant || null)),
    running,
    version: state.version || AGENT_VERSION,
    host,
    port,
    url: `http://${host}:${port}`,
    failPolicy: normalizeFailPolicy(config.proxy_fail_policy),
    lastRequestAt: state.last_request_at || null,
    portConflict: state.port_conflict === true && state.host === host && Number(state.port) === port,
    portConflictRetryAt: state.port_conflict_retry_at || null,
    lastProxyError: state.last_spawn_error || null,
    processMemory,
    env: {
      ANTHROPIC_BASE_URL: process.env.ANTHROPIC_BASE_URL || null,
      OPENAI_BASE_URL: process.env.OPENAI_BASE_URL || null,
      OPENAI_API_BASE: process.env.OPENAI_API_BASE || null,
      COPILOT_PROVIDER_BASE_URL: process.env.COPILOT_PROVIDER_BASE_URL || null
    },
    macLaunchAgent: platform === "darwin" ? macLaunchAgent : null
  };
}

function parseLoopbackProxyUrl(value) {
  if (!value) return null;
  let parsed;
  try { parsed = new URL(String(value)); } catch (_error) { return null; }
  if (!/^https?:$/i.test(parsed.protocol)) return null;
  const host = String(parsed.hostname || "").replace(/^\[|\]$/g, "").toLowerCase();
  const isLoopback = host === "localhost" || host === "127.0.0.1" || host === "::1";
  if (!isLoopback) return null;
  const port = Number(parsed.port || (parsed.protocol === "https:" ? 443 : 80));
  if (!Number.isFinite(port) || port < 1 || port > 65535) return null;
  return { host: host === "localhost" ? "127.0.0.1" : host, port, url: parsed.toString() };
}

async function isLocalProxyRoutingActive(options = {}) {
  const env = options.env || process.env;
  const target = parseLoopbackProxyUrl(options.url || env.ANTHROPIC_BASE_URL);
  if (!target) return false;
  const probe = options.probe || probeGainProxy;
  try {
    return Boolean(await probe(target.host, target.port, options.timeoutMs || 250));
  } catch (_error) {
    return false;
  }
}

function samePath(left, right) {
  if (!left || !right) return false;
  try {
    return path.resolve(String(left)).toLowerCase() === path.resolve(String(right)).toLowerCase();
  } catch (_error) {
    return String(left).toLowerCase() === String(right).toLowerCase();
  }
}

function isPackagedSnapshotPath(value) {
  return /(?:^|[\\/])snapshot(?:[\\/]|$)/i.test(String(value || ""));
}

function proxyChildCommand({ host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  // @yao-pkg embeds source files below C:\\snapshot but does not consistently
  // expose process.pkg. Passing that internal path back to gain-agent.exe makes
  // the child exit as if the snapshot filename were a command.
  const binaryMode = !cliPath || samePath(nodePath, cliPath) || isPackagedSnapshotPath(cliPath);
  return {
    command: nodePath,
    args: binaryMode
      ? ["proxy", "--host", host, "--port", String(port)]
      : [cliPath, "proxy", "--host", host, "--port", String(port)]
  };
}

function proxyChildEnvironment(env = process.env) {
  const childEnv = { ...env, GAIN_PROXY_SERVICE_CHILD: "1" };
  // pkg's patched spawn adds its own executable path when this is absent. That
  // makes a self-spawned child treat "proxy" as a JavaScript entry file. An
  // explicitly blank value preserves the normal packaged entrypoint instead.
  childEnv.PKG_EXECPATH = "";
  return childEnv;
}

function packageSafeLaunchEnvironment(env = process.env) {
  // @yao-pkg patches child_process and otherwise adds its executable path to
  // every child. WScript passes that value on to gain-agent, where it breaks
  // command dispatch. A blank explicit value prevents the injected override.
  return { ...env, PKG_EXECPATH: "" };
}

function spawnProxyChild({ host = DEFAULT_PROXY_HOST, port = DEFAULT_PROXY_PORT, nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const { command, args } = proxyChildCommand({ host, port, nodePath, cliPath });
  const child = spawn(command, args, {
    detached: false,
    stdio: "ignore",
    windowsHide: true,
    env: proxyChildEnvironment()
  });
  return child;
}

function runProxyServiceWatchdog(options = {}) {
  const host = options.host || DEFAULT_PROXY_HOST;
  const port = Number(options.port || DEFAULT_PROXY_PORT);
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();
  const processRef = options.processRef || process;
  const writeState = options.writeState || writeProxyState;
  const spawnChild = options.spawnChild || spawnProxyChild;
  const probePort = options.probePort || probeProxyPort;
  const setTimeoutFn = options.setTimeout || setTimeout;
  const clearTimeoutFn = options.clearTimeout || clearTimeout;
  const restartDelayMs = Number(options.restartDelayMs || 2000);
  const portConflictRetryMs = Number(options.portConflictRetryMs || PORT_CONFLICT_RETRY_MS);
  let stopping = false;
  let restartCount = 0;
  let restartTimer = null;

  writeState({
    enabled: true,
    watchdog_pid: processRef.pid,
    host,
    port,
    version: AGENT_VERSION,
    started_at: new Date().toISOString(),
    watchdog_node_path: nodePath,
    watchdog_cli_path: cliPath || null
  });

  const scheduleRestart = (delayMs) => {
    if (stopping) return;
    restartTimer = setTimeoutFn(start, delayMs);
  };

  const start = async () => {
    if (stopping) return;
    let occupied = false;
    try {
      occupied = await probePort(host, port, options.probeTimeoutMs || 250);
    } catch (_error) {
      occupied = false;
    }
    if (stopping) return;
    if (occupied) {
      restartCount += 1;
      const retryAt = new Date(Date.now() + portConflictRetryMs).toISOString();
      writeState({
        enabled: true,
        watchdog_pid: processRef.pid,
        host,
        port,
        version: AGENT_VERSION,
        port_conflict: true,
        restart_count: restartCount,
        last_spawn_error: `Port ${host}:${port} is already in use by another local process.`,
        port_conflict_retry_at: retryAt,
        last_exit_at: new Date().toISOString()
      });
      scheduleRestart(portConflictRetryMs);
      return;
    }

    const child = spawnChild({ host, port, nodePath, cliPath });
    writeState({
      proxy_pid: child.pid,
      restart_count: restartCount,
      host,
      port,
      version: AGENT_VERSION,
      port_conflict: false,
      port_conflict_retry_at: null,
      last_spawn_error: null,
      proxy_command: child.spawnfile || null,
      proxy_args: Array.isArray(child.spawnargs) ? child.spawnargs.slice(1) : []
    });
    child.on("error", (error) => {
      writeState({ last_spawn_error: error.message, last_exit_at: new Date().toISOString() });
    });
    child.on("exit", (code, signal) => {
      if (stopping) return;
      restartCount += 1;
      writeState({
        last_exit_at: new Date().toISOString(),
        restart_count: restartCount,
        last_exit_code: Number.isInteger(code) ? code : null,
        last_exit_signal: signal || null
      });
      scheduleRestart(restartDelayMs);
    });
  };

  const stop = () => {
    if (stopping) return;
    stopping = true;
    if (restartTimer) clearTimeoutFn(restartTimer);
    writeState({ stopped_at: new Date().toISOString() });
    processRef.exit(0);
  };
  processRef.on("SIGTERM", stop);
  processRef.on("SIGINT", stop);

  start();
}

function escapeXml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function escapeVbs(value) {
  return String(value || "").replace(/"/g, "\"\"");
}

module.exports = {
  DEFAULT_PROXY_HOST,
  DEFAULT_PROXY_PORT,
  PROXY_URL,
  PROXY_TASK,
  PROXY_RUN_VALUE,
  ENV_VARS,
  proxyUrl,
  proxyStatePath,
  readProxyState,
  writeProxyState,
  markProxyRequest,
  normalizeFailPolicy,
  readProcessMemory,
  serviceProcessMemory,
  serviceCommandLine,
  persistProxyEnvironment,
  clearGainProxyEnvironment,
  sameProxyUrl,
  readWindowsUserEnv,
  installProxyService,
  uninstallProxyService,
  stopRecordedProxyProcesses,
  getProxyServiceStatus,
  runProxyServiceWatchdog,
  isLocalProxyRoutingActive,
  parseLoopbackProxyUrl,
  probeProxyPort,
  probeGainProxy,
  proxyChildCommand,
  proxyChildEnvironment,
  packageSafeLaunchEnvironment,
  isPackagedSnapshotPath,
  windowsStartupDir,
  windowsStartupLauncherPath,
  writeWindowsStartupLauncher,
  startWindowsWatchdogHidden,
  startWindowsStartupLauncher,
  launchAgentPath,
  macLaunchDomain,
  installMacLaunchAgent,
  uninstallMacLaunchAgent,
  queryMacLaunchAgent,
  systemdUserUnitPath,
  profilePaths
};
