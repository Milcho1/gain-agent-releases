"use strict";

const { readConfigFile, writeConfigFile, configPath } = require("../config/loadPolicy");
const { uninstallHealthSchedule } = require("./healthSchedule");
const { stopRecordedHealthService } = require("./healthService");

const REMOVED_BY_ADMIN_NOTICE = "This device was paused or removed by your G.A.I.N admin. The agent is now inactive. Run 'gain-agent setup' to re-enroll.";

function isRevokedResponse(result) {
  return Boolean(result && result.revoked === true && String(result.reason || "") === "removed_by_admin");
}

function markAgentDormant({
  uninstallSchedule = uninstallHealthSchedule,
  stopHealthService = stopRecordedHealthService,
  now = () => new Date()
} = {}) {
  const current = readConfigFile();
  writeConfigFile({
    ...current,
    active: false,
    inactive_reason: "removed_by_admin",
    inactive_at: now().toISOString()
  });

  let schedule = null;
  try {
    schedule = uninstallSchedule();
  } catch (error) {
    schedule = { ok: false, errors: [{ task: "health schedule", error: error.message }] };
  }

  let healthService = null;
  try {
    // The receiving presence child is not the long-running health service.
    // Stop that parent as well so a remote pause takes effect immediately
    // after the revocation response instead of waiting for its next timer.
    healthService = stopHealthService();
  } catch (error) {
    healthService = { ok: false, error: error.message };
  }

  return {
    ok: true,
    notice: REMOVED_BY_ADMIN_NOTICE,
    config_path: configPath(),
    schedule,
    healthService
  };
}

module.exports = {
  REMOVED_BY_ADMIN_NOTICE,
  isRevokedResponse,
  markAgentDormant
};
