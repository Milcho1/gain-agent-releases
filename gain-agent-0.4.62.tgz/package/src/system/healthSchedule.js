"use strict";

const os = require("os");
const path = require("path");
const fs = require("fs");
const { execFileSync, spawn } = require("child_process");
const { configDir } = require("../config/loadPolicy");

const TASKS = [
  {
    name: "G.A.I.N Agent Presence",
    command: "presence",
    args: ["/SC", "MINUTE", "/MO", "5"],
    description: "lightweight online presence every 5 minutes"
  },
  {
    name: "G.A.I.N Agent Heartbeat",
    command: "sync",
    args: ["/SC", "HOURLY", "/MO", "1"],
    description: "policy sync and deployment heartbeat every hour"
  },
  {
    name: "G.A.I.N Agent Desktop Guard",
    command: "desktop-guard",
    args: ["/SC", "ONLOGON"],
    description: "desktop AI clipboard guard at user logon"
  }
];

const UPDATE_TASKS = [
  {
    name: "G.A.I.N Agent Update",
    command: "update --scheduled",
    args: ["/SC", "DAILY", "/ST", "03:15"],
    description: "daily checksum-verified update check"
  }
];
const HEALTH_STARTUP_LAUNCHER = "G.A.I.N Agent Health.vbs";
const WINDOWS_RUN_KEY = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run";
const HEALTH_RUN_VALUE = "G.A.I.N Agent Health";
const MAC_HEALTH_LABEL = "com.cyberwardion.gain-agent.health";
const MAC_UPDATE_LABEL = "com.cyberwardion.gain-agent.update";

function defaultCliPath() {
  return process.pkg ? "" : path.resolve(__dirname, "..", "cli", "index.js");
}

function stableConfigDir() {
  return path.join(os.homedir(), ".gain");
}

function macHealthLaunchAgentPath(homeDir = os.homedir()) {
  return path.join(homeDir, "Library", "LaunchAgents", `${MAC_HEALTH_LABEL}.plist`);
}

function macUpdateLaunchAgentPath(homeDir = os.homedir()) {
  return path.join(homeDir, "Library", "LaunchAgents", `${MAC_UPDATE_LABEL}.plist`);
}

function macLaunchDomain(options = {}) {
  const userId = options.userId !== undefined
    ? Number(options.userId)
    : (typeof process.getuid === "function" ? Number(process.getuid()) : Number(os.userInfo().uid));
  return Number.isFinite(userId) && userId >= 0 ? `gui/${userId}` : null;
}

function escapeXml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function installMacHealthLaunchAgent(options = {}) {
  const homeDir = options.homeDir || os.homedir();
  const plistPath = options.plistPath || macHealthLaunchAgentPath(homeDir);
  const domain = macLaunchDomain(options);
  const runner = options.execFileSync || execFileSync;
  const command = commandLine(options.nodePath || process.execPath, options.cliPath !== undefined ? options.cliPath : defaultCliPath(), "health-service");
  if (!domain) {
    return { ok: false, installed: false, errors: [{ task: MAC_HEALTH_LABEL, error: "Could not determine the logged-in macOS user. Run the installer from the developer's Terminal session." }] };
  }
  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>${MAC_HEALTH_LABEL}</string>
  <key>ProgramArguments</key><array><string>/bin/sh</string><string>-lc</string><string>${escapeXml(command)}</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>${escapeXml(path.join(configDir(), "health-service.log"))}</string>
  <key>StandardErrorPath</key><string>${escapeXml(path.join(configDir(), "health-service.err.log"))}</string>
</dict></plist>
`;
  fs.mkdirSync(path.dirname(plistPath), { recursive: true });
  fs.writeFileSync(plistPath, plist, "utf8");
  try { runner("launchctl", ["bootout", domain, plistPath], { stdio: "ignore" }); } catch (_error) {}
  try {
    runner("launchctl", ["bootstrap", domain, plistPath], { stdio: "pipe" });
    try { runner("launchctl", ["kickstart", "-k", `${domain}/${MAC_HEALTH_LABEL}`], { stdio: "ignore" }); } catch (_error) {}
    return { ok: true, installed: true, variant: "launchd", plistPath, domain, purpose: "presence/heartbeat" };
  } catch (bootstrapError) {
    try {
      runner("launchctl", ["load", plistPath], { stdio: "pipe" });
      return { ok: true, installed: true, variant: "launchd_legacy", plistPath, domain, purpose: "presence/heartbeat", warning: `bootstrap failed: ${bootstrapError.message}` };
    } catch (loadError) {
      try { fs.rmSync(plistPath, { force: true }); } catch (_error) {}
      return {
        ok: false,
        installed: false,
        errors: [{ task: MAC_HEALTH_LABEL, error: `Could not register the macOS health LaunchAgent: ${loadError.message}. Fix: run \`gain-agent install-health-schedule\` from the logged-in developer's Terminal.` }],
        purpose: "presence/heartbeat"
      };
    }
  }
}

function uninstallMacHealthLaunchAgent(options = {}) {
  const plistPath = options.plistPath || macHealthLaunchAgentPath(options.homeDir || os.homedir());
  const domain = macLaunchDomain(options);
  const runner = options.execFileSync || execFileSync;
  if (domain) {
    try { runner("launchctl", ["bootout", domain, plistPath], { stdio: "ignore" }); } catch (_error) {}
  }
  try { runner("launchctl", ["unload", plistPath], { stdio: "ignore" }); } catch (_error) {}
  fs.rmSync(plistPath, { force: true });
  return { ok: true, removed: [plistPath], domain, purpose: "presence/heartbeat" };
}

function macHealthLaunchAgentStatus(options = {}) {
  const plistPath = options.plistPath || macHealthLaunchAgentPath(options.homeDir || os.homedir());
  const domain = macLaunchDomain(options);
  const installed = fs.existsSync(plistPath);
  if (!installed || !domain) return { installed: false, registered: false, plistPath, domain };
  try {
    (options.execFileSync || execFileSync)("launchctl", ["print", `${domain}/${MAC_HEALTH_LABEL}`], { stdio: ["ignore", "pipe", "ignore"] });
    return { installed: true, registered: true, plistPath, domain };
  } catch (_error) {
    return { installed: true, registered: false, plistPath, domain };
  }
}

function installMacAutoUpdateLaunchAgent(options = {}) {
  const homeDir = options.homeDir || os.homedir();
  const plistPath = options.plistPath || macUpdateLaunchAgentPath(homeDir);
  const domain = macLaunchDomain(options);
  const runner = options.execFileSync || execFileSync;
  const command = commandLine(options.nodePath || process.execPath, options.cliPath !== undefined ? options.cliPath : defaultCliPath(), "update --scheduled");
  if (!domain) {
    return { ok: false, installed: false, errors: [{ task: MAC_UPDATE_LABEL, error: "Could not determine the logged-in macOS user. Run the installer from the developer's Terminal session." }] };
  }
  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>${MAC_UPDATE_LABEL}</string>
  <key>ProgramArguments</key><array><string>/bin/sh</string><string>-lc</string><string>${escapeXml(command)}</string></array>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>3</integer><key>Minute</key><integer>15</integer></dict>
  <key>StandardOutPath</key><string>${escapeXml(path.join(configDir(), "auto-update.log"))}</string>
  <key>StandardErrorPath</key><string>${escapeXml(path.join(configDir(), "auto-update.err.log"))}</string>
</dict></plist>
`;
  fs.mkdirSync(path.dirname(plistPath), { recursive: true });
  fs.writeFileSync(plistPath, plist, "utf8");
  try { runner("launchctl", ["bootout", domain, plistPath], { stdio: "ignore" }); } catch (_error) {}
  try {
    runner("launchctl", ["bootstrap", domain, plistPath], { stdio: "pipe" });
    return { ok: true, installed: true, variant: "launchd", plistPath, domain, purpose: "auto-update" };
  } catch (bootstrapError) {
    try {
      runner("launchctl", ["load", plistPath], { stdio: "pipe" });
      return { ok: true, installed: true, variant: "launchd_legacy", plistPath, domain, purpose: "auto-update", warning: `bootstrap failed: ${bootstrapError.message}` };
    } catch (loadError) {
      try { fs.rmSync(plistPath, { force: true }); } catch (_error) {}
      return {
        ok: false,
        installed: false,
        errors: [{ task: MAC_UPDATE_LABEL, error: `Could not register the macOS update LaunchAgent: ${loadError.message}. Fix: run \`gain-agent enable-auto-update\` from the logged-in developer's Terminal.` }],
        purpose: "auto-update"
      };
    }
  }
}

function uninstallMacAutoUpdateLaunchAgent(options = {}) {
  const plistPath = options.plistPath || macUpdateLaunchAgentPath(options.homeDir || os.homedir());
  const domain = macLaunchDomain(options);
  const runner = options.execFileSync || execFileSync;
  if (domain) {
    try { runner("launchctl", ["bootout", domain, plistPath], { stdio: "ignore" }); } catch (_error) {}
  }
  try { runner("launchctl", ["unload", plistPath], { stdio: "ignore" }); } catch (_error) {}
  fs.rmSync(plistPath, { force: true });
  return { ok: true, removed: [plistPath], domain, purpose: "auto-update" };
}

function commandLine(nodePath, cliPath, command) {
  const executable = shellQuoteForCommand(nodePath);
  if (!cliPath) return `${executable} ${command}`;
  return `${executable} ${shellQuoteForCommand(cliPath)} ${command}`;
}

function isPackagedSnapshotPath(value) {
  return /(?:^|[\\/])snapshot(?:[\\/]|$)/i.test(String(value || ""));
}

function windowsDirectCommand({ nodePath = process.execPath, cliPath = defaultCliPath(), args = [] } = {}) {
  const binaryMode = !cliPath || samePath(nodePath, cliPath) || isPackagedSnapshotPath(cliPath);
  return {
    command: nodePath,
    args: binaryMode ? args : [cliPath, ...args]
  };
}

function startWindowsDirectCommand(options = {}) {
  const child = (options.spawnFn || spawn)(
    windowsDirectCommand(options).command,
    windowsDirectCommand(options).args,
    {
      detached: true,
      stdio: "ignore",
      windowsHide: true,
      env: { ...process.env, PKG_EXECPATH: "" }
    }
  );
  if (child && typeof child.unref === "function") child.unref();
  return child;
}

function samePath(left, right) {
  if (!left || !right) return false;
  try {
    return path.resolve(String(left)).toLowerCase() === path.resolve(String(right)).toLowerCase();
  } catch (_error) {
    return String(left).toLowerCase() === String(right).toLowerCase();
  }
}

function windowsRunValueArgs(name, command) {
  return ["add", WINDOWS_RUN_KEY, "/v", name, "/t", "REG_SZ", "/d", command, "/f"];
}

function windowsDeleteRunValueArgs(name) {
  return ["delete", WINDOWS_RUN_KEY, "/v", name, "/f"];
}

function windowsQueryRunValueArgs(name) {
  return ["query", WINDOWS_RUN_KEY, "/v", name];
}

function queryWindowsRunValue(name, { execFileSync: runner = execFileSync } = {}) {
  try {
    const output = String(runner("reg", windowsQueryRunValueArgs(name), {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      windowsHide: true
    }) || "");
    const line = output.split(/\r?\n/).find((item) => new RegExp(`^\\s*${name.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\$&")}\\s+REG_`, "i").test(item));
    const match = line && line.match(/\sREG_\w+\s+(.*)$/i);
    return { enabled: Boolean(match), command: match ? match[1].trim() : null, raw: output };
  } catch (_error) {
    return { enabled: false, command: null, raw: "" };
  }
}

function hiddenRunnerPath(options = {}) {
  const dir = options.useCurrentConfigDir === true ? configDir() : stableConfigDir();
  return path.join(dir, "run-hidden.vbs");
}

function windowsStartupDir(options = {}) {
  const appData = options.appData || process.env.APPDATA || path.join(os.homedir(), "AppData", "Roaming");
  return path.join(appData, "Microsoft", "Windows", "Start Menu", "Programs", "Startup");
}

function windowsHealthStartupLauncherPath(options = {}) {
  return path.join(options.startupDir || windowsStartupDir(options), HEALTH_STARTUP_LAUNCHER);
}

function writeWindowsHealthStartupLauncher({ runnerPath = hiddenRunnerPath(), launcherPath = windowsHealthStartupLauncherPath() } = {}) {
  fs.mkdirSync(path.dirname(launcherPath), { recursive: true });
  const command = `wscript.exe "${runnerPath}" health-service`;
  const script = [
    "Option Explicit",
    "Dim shell",
    "Set shell = CreateObject(\"WScript.Shell\")",
    `shell.Run \"${escapeVbs(command)}\", 0, False`
  ].join("\r\n");
  fs.writeFileSync(launcherPath, script, "utf8");
  return launcherPath;
}

function startWindowsHealthStartupLauncher({ launcherPath, execFile = execFileSync } = {}) {
  execFile("wscript.exe", [launcherPath], {
    stdio: "ignore",
    windowsHide: true,
    env: { ...process.env, PKG_EXECPATH: "" }
  });
}

function writeWindowsHiddenRunner({ nodePath, cliPath, runnerPath = hiddenRunnerPath() } = {}) {
  fs.mkdirSync(path.dirname(runnerPath), { recursive: true });
  const script = [
    "Option Explicit",
    "Dim shell, args, commandLine, i, arg",
    "Set shell = CreateObject(\"WScript.Shell\")",
    "Set args = WScript.Arguments",
    "If args.Count < 1 Then WScript.Quit 1",
    cliPath
      ? `commandLine = Chr(34) & "${escapeVbs(nodePath)}" & Chr(34) & " " & Chr(34) & "${escapeVbs(cliPath)}" & Chr(34)`
      : `commandLine = Chr(34) & "${escapeVbs(nodePath)}" & Chr(34)`,
    "For i = 0 To args.Count - 1",
    "  arg = Replace(args.Item(i), Chr(34), Chr(34) & Chr(34))",
    "  commandLine = commandLine & \" \" & Chr(34) & arg & Chr(34)",
    "Next",
    "shell.Run commandLine, 0, False"
  ].join("\r\n");
  fs.writeFileSync(runnerPath, script, "utf8");
  return runnerPath;
}

function taskRunCommand(nodePath, cliPath, command, options = {}) {
  return commandLine(nodePath, cliPath, command);
}

function windowsCreateTaskArgs(task, { nodePath, cliPath, hiddenRunnerPath: runnerPath }) {
  return [
    "/Create",
    "/TN", task.name,
    ...task.args,
    "/TR", taskRunCommand(nodePath, cliPath, task.command, { hiddenRunnerPath: runnerPath }),
    "/F"
  ];
}

function windowsDeleteTaskArgs(task) {
  return ["/Delete", "/TN", task.name, "/F"];
}

function windowsQueryTaskArgs(task) {
  return ["/Query", "/TN", task.name, "/V", "/FO", "LIST"];
}

function taskAlreadyInstalled(task, { execFileSync: runner = execFileSync } = {}) {
  try {
    const output = String(runner("schtasks", windowsQueryTaskArgs(task), { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }) || "");
    return output.includes(task.command);
  } catch (_error) {
    return false;
  }
}

function manualScheduleInstructions({ nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const commandPrefix = commandLine(nodePath, cliPath, "");
  return [
    "Automatic health scheduling is installed directly on Windows.",
    "For macOS/Linux, add these user cron entries or deploy the equivalent with your MDM:",
    "",
    `*/5 * * * * ${commandPrefix}presence >/tmp/gain-agent-presence.log 2>&1`,
    `0 * * * * ${commandPrefix}sync >/tmp/gain-agent-heartbeat.log 2>&1`,
    `@reboot ${commandPrefix}desktop-guard >/tmp/gain-agent-desktop-guard.log 2>&1`,
    "",
    `Config is read from ${path.join(os.homedir(), ".gain", "config.json")} unless GAIN_CONFIG_DIR is set.`
  ].join("\n");
}

function installHealthSchedule(options = {}) {
  const platform = options.platform || process.platform;
  if (platform === "darwin") return installMacHealthLaunchAgent(options);
  if (platform !== "win32") return installWindowsOrManualTasks(TASKS, options, "presence/heartbeat");

  const runner = options.execFileSync || execFileSync;
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();
  const args = ["health-service"];
  const direct = windowsDirectCommand({ nodePath, cliPath, args });
  const command = [shellQuoteForCommand(direct.command), ...direct.args.map(shellQuoteForCommand)].join(" ");

  try {
    // A direct per-user Run entry avoids Windows Script Host entirely. It also
    // works where a company policy denies a user-created scheduled task.
    runner("reg", windowsRunValueArgs(HEALTH_RUN_VALUE, command), { stdio: "pipe", windowsHide: true });
    const legacyLauncherPath = options.startupLauncherPath || windowsHealthStartupLauncherPath(options);
    try { fs.rmSync(legacyLauncherPath, { force: true }); } catch (_error) {}
    for (const task of TASKS) {
      try { runner("schtasks", windowsDeleteTaskArgs(task), { stdio: "ignore", windowsHide: true }); } catch (_error) {}
    }
    if (options.startNow !== false) {
      startWindowsDirectCommand({ nodePath, cliPath, args, spawnFn: options.spawnFn });
    }
    return {
      ok: true,
      installed: true,
      variant: "registry_run",
      runValueName: HEALTH_RUN_VALUE,
      command,
      purpose: "presence/heartbeat"
    };
  } catch (error) {
    return {
      ok: false,
      installed: false,
      errors: [{
        task: HEALTH_RUN_VALUE,
        error: `Could not register Windows sign-in startup: ${error.message}. Fix: verify the agent is installed under your user account, then run \`gain-agent install-health-schedule\` again.`
      }],
      purpose: "presence/heartbeat"
    };
  }
}

function installDesktopGuardSchedule(options = {}) {
  if ((options.platform || process.platform) === "darwin") {
    // The macOS health LaunchAgent owns the long-running clipboard guard as
    // well as heartbeat/sync. Avoid a second competing guard process.
    return installMacHealthLaunchAgent(options);
  }
  return installWindowsOrManualTasks([TASKS[2]], options, "desktop-guard");
}

function installAutoUpdateSchedule(options = {}) {
  if ((options.platform || process.platform) === "darwin") return installMacAutoUpdateLaunchAgent(options);
  return installWindowsOrManualTasks(UPDATE_TASKS, options, "auto-update");
}

function installWindowsOrManualTasks(tasks, options = {}, purpose = "schedule") {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();

  if (platform !== "win32") {
    return {
      ok: true,
      installed: false,
      manual: true,
      instructions: purpose === "auto-update"
        ? autoUpdateManualScheduleInstructions({ nodePath, cliPath })
        : manualScheduleInstructions({ nodePath, cliPath })
    };
  }

  const installed = [];
  const errors = [];
  for (const task of tasks) {
    try {
      if (taskAlreadyInstalled(task, { execFileSync: runner })) {
        installed.push({ name: task.name, description: `${task.description} (already installed)` });
        continue;
      }
      runner("schtasks", windowsCreateTaskArgs(task, { nodePath, cliPath }), { stdio: "pipe" });
      installed.push({ name: task.name, description: task.description });
    } catch (error) {
      errors.push({ task: task.name, error: error.message });
    }
  }
  return { ok: errors.length === 0, installed: installed.length > 0, tasks: installed, errors, purpose };
}

function windowsTaskRunnerDiagnostics(tasks = [...TASKS, ...UPDATE_TASKS], options = {}) {
  const platform = options.platform || process.platform;
  if (platform !== "win32") return [];
  const runner = options.execFileSync || execFileSync;
  const exists = options.existsSync || fs.existsSync;
  const tempDir = String(options.tempDir || os.tmpdir()).toLowerCase();
  const expectedRunner = String(options.expectedRunnerPath || hiddenRunnerPath()).toLowerCase();
  const diagnostics = [];

  for (const task of tasks) {
    let output = "";
    try {
      output = String(runner("schtasks", windowsQueryTaskArgs(task), { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }) || "");
    } catch (_error) {
      continue;
    }
    const runCommand = extractTaskRunCommand(output);
    const scriptPath = extractHiddenRunnerScriptPath(runCommand);
    if (!scriptPath) continue;
    const lower = scriptPath.toLowerCase();
    if (lower.startsWith(tempDir) && lower !== expectedRunner) {
      diagnostics.push({
        task: task.name,
        runnerPath: scriptPath,
        reason: "points_to_temp_runner"
      });
      continue;
    }
    if (!exists(scriptPath)) {
      diagnostics.push({
        task: task.name,
        runnerPath: scriptPath,
        reason: "runner_missing"
      });
    }
  }

  return diagnostics;
}

function healthScheduleStatus(options = {}) {
  const platform = options.platform || process.platform;
  if (platform === "darwin") {
    const mac = macHealthLaunchAgentStatus(options);
    return {
      supported: true,
      scheduled: mac.registered,
      registryRun: false,
      startupFallback: false,
      launchAgent: mac,
      missing: mac.registered ? [] : [MAC_HEALTH_LABEL]
    };
  }
  if (platform !== "win32") return { supported: false, scheduled: false, registryRun: false, startupFallback: false, missing: [] };
  const runner = options.execFileSync || execFileSync;
  const missing = [];
  for (const task of TASKS) {
    try {
      runner("schtasks", windowsQueryTaskArgs(task), { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], windowsHide: true });
    } catch (_error) {
      missing.push(task.name);
    }
  }
  const launcherPath = options.startupLauncherPath || windowsHealthStartupLauncherPath(options);
  const registry = queryWindowsRunValue(HEALTH_RUN_VALUE, { execFileSync: runner });
  return {
    supported: true,
    scheduled: missing.length === 0,
    registryRun: registry.enabled,
    registryCommand: registry.command,
    runValueName: HEALTH_RUN_VALUE,
    startupFallback: fs.existsSync(launcherPath),
    launcherPath,
    missing
  };
}

function extractTaskRunCommand(output) {
  const line = String(output || "").split(/\r?\n/).find((item) => /Task To Run\s*:/i.test(item));
  if (!line) return "";
  return line.replace(/^.*?Task To Run\s*:\s*/i, "").trim();
}

function extractHiddenRunnerScriptPath(command) {
  const text = String(command || "");
  const quoted = text.match(/"([^"]*run-hidden\.vbs)"/i);
  if (quoted) return quoted[1];
  const bare = text.match(/([A-Z]:\\[^\s"]*run-hidden\.vbs)/i);
  return bare ? bare[1] : "";
}

function autoUpdateManualScheduleInstructions({ nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const commandPrefix = commandLine(nodePath, cliPath, "");
  return [
    "For macOS/Linux, add this user cron entry or deploy the equivalent with your MDM:",
    "",
    `15 3 * * * ${commandPrefix}update --scheduled >/tmp/gain-agent-update.log 2>&1`,
    "",
    `Config is read from ${path.join(os.homedir(), ".gain", "config.json")} unless GAIN_CONFIG_DIR is set.`
  ].join("\n");
}

function uninstallHealthSchedule(options = {}) {
  const platform = options.platform || process.platform;
  if (platform === "darwin") return uninstallMacHealthLaunchAgent(options);
  const result = uninstallWindowsOrManualTasks(TASKS, options, "Remove the G.A.I.N Agent cron entries for `presence`, `sync`, and `desktop-guard` from the user's crontab or your MDM policy.");
  if (platform === "win32") {
    const runner = options.execFileSync || execFileSync;
    try { runner("reg", windowsDeleteRunValueArgs(HEALTH_RUN_VALUE), { stdio: "ignore", windowsHide: true }); } catch (_error) {}
    const launcherPath = options.startupLauncherPath || windowsHealthStartupLauncherPath(options);
    try { fs.rmSync(launcherPath, { force: true }); } catch (_error) {}
    return { ...result, registryRunRemoved: true };
  }
  return result;
}

function uninstallAutoUpdateSchedule(options = {}) {
  if ((options.platform || process.platform) === "darwin") return uninstallMacAutoUpdateLaunchAgent(options);
  return uninstallWindowsOrManualTasks(UPDATE_TASKS, options, "Remove the G.A.I.N Agent auto-update cron entry from the user's crontab or your MDM policy.");
}

function uninstallDesktopGuardSchedule(options = {}) {
  if ((options.platform || process.platform) === "darwin") {
    return { ok: true, removed: false, manual: false, instructions: "The macOS health LaunchAgent remains installed for presence and policy sync. Desktop guard stops because local config is disabled." };
  }
  return uninstallWindowsOrManualTasks([TASKS[2]], options, "Remove the G.A.I.N Agent `desktop-guard` cron entry from the user's crontab or your MDM policy.");
}

function uninstallWindowsOrManualTasks(tasks, options = {}, instructions) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;

  if (platform !== "win32") {
    return {
      ok: true,
      removed: false,
      manual: true,
      instructions
    };
  }

  const removed = [];
  const errors = [];
  for (const task of tasks) {
    try {
      runner("schtasks", windowsDeleteTaskArgs(task), { stdio: "pipe" });
      removed.push(task.name);
    } catch (error) {
      errors.push({ task: task.name, error: error.message });
    }
  }
  return { ok: errors.length === 0, removed, errors };
}

function shellQuoteForCommand(value) {
  return `"${String(value || "").replace(/"/g, '\\"')}"`;
}

function escapeVbs(value) {
  return String(value || "").replace(/"/g, "\"\"");
}

module.exports = {
  TASKS,
  UPDATE_TASKS,
  HEALTH_STARTUP_LAUNCHER,
  WINDOWS_RUN_KEY,
  HEALTH_RUN_VALUE,
  MAC_HEALTH_LABEL,
  MAC_UPDATE_LABEL,
  macHealthLaunchAgentPath,
  macUpdateLaunchAgentPath,
  macLaunchDomain,
  installMacHealthLaunchAgent,
  uninstallMacHealthLaunchAgent,
  macHealthLaunchAgentStatus,
  installMacAutoUpdateLaunchAgent,
  uninstallMacAutoUpdateLaunchAgent,
  defaultCliPath,
  stableConfigDir,
  commandLine,
  windowsDirectCommand,
  startWindowsDirectCommand,
  windowsRunValueArgs,
  windowsDeleteRunValueArgs,
  windowsQueryRunValueArgs,
  queryWindowsRunValue,
  hiddenRunnerPath,
  windowsStartupDir,
  windowsHealthStartupLauncherPath,
  writeWindowsHealthStartupLauncher,
  startWindowsHealthStartupLauncher,
  writeWindowsHiddenRunner,
  taskRunCommand,
  windowsCreateTaskArgs,
  windowsDeleteTaskArgs,
  windowsQueryTaskArgs,
  taskAlreadyInstalled,
  manualScheduleInstructions,
  autoUpdateManualScheduleInstructions,
  windowsTaskRunnerDiagnostics,
  healthScheduleStatus,
  extractTaskRunCommand,
  extractHiddenRunnerScriptPath,
  installHealthSchedule,
  uninstallHealthSchedule,
  installDesktopGuardSchedule,
  uninstallDesktopGuardSchedule,
  installAutoUpdateSchedule,
  uninstallAutoUpdateSchedule
};
