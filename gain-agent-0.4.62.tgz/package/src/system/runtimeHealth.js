"use strict";

// Keep the deployment heartbeat useful without adding any content telemetry.
// This is deliberately limited to agent runtime state that an administrator
// needs to diagnose why a local control may not be active.
function buildAgentRuntimeHealth(config = {}, cache = null, proxy = null) {
  const cacheAvailable = Boolean(cache && cache.ok);
  const cacheState = !cacheAvailable
    ? "unavailable"
    : (cache.freshForHotPath ? "current" : "stale");
  const proxyConfigured = config.proxy_service_enabled === true
    || proxy?.enabled === true
    || proxy?.serviceEnabled === true;
  const failPolicy = proxy?.failPolicy === "fail_closed" ? "fail_closed" : "fail_open";

  return {
    active: config.active !== false,
    policy_cache: {
      state: cacheState,
      bundle_version: cacheAvailable ? (cache.bundleVersion || null) : null,
      age_seconds: cacheAvailable && Number.isFinite(Number(cache.ageSeconds))
        ? Math.max(0, Math.floor(Number(cache.ageSeconds)))
        : null,
    },
    proxy: {
      state: !proxyConfigured ? "not_configured" : (proxy?.running === true ? "running" : "offline"),
      configured: proxyConfigured,
      running: proxy?.running === true,
      fail_policy: failPolicy,
      service_variant: proxy?.serviceVariant || null,
    },
  };
}

module.exports = { buildAgentRuntimeHealth };
