"use strict";

const https = require("https");
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { execFileSync } = require("child_process");
const { AGENT_VERSION, sendEvent } = require("../reporters/supabaseEdgeClient");
const { configPath } = require("../config/loadPolicy");

const DEFAULT_BASE_URL = "https://www.cyberwardion.com/downloads/gain-agent";

function updateBaseUrl() {
  return (process.env.GAIN_AGENT_BASE_URL || DEFAULT_BASE_URL).replace(/\/+$/, "");
}

function latestManifestUrl() {
  return process.env.GAIN_AGENT_LATEST_URL || `${updateBaseUrl()}/latest.json`;
}

function isCyberWardionUpdateUrl(url) {
  try {
    const parsed = new URL(String(url || ""));
    return /(^|\.)cyberwardion\.com$/i.test(parsed.hostname) &&
      parsed.pathname.includes("/downloads/gain-agent");
  } catch (_error) {
    return String(url || "").toLowerCase().includes("cyberwardion.com/downloads/gain-agent");
  }
}

function shouldCheckForHostedUpdate(config = {}, manifestUrl = latestManifestUrl()) {
  if (
    config.deployment_mode === "self_hosted" &&
    config.telemetry_enabled === false &&
    isCyberWardionUpdateUrl(manifestUrl)
  ) {
    return {
      ok: false,
      skipped: true,
      reason: "self_hosted_no_vendor_update"
    };
  }
  return { ok: true, skipped: false };
}

function installScriptUrl(platform = process.platform) {
  return `${updateBaseUrl()}/${platform === "win32" ? "install.ps1" : "install.sh"}`;
}

function isStandaloneBinary() {
  return Boolean(process.pkg);
}

function platformKey(platform = process.platform, arch = process.arch) {
  const osPart = platform === "win32"
    ? "win"
    : platform === "darwin"
      ? "macos"
      : platform === "linux"
        ? "linux"
        : platform;
  const archPart = arch === "x64" || arch === "arm64" ? arch : arch;
  return `${osPart}-${archPart}`;
}

function resolveDownloadUrl(urlOrPath) {
  const raw = String(urlOrPath || "").trim();
  if (/^https?:\/\//i.test(raw)) return raw;
  return `${updateBaseUrl()}/${raw.replace(/^\/+/, "")}`;
}

function compareVersions(a, b) {
  const left = String(a || "0").split(".").map((part) => Number(part) || 0);
  const right = String(b || "0").split(".").map((part) => Number(part) || 0);
  const length = Math.max(left.length, right.length);
  for (let i = 0; i < length; i += 1) {
    const diff = (left[i] || 0) - (right[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function getJson(url) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, { headers: { "User-Agent": `gain-agent/${AGENT_VERSION}` } }, (response) => {
      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => { body += chunk; });
      response.on("end", () => {
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error(`HTTP ${response.statusCode}`));
          return;
        }
        try {
          resolve(JSON.parse(body));
        } catch (error) {
          reject(new Error(`invalid update manifest: ${error.message}`));
        }
      });
    });
    request.setTimeout(8000, () => request.destroy(new Error("timeout")));
    request.on("error", reject);
  });
}

function downloadFile(url, destination, redirects = 0) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    let request = null;
    let settled = false;
    const fail = (error) => {
      if (settled) return;
      settled = true;
      if (request) request.destroy();
      fs.rmSync(destination, { force: true });
      reject(error);
    };
    const file = fs.createWriteStream(destination, { mode: 0o755 });
    file.on("error", fail);
    request = https.get(url, { headers: { "User-Agent": `gain-agent/${AGENT_VERSION}` } }, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        if (redirects >= 5) {
          file.close(() => fail(new Error("too many redirects")));
          return;
        }
        const nextUrl = new URL(response.headers.location, url).toString();
        file.close(() => {
          fs.rmSync(destination, { force: true });
          if (settled) return;
          settled = true;
          resolve(downloadFile(nextUrl, destination, redirects + 1));
        });
        return;
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        file.close(() => fs.rmSync(destination, { force: true }));
        reject(new Error(`HTTP ${response.statusCode}`));
        return;
      }
      response.pipe(file);
      file.on("finish", () => file.close(() => {
        if (settled) return;
        settled = true;
        resolve();
      }));
    });
    request.setTimeout(30000, () => request.destroy(new Error("timeout")));
    request.on("error", (error) => {
      file.close(() => fail(error));
    });
  });
}

function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex");
}

function windowsUpdaterHelperPath(nextVersion, pid = process.pid) {
  return path.join(os.tmpdir(), `gain-agent-updater-${nextVersion || AGENT_VERSION}-${pid}.ps1`);
}

function quoteWindowsArg(value) {
  const raw = String(value);
  if (raw.length === 0) return "\"\"";
  if (!/[ \t"]/.test(raw)) return raw;
  let quoted = "\"";
  let slashCount = 0;
  for (const char of raw) {
    if (char === "\\") {
      slashCount += 1;
    } else if (char === "\"") {
      quoted += "\\".repeat((slashCount * 2) + 1);
      quoted += char;
      slashCount = 0;
    } else {
      quoted += "\\".repeat(slashCount);
      quoted += char;
      slashCount = 0;
    }
  }
  quoted += "\\".repeat(slashCount * 2);
  quoted += "\"";
  return quoted;
}

function quotePowerShellString(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function sanitizeUpdateFailureReason(reason) {
  return String(reason || "unknown_error")
    .replace(/[a-zA-Z]:\\[^\s"'`]+/g, "<path>")
    .replace(/\\\\[^\s"'`]+/g, "<path>")
    .replace(/\/(?:Users|home|tmp|var|private|opt|Applications|Program Files)[^\s"'`]+/g, "<path>")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 300) || "unknown_error";
}

function buildWindowsUpdateFailureEvent(config = {}, { oldVersion = AGENT_VERSION, newVersion = "", reason = "", kind = "windows_auto_update_failed" } = {}) {
  const oldText = String(oldVersion || AGENT_VERSION).slice(0, 40);
  const newText = String(newVersion || "unknown").slice(0, 40);
  const safeReason = sanitizeUpdateFailureReason(reason);
  const proxyRepairFailed = kind === "windows_proxy_repair_failed";
  return {
    surface: "agent",
    event_type: proxyRepairFailed ? "agent_proxy_repair_failed" : "agent_auto_update_failed",
    domain: "agent.local",
    tool_name: "G.A.I.N Agent",
    category: "agent_update",
    action: "logged",
    enforcement_action: "log_only",
    severity: "medium",
    content_length: 0,
    patterns_detected: [],
    reason_category: proxyRepairFailed ? "windows_proxy_repair_failed" : "windows_auto_update_failed",
    detection_engine_version: `agent-${oldText}`,
    detection_reason: proxyRepairFailed
      ? `Windows auto-update installed ${newText}, but local proxy repair failed: ${safeReason}`
      : `Windows auto-update failed from ${oldText} to ${newText}: ${safeReason}`,
    device_id: config.device_id,
    created_at: new Date().toISOString()
  };
}

async function reportWindowsUpdateFailure(config, details = {}, { sendEventFn = sendEvent } = {}) {
  const event = buildWindowsUpdateFailureEvent(config, details);
  const result = await sendEventFn(config, event);
  return { ...result, event };
}

function launchWindowsHiddenProcess(filePath, args, { execFileSyncFn = execFileSync, preferPwshLauncher = false } = {}) {
  const argLine = args.map(quoteWindowsArg).join(" ");
  if (preferPwshLauncher) {
    const startProcessScript = [
      "$ErrorActionPreference = 'Stop'",
      `$p = Start-Process -FilePath ${quotePowerShellString(filePath)} -ArgumentList ${quotePowerShellString(argLine)} -WindowStyle Hidden -PassThru`,
      "[Console]::Out.Write($p.Id)"
    ].join("; ");
    const output = execFileSyncFn("pwsh.exe", [
      "-NoProfile",
      "-Command",
      startProcessScript
    ], {
      encoding: "utf8",
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"]
    });
    const pid = Number.parseInt(String(output || "").trim(), 10);
    return Number.isFinite(pid) ? pid : null;
  }

  execFileSyncFn("cmd.exe", [
    "/d",
    "/s",
    "/c",
    `start "" /min ${quoteWindowsArg(filePath)} ${argLine}`
  ], {
    windowsHide: true,
    stdio: "ignore"
  });
  return null;
}

function writeWindowsUpdaterHelper(helperPath) {
  fs.mkdirSync(path.dirname(helperPath), { recursive: true });
  const script = String.raw`param(
  [Parameter(Mandatory=$true)][int]$ProcessId,
  [Parameter(Mandatory=$true)][string]$TargetPath,
  [Parameter(Mandatory=$true)][string]$PendingPath,
  [Parameter(Mandatory=$true)][string]$BackupPath,
  [Parameter(Mandatory=$true)][string]$LogPath,
  [Parameter(Mandatory=$true)][string]$OldVersion,
  [Parameter(Mandatory=$true)][string]$NextVersion,
  [Parameter(Mandatory=$false)][string]$ProxyConfigPath = "",
  [Parameter(Mandatory=$false)][string]$ProxyHost = "127.0.0.1",
  [Parameter(Mandatory=$false)][int]$ProxyPort = 8787,
  [Parameter(Mandatory=$false)][string]$ProxyFailPolicy = "fail_open"
)

$ErrorActionPreference = "Stop"

function Write-UpdateLog([string]$Message) {
  try {
    $dir = Split-Path -Parent $LogPath
    if ($dir) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Add-Content -LiteralPath $LogPath -Value ("{0} {1}" -f (Get-Date).ToUniversalTime().ToString("o"), $Message)
  } catch {}
}

function Report-UpdateFailure([string]$Reason, [string]$Kind = "windows_auto_update_failed") {
  try {
    $reportReason = if ($Reason) { $Reason } else { "windows_helper_failed" }
    Write-UpdateLog ("reporting final failure: {0}" -f $reportReason)
    Start-Process -FilePath $TargetPath -ArgumentList @("update-report", "--old-version", $OldVersion, "--new-version", $NextVersion, "--reason", $reportReason, "--kind", $Kind) -WindowStyle Hidden
  } catch {
    Write-UpdateLog ("failure report launch failed: {0}" -f $_.Exception.Message)
  }
}

$proxyConfigBackupPath = ""
function Save-ProxyConfig {
  if (-not $ProxyConfigPath -or -not (Test-Path -LiteralPath $ProxyConfigPath)) { return }
  try {
    $proxyConfigBackupPath = "$ProxyConfigPath.update-$NextVersion.backup"
    Copy-Item -LiteralPath $ProxyConfigPath -Destination $proxyConfigBackupPath -Force
    Write-UpdateLog "saved proxy configuration before repair"
  } catch {
    Write-UpdateLog ("could not save proxy configuration: {0}" -f $_.Exception.Message)
  }
}

function Restore-ProxyConfig {
  if (-not $proxyConfigBackupPath -or -not (Test-Path -LiteralPath $proxyConfigBackupPath)) { return }
  try {
    Copy-Item -LiteralPath $proxyConfigBackupPath -Destination $ProxyConfigPath -Force
    Write-UpdateLog "restored proxy configuration after failed repair"
  } catch {
    Write-UpdateLog ("could not restore proxy configuration: {0}" -f $_.Exception.Message)
  }
}

function Test-ProxyReachable {
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $connect = $client.ConnectAsync($ProxyHost, $ProxyPort)
    if (-not $connect.Wait(1000)) { return $false }
    return $client.Connected
  } catch {
    return $false
  } finally {
    $client.Dispose()
  }
}

function Repair-ProxyService {
  Save-ProxyConfig
  $lastReason = "proxy did not become reachable"
  for ($attempt = 1; $attempt -le 4; $attempt++) {
    try {
      Write-UpdateLog ("proxy repair attempt {0}/4" -f $attempt)
      $proxyRepair = Start-Process -FilePath $TargetPath -ArgumentList @("proxy", "--service", "install", "--host", $ProxyHost, "--port", $ProxyPort, "--proxy-fail-policy", $ProxyFailPolicy) -WindowStyle Hidden -Wait -PassThru
      if ($proxyRepair.ExitCode -ne 0) {
        throw "proxy service install exited with code $($proxyRepair.ExitCode)"
      }
      for ($check = 1; $check -le 5; $check++) {
        if (Test-ProxyReachable) {
          Write-UpdateLog "proxy service repaired and reachable after update"
          if ($proxyConfigBackupPath) { Remove-Item -LiteralPath $proxyConfigBackupPath -Force -ErrorAction SilentlyContinue }
          return $true
        }
        Start-Sleep -Seconds 1
      }
      throw "proxy service installed but $($ProxyHost):$ProxyPort did not become reachable"
    } catch {
      $lastReason = $_.Exception.Message
      Write-UpdateLog ("proxy repair attempt {0} failed: {1}" -f $attempt, $lastReason)
      if ($attempt -lt 4) { Start-Sleep -Seconds ([Math]::Pow(2, $attempt - 1)) }
    }
  }
  Restore-ProxyConfig
  Write-UpdateLog ("proxy repair failed after retries; previous configuration was restored: {0}" -f $lastReason)
  Report-UpdateFailure ("proxy_repair_failed: $lastReason") "windows_proxy_repair_failed"
  return $false
}

try {
  Write-UpdateLog "waiting for process $ProcessId to exit"
  $deadline = (Get-Date).AddMinutes(5)
  while ((Get-Date) -lt $deadline) {
    $process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if (-not $process) { break }
    Start-Sleep -Milliseconds 500
  }

  $stoppedProxy = $false
  $shouldRepairProxy = $false
  try {
    $targetFullPath = [System.IO.Path]::GetFullPath($TargetPath)
    $runningTargetProcesses = Get-Process -ErrorAction SilentlyContinue | Where-Object {
      $_.Id -ne $PID -and $_.Id -ne $ProcessId -and $_.Path -and ([System.IO.Path]::GetFullPath($_.Path) -ieq $targetFullPath)
    }
    foreach ($runningProcess in $runningTargetProcesses) {
      try {
        $commandLine = (Get-CimInstance Win32_Process -Filter "ProcessId = $($runningProcess.Id)" -ErrorAction SilentlyContinue).CommandLine
        if ($commandLine -match '(?i)\bproxy\b' -and $commandLine -match '(?i)--service' -and $commandLine -match '(?i)\brun\b') {
          $stoppedProxy = $true
        }
      } catch {}
      Write-UpdateLog ("stopping old process {0} before replace" -f $runningProcess.Id)
      Stop-Process -Id $runningProcess.Id -Force -ErrorAction SilentlyContinue
    }
  } catch {
    Write-UpdateLog ("process cleanup skipped: {0}" -f $_.Exception.Message)
  }
  $shouldRepairProxy = $stoppedProxy
  # A proxy can be configured but already down while an update begins. In that
  # case there is no old process to discover above, yet the replacement binary
  # must still repair the configured service instead of leaving it unavailable.
  try {
    if ($ProxyConfigPath -and (Test-Path -LiteralPath $ProxyConfigPath)) {
      $savedProxyConfig = Get-Content -LiteralPath $ProxyConfigPath -Raw | ConvertFrom-Json
      if ($savedProxyConfig.proxy_service_enabled -eq $true) {
        $shouldRepairProxy = $true
        Write-UpdateLog "proxy repair required by saved configuration"
      }
    }
  } catch {
    Write-UpdateLog ("could not read saved proxy configuration: {0}" -f $_.Exception.Message)
  }

  $lastFailureReason = "unknown_error"
  for ($attempt = 1; $attempt -le 90; $attempt++) {
    try {
      if (-not (Test-Path -LiteralPath $PendingPath)) {
        throw "pending binary is missing: $PendingPath"
      }
      if (Test-Path -LiteralPath $TargetPath) {
        Copy-Item -LiteralPath $TargetPath -Destination $BackupPath -Force
      }
      Copy-Item -LiteralPath $PendingPath -Destination $TargetPath -Force
      Remove-Item -LiteralPath $PendingPath -Force
      Write-UpdateLog "installed update at $TargetPath"
      if ($shouldRepairProxy) {
        Repair-ProxyService | Out-Null
      }
      exit 0
    } catch {
      $lastFailureReason = $_.Exception.Message
      Write-UpdateLog ("attempt {0} failed: {1}" -f $attempt, $_.Exception.Message)
      Start-Sleep -Seconds 1
    }
  }
  Report-UpdateFailure $lastFailureReason
  exit 1
} catch {
  Write-UpdateLog ("fatal: {0}" -f $_.Exception.Message)
  Report-UpdateFailure $_.Exception.Message
  exit 1
}
`;
  fs.writeFileSync(helperPath, script, "utf8");
  return helperPath;
}

function startWindowsUpdaterHelper({
  targetPath,
  pendingPath,
  backupPath,
  nextVersion,
  oldVersion = AGENT_VERSION,
  proxyConfigPath = configPath(),
  proxyHost = "127.0.0.1",
  proxyPort = 8787,
  proxyFailPolicy = "fail_open",
  processId = process.pid,
  helperPath = windowsUpdaterHelperPath(nextVersion, processId),
  logPath = path.join(os.tmpdir(), `gain-agent-updater-${nextVersion || AGENT_VERSION}.log`),
  execFileSyncFn = execFileSync
} = {}) {
  if (!targetPath || !pendingPath || !backupPath) {
    throw new Error("targetPath, pendingPath, and backupPath are required for the Windows updater helper");
  }
  writeWindowsUpdaterHelper(helperPath);
  const shell = commandExists("pwsh.exe", ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"])
    ? "pwsh.exe"
    : "powershell.exe";
  const helperArgs = [
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    helperPath,
    "-ProcessId",
    String(processId),
    "-TargetPath",
    targetPath,
    "-PendingPath",
    pendingPath,
    "-BackupPath",
    backupPath,
    "-LogPath",
    logPath,
    "-OldVersion",
    oldVersion,
    "-NextVersion",
    nextVersion || AGENT_VERSION,
    "-ProxyConfigPath",
    proxyConfigPath,
    "-ProxyHost",
    proxyHost,
    "-ProxyPort",
    String(proxyPort),
    "-ProxyFailPolicy",
    proxyFailPolicy
  ];
  const helperPid = launchWindowsHiddenProcess(shell, helperArgs, {
    execFileSyncFn,
    preferPwshLauncher: shell === "pwsh.exe"
  });
  return {
    helperPath,
    pendingPath,
    backupPath,
    logPath,
    helperPid
  };
}

async function checkForUpdate({ currentVersion = AGENT_VERSION, config = {} } = {}) {
  const manifestUrl = latestManifestUrl();
  const guard = shouldCheckForHostedUpdate(config, manifestUrl);
  if (!guard.ok) {
    return {
      ...guard,
      manifest: null,
      currentVersion,
      latestVersion: currentVersion,
      updateAvailable: false
    };
  }
  const manifest = await getJson(manifestUrl);
  const latestVersion = manifest.version;
  if (!latestVersion) throw new Error("update manifest is missing version");
  return {
    manifest,
    currentVersion,
    latestVersion,
    updateAvailable: compareVersions(latestVersion, currentVersion) > 0
  };
}

function binaryEntry(manifest, key = platformKey()) {
  const binaries = manifest && typeof manifest === "object" ? manifest.binaries : null;
  if (!binaries || typeof binaries !== "object") return null;
  return binaries[key] || null;
}

// On Unix a running executable must be replaced with rename, not overwritten
// in place. Rename keeps the old inode alive for the current process and makes
// the next launch see the fully-written replacement binary.
function replaceUnixBinary(tempPath, targetPath, { fsModule = fs, processId = process.pid, now = Date.now() } = {}) {
  const stagedPath = `${targetPath}.next-${processId}-${now}`;
  try {
    fsModule.copyFileSync(tempPath, stagedPath);
    fsModule.chmodSync(stagedPath, 0o755);
    fsModule.renameSync(stagedPath, targetPath);
    fsModule.rmSync(tempPath, { force: true });
    return { ok: true, path: targetPath, stagedPath };
  } catch (error) {
    try { fsModule.rmSync(stagedPath, { force: true }); } catch (_cleanupError) {}
    return { ok: false, error: error.message, stagedPath };
  }
}

function repairUnixProxyAfterUpdate(config = {}, {
  executablePath = process.execPath,
  execFileSyncFn = execFileSync
} = {}) {
  if (config.proxy_service_enabled !== true) {
    return { ok: true, skipped: true, reason: "proxy_not_enabled" };
  }
  const host = config.proxy_service_host || "127.0.0.1";
  const port = String(Number(config.proxy_service_port || 8787));
  const failPolicy = config.proxy_fail_policy || "fail_open";
  try {
    execFileSyncFn(executablePath, [
      "proxy",
      "--service",
      "install",
      "--host",
      host,
      "--port",
      port,
      "--proxy-fail-policy",
      failPolicy
    ], { stdio: "ignore" });
    return { ok: true, host, port: Number(port), failPolicy };
  } catch (error) {
    return {
      ok: false,
      host,
      port: Number(port),
      failPolicy,
      error: `Updated agent could not restart its local proxy: ${sanitizeUpdateFailureReason(error.message)}. AI clients keep their direct connection in fail-open mode.`
    };
  }
}

async function installStandaloneBinaryUpdate(config, { update, version, stdio = "inherit" } = {}) {
  const manifest = update?.manifest || {};
  const key = platformKey();
  const binary = binaryEntry(manifest, key);
  if (!binary || !binary.url) {
    return {
      ok: false,
      fallback: true,
      message: `No standalone binary is published for ${key}. Re-run the installer to use the npm fallback.`
    };
  }

  const nextVersion = version || update?.latestVersion || manifest.version || AGENT_VERSION;
  const suffix = process.platform === "win32" ? ".exe" : "";
  const tempPath = path.join(os.tmpdir(), `gain-agent-${nextVersion}-${key}-${process.pid}-${Date.now()}${suffix}`);
  const downloadUrl = resolveDownloadUrl(binary.url);
  await downloadFile(downloadUrl, tempPath);
  const expected = String(binary.sha256 || "").toLowerCase();
  const actual = sha256File(tempPath);
  if (expected && actual !== expected) {
    fs.rmSync(tempPath, { force: true });
    throw new Error(`downloaded binary checksum mismatch. Expected ${expected} but got ${actual}`);
  }
  if (process.platform !== "win32") fs.chmodSync(tempPath, 0o755);

  const currentPath = process.execPath;
  if (process.platform === "win32") {
    const pendingPath = path.join(path.dirname(currentPath), `gain-agent-${nextVersion}-${key}.pending.exe`);
    const backupPath = path.join(path.dirname(currentPath), `gain-agent-${AGENT_VERSION}-${key}.previous.exe`);
    fs.copyFileSync(tempPath, pendingPath);
    fs.rmSync(tempPath, { force: true });
    const helper = startWindowsUpdaterHelper({
      targetPath: currentPath,
      pendingPath,
      backupPath,
      nextVersion,
      oldVersion: AGENT_VERSION,
      proxyConfigPath: configPath(),
      proxyHost: config.proxy_service_host || "127.0.0.1",
      proxyPort: Number(config.proxy_service_port || 8787),
      proxyFailPolicy: config.proxy_fail_policy || "fail_open"
    });
    return {
      ok: true,
      pending: true,
      path: pendingPath,
      helper,
      message: `Downloaded verified G.A.I.N Agent ${nextVersion}. A separate updater helper will replace ${currentPath} after this process exits. Helper log: ${helper.logPath}`
    };
  }

  const replacement = replaceUnixBinary(tempPath, currentPath);
  if (!replacement.ok) {
    fs.rmSync(tempPath, { force: true });
    throw new Error(`could not replace the running agent binary: ${replacement.error}`);
  }
  const proxyRepair = repairUnixProxyAfterUpdate(config, { executablePath: currentPath });
  const proxyWarning = proxyRepair.ok ? "" : ` ${proxyRepair.error}`;
  if (stdio !== "ignore") {
    return { ok: true, proxyRepair, message: `Installed G.A.I.N Agent ${nextVersion} at ${currentPath}.${proxyWarning}` };
  }
  return { ok: true, proxyRepair };
}

async function runHostedInstaller(config, { update, version, stdio = "inherit" } = {}) {
  const guard = shouldCheckForHostedUpdate(config);
  if (!guard.ok) return guard;

  if (isStandaloneBinary()) {
    return installStandaloneBinaryUpdate(config, { update, version, stdio });
  }

  const env = {
    ...process.env,
    GAIN_ORG_API_KEY: config.org_api_key || process.env.GAIN_ORG_API_KEY || "",
    GAIN_ENFORCEMENT_MODE: config.enforcement_mode || "redact",
    GAIN_DEVICE_LABEL: config.device_label || "Developer workstation",
    GAIN_DEPARTMENT: config.department || "",
    GAIN_AGENT_VERSION: version || process.env.GAIN_AGENT_VERSION || "",
    GAIN_AGENT_AUTO_UPDATE: config.auto_update ? "true" : (process.env.GAIN_AGENT_AUTO_UPDATE || "")
  };

  if (process.platform === "win32") {
    const shell = commandExists("pwsh.exe", ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"]) ? "pwsh.exe" : "powershell.exe";
    const scriptUrl = installScriptUrl("win32").replace(/'/g, "''");
    execFileSync(shell, [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      `& { irm '${scriptUrl}' | iex }`
    ], { stdio, env });
    return { ok: true };
  }

  const scriptUrl = installScriptUrl(process.platform).replace(/'/g, "'\\''");
  execFileSync("sh", [
    "-c",
    `curl -fsSL '${scriptUrl}' | bash`
  ], { stdio, env });
  return { ok: true };
}

function commandExists(command, args = ["--version"]) {
  try {
    execFileSync(command, args, { stdio: "ignore" });
    return true;
  } catch (_error) {
    return false;
  }
}

module.exports = {
  DEFAULT_BASE_URL,
  buildWindowsUpdateFailureEvent,
  compareVersions,
  binaryEntry,
  checkForUpdate,
  downloadFile,
  installScriptUrl,
  installStandaloneBinaryUpdate,
  isCyberWardionUpdateUrl,
  isStandaloneBinary,
  latestManifestUrl,
  platformKey,
  resolveDownloadUrl,
  repairUnixProxyAfterUpdate,
  replaceUnixBinary,
  reportWindowsUpdateFailure,
  sanitizeUpdateFailureReason,
  runHostedInstaller,
  sha256File,
  startWindowsUpdaterHelper,
  shouldCheckForHostedUpdate
};
