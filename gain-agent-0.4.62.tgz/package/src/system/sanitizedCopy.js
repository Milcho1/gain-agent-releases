"use strict";

const fs = require("fs");
const path = require("path");

function nextSanitizedCopyPath(sourcePath, existsSync = fs.existsSync) {
  const source = path.resolve(sourcePath);
  const parsed = path.parse(source);
  const base = `${parsed.name}.gain-redacted`;
  let attempt = 1;
  let candidate = path.join(parsed.dir, `${base}${parsed.ext}`);
  while (existsSync(candidate)) {
    attempt += 1;
    candidate = path.join(parsed.dir, `${base}-${attempt}${parsed.ext}`);
  }
  return candidate;
}

function writeSanitizedCopy(sourcePath, text, options = {}) {
  const source = path.resolve(sourcePath);
  const destination = options.outputPath
    ? path.resolve(options.outputPath)
    : nextSanitizedCopyPath(source);
  if (destination === source) {
    throw new Error("Refusing to overwrite the original. Choose a different --output path.");
  }
  if (options.outputPath && fs.existsSync(destination) && !options.overwrite) {
    throw new Error(`Refusing to overwrite existing file: ${destination}. Choose another --output path or use --force.`);
  }
  const sourceMode = fs.statSync(source).mode;
  fs.writeFileSync(destination, text, { encoding: "utf8", mode: sourceMode });
  return destination;
}

module.exports = { nextSanitizedCopyPath, writeSanitizedCopy };
