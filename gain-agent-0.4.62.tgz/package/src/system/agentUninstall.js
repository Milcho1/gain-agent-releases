"use strict";

const fs = require("fs");
const {
  readConfigFile,
  writeConfigFile,
  configDir
} = require("../config/loadPolicy");
const { uninstallProxyService } = require("./proxyService");
const {
  uninstallHealthSchedule,
  uninstallAutoUpdateSchedule
} = require("./healthSchedule");
const { stopRecordedHealthService } = require("./healthService");
const { removeAutoWiring } = require("../integrations/autoWire");

function runStep(name, run) {
  try {
    const result = run();
    return { name, ok: result && result.ok !== false, result };
  } catch (error) {
    return { name, ok: false, error: error.message };
  }
}

// A running executable cannot reliably remove itself on Windows. This command
// removes every active integration and service first, then prints the one safe
// manual binary-removal step. --purge additionally removes local policy/cache
// metadata after the services are stopped.
function uninstallAgent(options = {}) {
  const readConfig = options.readConfigFile || readConfigFile;
  const writeConfig = options.writeConfigFile || writeConfigFile;
  const removeProxy = options.uninstallProxyService || uninstallProxyService;
  const removeHealth = options.uninstallHealthSchedule || uninstallHealthSchedule;
  const removeUpdates = options.uninstallAutoUpdateSchedule || uninstallAutoUpdateSchedule;
  const stopHealth = options.stopRecordedHealthService || stopRecordedHealthService;
  const removeWiring = options.removeAutoWiring || removeAutoWiring;
  const removeDirectory = options.rmSync || fs.rmSync;
  const getConfigDir = options.configDir || configDir;
  const current = readConfig();

  // This must happen before any best-effort cleanup. A hook that races with
  // removal sees active:false and fail-opens rather than interrupting a tool.
  writeConfig({
    ...current,
    active: false,
    desktop_guard_enabled: false,
    auto_update: false,
    inactive_reason: "uninstalled_locally"
  });

  const steps = [
    runStep("proxy service and routing", () => removeProxy(options)),
    runStep("health schedule", () => removeHealth(options)),
    runStep("auto-update schedule", () => removeUpdates(options)),
    runStep("running health service", () => stopHealth(options)),
    runStep("coding-tool hooks and MCP entries", () => removeWiring(options))
  ];

  let purged = false;
  let purgeError = null;
  if (options.purge) {
    try {
      removeDirectory(getConfigDir(), { recursive: true, force: true });
      purged = true;
    } catch (error) {
      purgeError = error.message;
    }
  }

  return {
    ok: steps.every((step) => step.ok) && !purgeError,
    steps,
    disabled: true,
    purged,
    purgeError
  };
}

module.exports = { uninstallAgent, runStep };
