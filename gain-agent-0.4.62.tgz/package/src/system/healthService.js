"use strict";

const fs = require("fs");
const path = require("path");
const { spawn, execFileSync } = require("child_process");
const { configDir, loadConfig, writeJsonFileAtomically } = require("../config/loadPolicy");

const PRESENCE_INTERVAL_MS = 5 * 60 * 1000;
// Normal scanning stays entirely local. This lightweight bundle refresh keeps
// an administrator's emergency pause/resume within five minutes on agents.
const SYNC_INTERVAL_MS = 5 * 60 * 1000;
const DESKTOP_GUARD_RETRY_MS = 60 * 1000;
const CONFIG_POLL_INTERVAL_MS = 2 * 1000;

function healthStatePath() {
  return path.join(configDir(), "health-service.json");
}

function readHealthStateStatus() {
  try {
    const state = JSON.parse(fs.readFileSync(healthStatePath(), "utf8"));
    if (!state || typeof state !== "object" || Array.isArray(state)) {
      return { ok: false, reason: "invalid_shape" };
    }
    return { ok: true, state };
  } catch (error) {
    if (error.code === "ENOENT") return { ok: false, reason: "missing" };
    return { ok: false, reason: "unreadable", error: error.message };
  }
}

function readHealthState() {
  const result = readHealthStateStatus();
  return result.ok ? result.state : {};
}

function writeHealthState(patch = {}) {
  const current = readHealthState();
  const next = { ...current, ...patch, updated_at: new Date().toISOString() };
  writeJsonFileAtomically(healthStatePath(), next);
  return next;
}

function getProcessCommandLine(pid, options = {}) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  try {
    if (platform === "win32") {
      const script = `$p = Get-CimInstance Win32_Process -Filter 'ProcessId=${Number(pid)}' -ErrorAction SilentlyContinue; if ($p) { $p.CommandLine }`;
      return String(runner("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"],
        windowsHide: true
      }) || "").trim();
    }
    if (platform === "linux") {
      return fs.readFileSync(`/proc/${Number(pid)}/cmdline`, "utf8").replace(/\0/g, " ").trim();
    }
    if (platform === "darwin") {
      return String(runner("ps", ["-p", String(pid), "-o", "command="], {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"]
      }) || "").trim();
    }
  } catch (_error) {
    // Failing closed here is intentional: uninstall has already disabled G.A.I.N
    // in config, so an unverified PID must never terminate an unrelated process.
  }
  return "";
}

function isGainHealthServiceCommand(commandLine) {
  const text = String(commandLine || "").toLowerCase();
  return /gain[-_ ]?agent(?:\.exe)?/.test(text) && /\bhealth-service\b/.test(text);
}

function verifyRecordedHealthProcess(pid, state = {}, options = {}) {
  const commandLine = options.getProcessCommandLine
    ? options.getProcessCommandLine(pid, state)
    : getProcessCommandLine(pid, options);
  if (isGainHealthServiceCommand(commandLine)) {
    return { ok: true, commandLine };
  }
  return {
    ok: false,
    reason: commandLine ? "pid_is_not_gain_health_service" : "pid_could_not_be_verified"
  };
}

function stopRecordedHealthService(options = {}) {
  const state = options.state || readHealthState();
  const kill = options.kill || process.kill;
  const pid = Number(state.pid);
  if (!Number.isInteger(pid) || pid <= 0 || pid === process.pid) {
    writeHealthState({ enabled: false, stopped_at: new Date().toISOString(), pid: null });
    return { ok: true, stopped: false, pid: null };
  }
  const verification = verifyRecordedHealthProcess(pid, state, options);
  if (!verification.ok) {
    const error = verification.reason === "pid_is_not_gain_health_service"
      ? `Skipped stopping PID ${pid}: it is not a G.A.I.N health-service process.`
      : `Skipped stopping PID ${pid}: the process identity could not be verified.`;
    writeHealthState({
      enabled: false,
      stopped_at: new Date().toISOString(),
      pid: null,
      last_stop_error: error
    });
    return { ok: true, stopped: false, skipped: true, pid, reason: verification.reason, error };
  }
  try {
    kill(pid, "SIGTERM");
    writeHealthState({ enabled: false, stopped_at: new Date().toISOString(), pid: null });
    return { ok: true, stopped: true, pid };
  } catch (error) {
    // A stale PID or a process that already exited is harmless. Preserve a
    // diagnostic for permission errors without preventing clean uninstall.
    writeHealthState({
      enabled: false,
      stopped_at: new Date().toISOString(),
      pid: null,
      last_stop_error: error.code === "ESRCH" ? null : error.message
    });
    return { ok: error.code === "ESRCH", stopped: false, pid, error: error.code === "ESRCH" ? null : error.message };
  }
}

function healthCommand(command, { nodePath = process.execPath, cliPath } = {}) {
  const packaged = !cliPath || path.resolve(String(cliPath)) === path.resolve(process.execPath);
  return packaged
    ? { command: nodePath, args: [command] }
    : { command: nodePath, args: [cliPath, command] };
}

function healthChildEnvironment(baseEnvironment = process.env) {
  // @yao-pkg/pkg otherwise reinjects its snapshot entrypoint into spawned EXEs.
  // A health child must receive only the subcommand (presence, sync, or guard).
  return { ...baseEnvironment, PKG_EXECPATH: "", GAIN_HEALTH_SERVICE_CHILD: "1" };
}

function isDesktopGuardEnabled(config = {}) {
  return config.desktop_guard_enabled !== false;
}

function runHealthService(options = {}) {
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath === undefined ? (process.pkg ? "" : path.resolve(__dirname, "..", "cli", "index.js")) : options.cliPath;
  const spawnFn = options.spawn || spawn;
  const loadConfigFn = options.loadConfig || loadConfig;
  const setIntervalFn = options.setInterval || setInterval;
  const clearIntervalFn = options.clearInterval || clearInterval;
  const exitFn = options.exit || process.exit;
  const presenceIntervalMs = Number(options.presenceIntervalMs || PRESENCE_INTERVAL_MS);
  const syncIntervalMs = Number(options.syncIntervalMs || SYNC_INTERVAL_MS);
  const desktopGuardRetryMs = Number(options.desktopGuardRetryMs || DESKTOP_GUARD_RETRY_MS);
  const configPollIntervalMs = Number(options.configPollIntervalMs || CONFIG_POLL_INTERVAL_MS);
  let stopping = false;
  let desktopGuardRunning = false;

  if (loadConfigFn().active === false) {
    writeHealthState({ enabled: false, stopped_at: new Date().toISOString(), pid: null });
    return;
  }

  writeHealthState({
    enabled: true,
    pid: process.pid,
    command: "health-service",
    executable: process.execPath,
    started_at: new Date().toISOString(),
    presence_interval_ms: presenceIntervalMs,
    sync_interval_ms: syncIntervalMs,
    config_poll_interval_ms: configPollIntervalMs
  });

  const run = (command, stateField) => {
    if (stopping) return;
    const currentConfig = loadConfigFn();
    if (currentConfig.active === false) { stop(); return; }
    if (stateField === "desktop_guard" && !isDesktopGuardEnabled(currentConfig)) return;
    if (stateField === "desktop_guard" && desktopGuardRunning) return;
    const childInfo = healthCommand(command, { nodePath, cliPath });
    let child;
    try {
      child = spawnFn(childInfo.command, childInfo.args, {
        detached: false,
        stdio: "ignore",
        windowsHide: true,
        env: healthChildEnvironment()
      });
    } catch (error) {
      writeHealthState({ [`last_${stateField}_error`]: error.message });
      return;
    }
    if (stateField === "desktop_guard") {
      desktopGuardRunning = true;
      writeHealthState({ desktop_guard_started_at: new Date().toISOString(), last_desktop_guard_error: null });
    }
    child.on("error", (error) => {
      if (stateField === "desktop_guard") desktopGuardRunning = false;
      writeHealthState({ [`last_${stateField}_error`]: error.message });
    });
    child.on("exit", (code) => {
      if (stateField === "desktop_guard") desktopGuardRunning = false;
      const now = new Date().toISOString();
      writeHealthState(code === 0
        ? { [`last_${stateField}_at`]: now, [`last_${stateField}_error`]: null }
        : { [`last_${stateField}_error`]: `gain-agent ${command} exited with code ${code}` });
    });
  };

  const presenceTimer = setIntervalFn(() => run("presence", "presence"), presenceIntervalMs);
  const syncTimer = setIntervalFn(() => run("sync", "sync"), syncIntervalMs);
  // A revoke or emergency local disable changes config outside this process.
  // Poll only the tiny local config file, so the service exits promptly even
  // when Windows will not reveal a process command line for PID verification.
  const configTimer = setIntervalFn(() => {
    if (!stopping && loadConfigFn().active === false) stop();
  }, configPollIntervalMs);
  // Keep this lightweight timer alive even while the guard is off. An admin can
  // enable desktop protection later without requiring a sign-out or reinstall.
  const desktopGuardTimer = setIntervalFn(() => run("desktop-guard", "desktop_guard"), desktopGuardRetryMs);
  const stop = () => {
    stopping = true;
    clearIntervalFn(presenceTimer);
    clearIntervalFn(syncTimer);
    clearIntervalFn(configTimer);
    clearIntervalFn(desktopGuardTimer);
    writeHealthState({
      enabled: false,
      pid: null,
      stopped_at: new Date().toISOString()
    });
    exitFn(0);
  };
  process.on("SIGTERM", stop);
  process.on("SIGINT", stop);
  run("presence", "presence");
  run("sync", "sync");
  run("desktop-guard", "desktop_guard");
}

module.exports = {
  PRESENCE_INTERVAL_MS,
  SYNC_INTERVAL_MS,
  DESKTOP_GUARD_RETRY_MS,
  CONFIG_POLL_INTERVAL_MS,
  healthStatePath,
  readHealthStateStatus,
  readHealthState,
  writeHealthState,
  getProcessCommandLine,
  isGainHealthServiceCommand,
  verifyRecordedHealthProcess,
  stopRecordedHealthService,
  healthCommand,
  healthChildEnvironment,
  isDesktopGuardEnabled,
  runHealthService
};
