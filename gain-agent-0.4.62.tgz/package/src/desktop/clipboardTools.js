"use strict";

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function commandExists(command) {
  const checker = process.platform === "win32" ? "where" : "command";
  const args = process.platform === "win32" ? [command] : ["-v", command];
  const result = spawnSync(checker, args, { stdio: "ignore", shell: process.platform !== "win32" });
  return !result.error && result.status === 0;
}

function getWindowsPowerShellCommand(environment = process.env, exists = fs.existsSync) {
  if (process.platform !== "win32") return null;

  // Registry Run starts outside an interactive terminal and may not inherit the
  // PowerShell 7 directory on PATH. Prefer the installed executable directly
  // before falling back to whatever the shell can resolve.
  const programFiles = [environment.ProgramW6432, environment.ProgramFiles, environment["ProgramFiles(x86)"]]
    .filter(Boolean);
  const candidates = [
    ...programFiles.map((root) => path.join(root, "PowerShell", "7", "pwsh.exe")),
    "pwsh.exe",
    "powershell.exe",
    "powershell"
  ];
  for (const command of candidates) {
    if (path.isAbsolute(command) && exists(command)) return command;
    if (commandExists(command)) return command;
  }
  return null;
}

function run(command, args, options = {}) {
  return spawnSync(command, args, {
    input: options.input,
    encoding: "utf8",
    maxBuffer: 8 * 1024 * 1024,
    windowsHide: true
  });
}

function powershellClipboard() {
  const command = getWindowsPowerShellCommand();
  if (!command) return null;
  return {
    name: "powershell",
    readText() {
      const result = run(command, ["-NoProfile", "-Command", "Get-Clipboard -Raw"]);
      if (result.error || result.status !== 0) return "";
      return String(result.stdout || "");
    },
    writeText(text) {
      const result = run(command, ["-NoProfile", "-Command", "$input | Set-Clipboard"], { input: String(text || "") });
      return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
    }
  };
}

function macClipboard() {
  if (!commandExists("pbpaste") || !commandExists("pbcopy")) return null;
  return {
    name: "pbpaste/pbcopy",
    readText() {
      const result = run("pbpaste", []);
      if (result.error || result.status !== 0) return "";
      return String(result.stdout || "");
    },
    writeText(text) {
      const result = run("pbcopy", [], { input: String(text || "") });
      return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
    }
  };
}

function linuxClipboard() {
  if (commandExists("wl-paste") && commandExists("wl-copy")) {
    return {
      name: "wl-paste/wl-copy",
      readText() {
        const result = run("wl-paste", ["-n"]);
        if (result.error || result.status !== 0) return "";
        return String(result.stdout || "");
      },
      writeText(text) {
        const result = run("wl-copy", [], { input: String(text || "") });
        return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
      }
    };
  }
  if (commandExists("xclip")) {
    return {
      name: "xclip",
      readText() {
        const result = run("xclip", ["-selection", "clipboard", "-o"]);
        if (result.error || result.status !== 0) return "";
        return String(result.stdout || "");
      },
      writeText(text) {
        const result = run("xclip", ["-selection", "clipboard"], { input: String(text || "") });
        return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
      }
    };
  }
  return null;
}

function getClipboardAdapter(platform = process.platform) {
  if (platform === "win32") return powershellClipboard();
  if (platform === "darwin") return macClipboard();
  return linuxClipboard();
}

module.exports = {
  commandExists,
  getWindowsPowerShellCommand,
  getClipboardAdapter
};
