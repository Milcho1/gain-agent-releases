"use strict";

const { spawnSync } = require("child_process");
const { getWindowsPowerShellCommand } = require("./clipboardTools");

function run(command, args) {
  return spawnSync(command, args, {
    encoding: "utf8",
    maxBuffer: 1024 * 1024,
    windowsHide: true
  });
}

const WINDOWS_FOREGROUND_SCRIPT = `
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class GainForeground {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
}
"@
$hwnd = [GainForeground]::GetForegroundWindow()
[uint32]$foregroundProcessId = 0
[GainForeground]::GetWindowThreadProcessId($hwnd, [ref]$foregroundProcessId) | Out-Null
$p = Get-Process -Id $foregroundProcessId -ErrorAction SilentlyContinue
if ($p) {
  [ordered]@{ name = $p.ProcessName; processName = $p.ProcessName; path = $p.Path; pid = $foregroundProcessId } | ConvertTo-Json -Compress
}
`;

function windowsForegroundApp(runCommand = run, powerShellCommand = getWindowsPowerShellCommand()) {
  if (!powerShellCommand) return null;
  const result = runCommand(powerShellCommand, ["-NoProfile", "-Command", WINDOWS_FOREGROUND_SCRIPT]);
  if (result.error || result.status !== 0 || !String(result.stdout || "").trim()) return null;
  try { return JSON.parse(result.stdout); } catch (_error) { return null; }
}

function macForegroundApp() {
  const result = run("osascript", ["-e", "tell application \"System Events\" to get name of first application process whose frontmost is true"]);
  if (result.error || result.status !== 0) return null;
  const name = String(result.stdout || "").trim();
  return name ? { name, processName: name, path: "" } : null;
}

function getForegroundApp(platform = process.platform) {
  if (platform === "win32") return windowsForegroundApp();
  if (platform === "darwin") return macForegroundApp();
  return null;
}

module.exports = {
  WINDOWS_FOREGROUND_SCRIPT,
  windowsForegroundApp,
  getForegroundApp
};
