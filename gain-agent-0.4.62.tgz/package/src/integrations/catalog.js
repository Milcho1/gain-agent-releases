"use strict";

const os = require("os");
const { GAIN_MCP, PROXY_ENV_VARS, toolDefinitions, toolPaths } = require("./autoWire");

const PROXY_URL = "http://127.0.0.1:8787";

const DESKTOP_APP_INTEGRATION = {
  id: "desktop-apps",
  name: "Desktop AI apps",
  status: "restrict-and-clipboard-guard",
  coverage: "Device-level allowlist/blocklist plus foreground-only clipboard scanning for monitored desktop AI apps. No TLS MITM.",
  install: [
    "Use gain-agent setup --desktop-guard on to keep clipboard protection enabled.",
    "Run gain-agent desktop-guard status to confirm it is running.",
    "Review events in the dashboard with the Desktop app source filter."
  ],
  config: {
    command: "gain-agent desktop-check --app \"ChatGPT Desktop\" --domain chatgpt.com",
    guardCommand: "gain-agent desktop-guard start",
    surface: "desktop_app"
  }
};

function toolStatus(tool) {
  const parts = [];
  if (Array.isArray(tool.proxyEnv) && tool.proxyEnv.length) parts.push("proxy");
  if (tool.nativeHook) parts.push("hook");
  if (tool.mcp) parts.push("mcp");
  if (tool.gitFallback) parts.push("git");
  return parts.join("-") || "manual";
}

function toolCoverage(tool) {
  const mechanisms = Array.isArray(tool.mechanisms) && tool.mechanisms.length
    ? tool.mechanisms.join(", ")
    : "manual setup";
  const note = tool.notes ? ` ${tool.notes}` : "";
  return `${mechanisms}.${note}`;
}

function toolInstallSteps(tool) {
  const steps = [`Run gain-agent integrations --apply to wire ${tool.name} when it is detected.`];
  if (tool.nativeHook) steps.push(`Restart ${tool.name} after wiring so hooks are loaded.`);
  if (Array.isArray(tool.proxyEnv) && tool.proxyEnv.length) {
    steps.push("Proxy routing is optional and stays off in fail-open mode, so the tool keeps working if the local proxy is unavailable.");
    steps.push("Use gain-agent status to confirm proxy routing only after an admin selects fail-closed mode.");
  }
  if (tool.mcp && !tool.nativeHook) steps.push("Use MCP tools for explicit scan/redact actions where the tool supports MCP.");
  if (tool.gitFallback && (!Array.isArray(tool.proxyEnv) || !tool.proxyEnv.length) && !tool.mcp && !tool.nativeHook) {
    steps.push("Git fallback catches AI-written secrets before commit.");
  }
  return steps;
}

function toolConfig(tool) {
  const config = {};
  if (tool.mcp) config.mcpServers = { gain: GAIN_MCP };
  if (Array.isArray(tool.proxyEnv) && tool.proxyEnv.length) {
    config.proxyEnv = Object.fromEntries(tool.proxyEnv.map((name) => [name, PROXY_URL]));
  }
  if (tool.nativeHook) config.hookCommand = "gain-agent claude-hook";
  if (tool.gitFallback && !Object.keys(config).length) config.gitFallback = "gain-agent install-global-git-hook";
  return Object.keys(config).length ? config : { manual: "See gain-agent integrations --apply output for supported wiring." };
}

function integrationFromTool(tool) {
  const item = {
    id: tool.id,
    name: tool.name,
    status: toolStatus(tool),
    coverage: toolCoverage(tool),
    install: toolInstallSteps(tool),
    config: toolConfig(tool)
  };
  if (tool.configType === "toml") {
    item.configToml = "[mcp_servers.gain]\ncommand = \"gain-agent\"\nargs = [\"mcp\"]";
    delete item.config;
  }
  return item;
}

function allIntegrations() {
  return [
    ...toolDefinitions(toolPaths(os.homedir())).map(integrationFromTool),
    DESKTOP_APP_INTEGRATION
  ];
}

function normalizeToolFilter(value) {
  return String(value || "")
    .split(",")
    .map((s) => s.trim().toLowerCase().replace(/\s+/g, "-"))
    .filter(Boolean);
}

function itemMatches(item, filter) {
  if (!filter.length) return true;
  const names = [item.id, item.name].map((v) => String(v).toLowerCase().replace(/\s+/g, "-"));
  return filter.some((token) => names.includes(token));
}

function getIntegrations({ tools = "" } = {}) {
  const filter = normalizeToolFilter(tools);
  return allIntegrations().filter((item) => itemMatches(item, filter)).map((item) => ({ ...item }));
}

function printIntegrations({ json = false, apply = false, agentPath = null, tools = "", noProxyEnv = false, noGitHook = false } = {}) {
  if (apply) {
    const { applyAutoWiring, printAutoWiringResult } = require("./autoWire");
    const { loadConfig } = require("../config/loadPolicy");
    const result = applyAutoWiring({ agentPath, tools, noProxyEnv, noGitHook, config: loadConfig() });
    if (json) {
      console.log(JSON.stringify(result, null, 2));
    } else {
      printAutoWiringResult(result);
    }
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if (json) {
    console.log(JSON.stringify({ integrations: getIntegrations({ tools }) }, null, 2));
    return;
  }

  console.log("G.A.I.N Agent integrations");
  console.log("Install/update the agent first, then wire it into the coding agents your team uses.\n");
  console.log("Auto-wire detected tools with: gain-agent integrations --apply");
  console.log(`Proxy envs managed by the agent: ${PROXY_ENV_VARS.join(", ")}\n`);
  for (const item of getIntegrations({ tools })) {
    console.log(`${item.name} [${item.status}]`);
    console.log(`  Coverage: ${item.coverage}`);
    console.log("  Steps:");
    for (const step of item.install) console.log(`    - ${step}`);
    if (item.configToml) {
      console.log("  Config:");
      console.log(indent(item.configToml, 4));
    } else if (item.config) {
      console.log("  Config:");
      console.log(indent(JSON.stringify(item.config, null, 2), 4));
    }
    console.log("");
  }
  console.log("Honesty rule: `gain-agent status` only says redact is active when a detected tool is routed to a reachable local proxy.");
}

function indent(text, spaces) {
  const pad = " ".repeat(spaces);
  return String(text).split("\n").map((line) => `${pad}${line}`).join("\n");
}

module.exports = { getIntegrations, printIntegrations };
