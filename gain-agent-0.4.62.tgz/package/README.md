# G.A.I.N. Agent

**Metadata-only AI usage visibility and on-device redaction for local, dev, and CI workflows.**

The G.A.I.N. Agent is the command-line companion to the [G.A.I.N.](https://cyberwardion.com/gain)
browser extension by CyberWardion. It uses the **exact same detection and
redaction engine** the extension ships, so secrets and sensitive data are caught
and masked identically, whether they're typed into ChatGPT in a browser or
committed by a developer at the terminal.

- **Detects** secrets, credentials, PII, card numbers, and regulated data
- **Redacts** them locally. Raw content never leaves your machine
- **Reports metadata only** to your G.A.I.N. dashboard: counts, types, actions,
  never the values, never your file contents or prompts)
- **Gates commits and CI**. Exits non-zero when critical secrets are found

## Customer install

G.A.I.N Agent is distributed from CyberWardion's download endpoint. It is **not
published to npm yet**.

Windows PowerShell:

```powershell
$env:GAIN_ORG_API_KEY="<YOUR_ORG_KEY>"; irm https://www.cyberwardion.com/downloads/gain-agent/install.ps1 | iex
```

macOS / Linux:

```sh
curl -fsSL https://www.cyberwardion.com/downloads/gain-agent/install.sh | GAIN_ORG_API_KEY="<YOUR_ORG_KEY>" bash
```

The installer downloads a checksum-verified standalone binary, installs or updates the agent,
connects it to the org when `GAIN_ORG_API_KEY` is provided, installs the health
schedule, starts the hidden local proxy service with watchdog/fallback,
auto-wires detected coding tools, optionally enables auto-update, and runs
`gain-agent doctor` last.

Set `GAIN_AGENT_NO_SERVICE=1` to skip the hidden proxy service,
`GAIN_AGENT_SKIP_INTEGRATIONS=1` to skip auto-wiring, or
`GAIN_AGENT_SKIP_HEALTH_SCHEDULE=1` to skip scheduled health pings. For manual
`gain-agent init`, `--no-service` is also supported.

The normal hosted install does not require Node.js or npm. Node is only needed
when no standalone binary is published for the current platform.

### macOS customer install

For a customer-facing Mac rollout, ship one **signed and notarized universal
PKG**, not a raw binary, `.dmg`, or copy-paste shell command. The PKG supports
both Apple Silicon and Intel Macs, installs `gain-agent` to `/usr/local/bin`,
and lets Gatekeeper verify it without an Open Anyway exception.

Build it on a Mac or macOS CI runner after `npm run build:binaries`:

```sh
export DEVELOPER_ID_APPLICATION="Developer ID Application: CyberWardion (...)"
export DEVELOPER_ID_INSTALLER="Developer ID Installer: CyberWardion (...)"
export APPLE_NOTARY_PROFILE="cyberwardion-notary"
npm run package:macos
```

The build produces `dist/macos-pkg/GAIN-Agent-<VERSION>-macOS.pkg`, submits it
to Apple notarization, staples the approval ticket, and verifies the signed
installer before it can be distributed. It never embeds an Organization Key.
After installation, the signed-in developer enrolls with `gain-agent setup`,
or an MDM provides the key as a separate, per-user configuration step.

### macOS release automation

The repository includes the **Release notarized macOS G.A.I.N Agent package**
workflow. It builds the universal PKG on a macOS runner, signs it, notarizes
and staples it, installs it for a smoke test, then uploads the verified PKG and
checksum to `Milcho1/gain-agent-releases`.

Before the first run, add these GitHub Actions secrets to the source repository:

- `APPLE_APPLICATION_CERTIFICATE_P12_BASE64`
- `APPLE_APPLICATION_CERTIFICATE_PASSWORD`
- `APPLE_INSTALLER_CERTIFICATE_P12_BASE64`
- `APPLE_INSTALLER_CERTIFICATE_PASSWORD`
- `APPLE_ID`
- `APPLE_TEAM_ID`
- `APPLE_APP_SPECIFIC_PASSWORD`
- `GAIN_MACOS_QA_ORG_KEY` for a disposable test organization
- `GAIN_RELEASE_TOKEN` with Contents read/write access to `Milcho1/gain-agent-releases`

Run the workflow manually with the exact existing release tag, for example
`gain-agent-v0.4.58`. A failed signing, notarization, installation, backend
connection, or local detection check stops the release before it uploads an
asset for customers.

Use a `.dmg` only when G.A.I.N later ships a visible macOS desktop `.app`.

### macOS developer install

Run the installer in the signed-in developer's Terminal, not through a remote
root shell or an MDM command running as another user:

```sh
curl -fsSL https://www.cyberwardion.com/downloads/gain-agent/install.sh | GAIN_ORG_API_KEY="<YOUR_ORG_KEY>" bash
gain-agent doctor
```

### macOS release smoke test

Run this only on a real Mac with a disposable test Organization Key. It uses a
temporary G.A.I.N configuration, confirms enrollment and policy sync, checks
local detection and safe redaction, and verifies that the original test file is
unchanged. Add `--with-service` to also test the per-user fail-open launchd
proxy service; the script removes that LaunchAgent when it exits.

```sh
export GAIN_ORG_API_KEY="<TEST_ORG_KEY>"
./scripts/macos-smoke-test.sh --agent /path/to/gain-agent --with-service
```

The installer adds `~/.local/bin` to `~/.zprofile`. Open a new Terminal and
restart Claude Code after install so it loads the current binary and any proxy
settings. `doctor` is the single diagnosis command: it names a missing org
key, failed enrollment, missing policy cache, unreachable proxy, unregistered
LaunchAgent, or a stale health service and gives the exact repair command.

For desktop clipboard coverage, bring Claude Desktop or ChatGPT Desktop to the
front and run this once:

```sh
gain-agent desktop-guard --once
```

macOS may ask for Automation access to System Events. Choose **Allow**. The
guard only reads the clipboard while a configured AI desktop app is foreground;
it never sends clipboard or prompt content to CyberWardion.

The raw-binary path is for development only. Do not send it to customers. Use
the signed and notarized PKG above for a production macOS rollout.

Copy-paste local smoke test:

```sh
KEY_PREFIX='sk-proj-'
KEY_SUFFIX='Ab3xK9mQ2pL7wR5tY8nZ4cV6bN1'
printf '%s\n' "Deploy with OPENAI_API_KEY=${KEY_PREFIX}${KEY_SUFFIX} and IBAN DE89 3704 0044 0532 0130 00" | gain-agent redact
```

The output must replace the sensitive values with `[REDACTED]`. This test runs
locally and sends no prompt or file content to the dashboard.

Manual install/update fallback:

```sh
npm install -g ./gain-agent-<VERSION>.tgz
gain-agent --help
```

> Node.js 18+ with npm is only required for this fallback.

## Quick start

```sh
# 1. Connect, start background protection, auto-wire tools, and verify
gain-agent init --org-key <YOUR_ORG_KEY> --label "Developer workstation"

# 2. Re-run auto-wiring later if you install another coding tool
gain-agent integrations --apply

# 3. Use it
gain-agent scan .                       # scan a directory for secrets
cat prompt.txt | gain-agent redact      # scrub sensitive data from any text
```

## Commands

| Command | What it does |
|---|---|
| `setup --org-key <KEY> [--supabase-url <URL>] [--supabase-key <KEY>] [--mode <m>] [--label <name>] [--department <name>] [--auto-update]` | Save config, enroll this workstation, and sync org policies |
| `scan <path> [--mode <m>] [--json] [--no-report]` | Scan files for sensitive patterns; reports metadata |
| `baseline create [path] \| show [path] \| clear [path]` | Suppress existing known findings without storing secret values |
| `redact [--json]` | Read text on stdin, write redacted text to stdout (local only) |
| `update [--check\|--force]` | Check or update from CyberWardion's hosted package |
| `siem-test` | Send a metadata-only test event to the configured SIEM webhook |
| `proxy [--host 127.0.0.1] [--port 8787]` | Run the local CLI proxy in the foreground |
| `proxy --service install\|uninstall\|status` | Install, remove, or inspect the hidden local proxy service |
| `status` | Show current config and queued events |
| `doctor` | Check Node version, scanner, redactor, org connection, and policy sync |
| `sync` | Refresh org policies and update dashboard deployment health |
| `heartbeat` | Send a full deployment heartbeat to the dashboard |
| `presence` | Send a lightweight online presence ping to the dashboard |
| `install-health-schedule` | Install managed presence/heartbeat schedule where supported |
| `uninstall-health-schedule` | Remove the managed presence/heartbeat schedule |
| `enable-auto-update` | Install daily hidden update checks where supported |
| `disable-auto-update` | Remove daily update checks |
| `integrations [--json] [--apply] [--tools <csv>]` | Show setup instructions or auto-wire detected AI coding tools |
| `flush` | Send any locally-queued events to the dashboard |
| `install-git-hook` | Install a pre-commit secret scanner in the current repo |
| `install-global-git-hook` | Install a global pre-commit scanner for all repos on the workstation |
| `uninstall-global-git-hook` | Remove G.A.I.N as the global Git hook path |
| `git-hook` | Run the pre-commit scan (used by the installed hook) |
| `claude-hook` | Claude Code hook (reads hook JSON on stdin) |

Enforcement modes (`--mode`): `visibility_only`, `warn`, `redact`, `block`.

### Document scanning

`gain-agent scan` extracts readable text before scanning `.docx`, `.pdf`,
`.xlsx`, and `.pptx` files. Workbook coverage includes every worksheet and
cell comments; presentation coverage includes slides and speaker notes. PDFs
use local `pdftotext` when available and the bundled PDF parser otherwise.
Image-only or otherwise unextractable documents are reported as unscannable,
never treated as clean.

## Redact in a pipeline

```sh
cat draft-prompt.txt | gain-agent redact > safe-prompt.txt
```
```
deploy with OPENAI_API_KEY=[REDACTED] and card [REDACTED]
[G.A.I.N] Redacted 2 sensitive values (api_key, credit_card).
```
`--json` emits a metadata summary to stderr (types and counts), leaving the
redacted text clean on stdout.

## Block secrets before they're committed

```sh
cd your-repo
gain-agent install-git-hook
```
Commits that contain critical secrets (API keys, private keys, `.env` values)
are blocked; only metadata is reported.

For managed developer workstations, install once globally:

```sh
gain-agent install-global-git-hook
```

This configures Git's global `core.hooksPath` to `~/.gain/git-hooks`. If another
global hook path already exists, G.A.I.N refuses to replace it unless `--force`
is explicitly passed.

## Baseline known findings

For repos with existing historical findings, create a metadata-only baseline:

```sh
gain-agent baseline create .
gain-agent baseline show .
```

The baseline file lives at `.gain/baseline.json` and stores only file path,
pattern type, count, and risk. It never stores secret values or file content.
Future scans suppress matching known findings and report only new or increased
findings.

## Use in CI

`scan` exits with code `2` on a BLOCK decision, so it gates a pipeline:

```sh
gain-agent scan . --mode block || exit 1
```

## Works with your AI coding tools

G.A.I.N. protects across tools through three mechanisms:

| Tool | How it's covered |
|---|---|
| **Claude Code** | Local proxy (`ANTHROPIC_BASE_URL`) plus native hook (`gain-agent claude-hook`) or MCP |
| **GitHub Copilot CLI** | Local proxy (`COPILOT_PROVIDER_BASE_URL`) for OpenAI-compatible requests |
| **ChatGPT / Claude desktop apps** | App/domain restriction plus foreground-only clipboard guard (`gain-agent desktop-guard`), no TLS MITM |
| **Codex CLI** | MCP server |
| **Gemini CLI** | MCP server |
| **Cursor** | MCP server; local proxy is limited to modes that support custom base URLs |
| **Any MCP client** | MCP server (`gain-agent mcp`) |
| **Any tool that writes code** | Git pre-commit hook catches secrets before commit, no matter which AI wrote them |

### Local CLI proxy

`gain-agent proxy` runs a localhost gateway for CLI tools that support custom
provider base URLs. It scans request bodies before forwarding, applies local or
org policy, and reports metadata only (`surface: "agent"`,
`event_type: "cli_proxy_request"`). No TLS MITM and no system proxy.

```sh
gain-agent proxy --host 127.0.0.1 --port 8787
```

For managed workstations, install it as a hidden user service instead:

```sh
gain-agent proxy --service install
gain-agent proxy --service status
gain-agent proxy --service uninstall
```

On Windows this uses a per-user registry Run entry and starts the agent binary
directly. On macOS it writes a user LaunchAgent. On Linux it writes a systemd
user unit. The service binds `127.0.0.1:8787`.

Only an administrator who explicitly selects `fail_closed` gets persistent
proxy environment variables for supported clients:

```sh
export ANTHROPIC_BASE_URL=http://127.0.0.1:8787
export COPILOT_PROVIDER_BASE_URL=http://127.0.0.1:8787
```

The default fail policy is `fail_open`: a stopped or missing local proxy never
interrupts an AI client. The proxy service still runs for local protection, but
supported clients keep their direct connection if it is unavailable. Explicit
`fail_closed` routing is reserved for organizations that accept that tradeoff:

```sh
gain-agent proxy --service install --proxy-fail-policy fail_open
```

That installs the service but does not set client environment variables.

Use separate upstream flags only when you need a non-default provider target:

```sh
gain-agent proxy \
  --anthropic-upstream https://api.anthropic.com \
  --openai-upstream https://api.openai.com
```

Policy behavior:

- `visibility_only`: detect and log metadata, then forward unchanged.
- `warn`: detect and log metadata, then forward with `x-gain-warning`.
- `redact`: redact sensitive strings in the request body before forwarding.
- `block`: return a provider-shaped 403 before the request leaves localhost.

Restrict-access is device-enforced in the proxy. Tools marked `blocked`, or
tools missing from the approved list when `access_mode=allow_only_approved`, are
prevented before any upstream request is made.

### Desktop app coverage

`gain-agent desktop-check` is the desktop-app restrict mode without TLS interception.
It checks an app name and/or known AI domain against the device policy, reports a
metadata-only event (`surface: "desktop_app"`, `event_type: "desktop_access"`),
and blocks before launching when the app is blocked or missing from the approved
list in `access_mode=allow_only_approved`.

```sh
gain-agent desktop-check --app "ChatGPT Desktop" --domain chatgpt.com
gain-agent desktop-check --app "Claude Desktop" --exec "C:\\Program Files\\Claude\\Claude.exe"
```

`gain-agent desktop-guard` is the resident clipboard guard for desktop AI apps.
It reads the clipboard only while a monitored desktop AI app is the foreground
window. Defaults are Claude Desktop and ChatGPT Desktop. It applies the same org
policy locally: redact replaces the clipboard with redacted text, warn shows a
native notification, block clears the clipboard, and log_only reports metadata
without changing the clipboard. Clipboard content is never sent or stored.

```sh
gain-agent setup --desktop-guard on
gain-agent desktop-guard start
gain-agent desktop-guard stop
```

What it does:

- Blocks apps/domains in `blocked_tools`.
- In `allow_only_approved`, blocks anything not in `approved_tools` or marked approved by org policy.
- Monitors clipboard only when a monitored desktop AI app is foreground.
- Logs only app/domain/device/department/action and detected type/count metadata.
- Emits `surface: "desktop_app"` so the dashboard source filter shows it as Desktop app.

What it does not do:

- No TLS MITM.
- No local root CA.
- No request, response, screenshot, image, or voice inspection.
- No clipboard content is reported to the dashboard.

### MCP server

`gain-agent mcp` runs a [Model Context Protocol](https://modelcontextprotocol.io)
server (JSON-RPC over stdio) exposing two tools any MCP client can call:

- **`redact_text`**: returns text with secrets/PII/cards masked
- **`scan_text`**: reports the types and counts of sensitive data found (no values)

Register it (command `gain-agent`, args `["mcp"]`):

Automatic setup for installed coding tools:
```sh
gain-agent integrations --apply
```
This detects Claude Code, Cursor, GitHub Copilot CLI, Codex CLI, Gemini CLI,
Windsurf, Aider, Continue, and Cline. It backs up config files before editing,
adds MCP where the tool has a stable MCP config, adds the Claude Code native hook,
persists proxy environment variables for Anthropic and OpenAI-compatible tools,
and installs the global git fallback when possible. Use `--tools <csv>` to limit
the scope.
On Windows the hook command uses the absolute standalone binary path with
forward slashes so Claude Code can run it without hand-editing `settings.json`.

Run `gain-agent status` to see the per-tool table:

```text
tool | detected | mechanism | active
```

The agent only reports "redact via proxy" as active when the tool is routed to a
reachable local proxy. Tools without a stable native hook or proxy setting are
reported honestly as MCP or git fallback only.

**Claude Code**
```sh
claude mcp add gain -- gain-agent mcp
```
**Claude Desktop** (`claude_desktop_config.json`), **Cursor** (`.cursor/mcp.json`), **Gemini CLI** (`~/.gemini/settings.json`)
```json
{ "mcpServers": { "gain": { "command": "gain-agent", "args": ["mcp"] } } }
```
**Codex CLI** (`~/.codex/config.toml`)
```toml
[mcp_servers.gain]
command = "gain-agent"
args = ["mcp"]
```
Tool calls are reported as metadata only (`surface: "mcp"`).

### Claude Code hook (deeper integration)
```sh
gain-agent claude-hook   # reads Claude Code hook JSON on stdin
```
Run `gain-agent init --org-key <KEY>` or `gain-agent integrations --apply` to
wire it into Claude Code automatically as a UserPromptSubmit / PreToolUse hook.
Restart Claude Code after wiring so the hook is loaded. Claude Code
UserPromptSubmit hooks cannot replace the user's submitted prompt. They can block
or add context only. Claude documents this in the hooks reference:
https://code.claude.com/docs/en/hooks. That means visible in-agent redaction is
not available from the hook today. For redact-and-continue, run the local proxy
and route Claude Code through `ANTHROPIC_BASE_URL=http://127.0.0.1:8787`. When
that live local route is reachable, the hook hard-blocks only private keys, seed
phrases, and crypto private keys, then lets the proxy redact API keys, emails,
IBANs, database strings, and other redactable types in transit.

### Universal: catch secrets at commit (any tool)
No matter which AI wrote the code, block secrets before they're committed:
```sh
cd your-repo && gain-agent install-git-hook
```

### CI (GitHub Actions)
```yaml
- name: G.A.I.N. secret scan
  run: |
    npm install -g ./gain-agent-0.4.25.tgz
    gain-agent scan . --mode block
```
`scan` exits non-zero on a BLOCK decision, failing the job.

## Per-project policy: `.gain/policy.json`

For repos where AI use is restricted or forbidden, drop a `.gain/policy.json` at
the repo root:

```json
{
  "ai_allowed": false,
  "reason": "Customer source code cannot be shared with AI tools",
  "action": "block",
  "report_metadata": true
}
```
A project ban (`ai_allowed: false`) always wins over the configured enforcement
mode.

## Organization policies

When connected with an Organization Key, the agent pulls the same live policy
bundle used by the browser extension and applies it locally to scans, Claude Code
hooks, and git pre-commit protection. The policy bundle is cached in
`~/.gain/policy-cache.json` for offline continuity.

If the network is down, the agent keeps using the last valid cached policy for up
to 24 hours. If no org policy is available yet, it falls back to the local
`enforcement_mode`.

Precedence:

1. `.gain/policy.json` project bans win.
2. Hard-block patterns like private keys are always blocked.
3. Dashboard organization policies decide block / redact / warn / log.
4. Local `enforcement_mode` is used only when no org policy is available.

## Deployment health

`setup` enrolls the workstation immediately. After that, admins can verify the
agent in the G.A.I.N dashboard just like a browser extension install. For managed
rollouts, run:

```sh
gain-agent sync       # refresh policies + full heartbeat
gain-agent presence   # lightweight online ping
gain-agent heartbeat  # full health update
gain-agent install-health-schedule
```

Recommended managed schedule:

- `gain-agent presence` every 5 minutes
- `gain-agent sync` or `gain-agent heartbeat` every 60 minutes
- `gain-agent desktop-guard` at user logon

This keeps dashboard health current and the desktop clipboard guard resident
without sending prompt, file, or clipboard content.

On Windows, `install-health-schedule` creates per-user Scheduled Tasks for
5-minute presence, hourly policy sync, and the desktop guard at logon. On
macOS/Linux it prints the exact cron entries for IT/MDM deployment.

## Configuration

Config lives at `~/.gain/config.json` (override the directory with
`GAIN_CONFIG_DIR`). Every setting can also be supplied via environment variables,
which take precedence, useful for CI and managed rollouts:

| Env var | Setting |
|---|---|
| `GAIN_ORG_API_KEY` | Organisation key |
| `GAIN_SUPABASE_URL` | Dashboard backend URL |
| `GAIN_SUPABASE_KEY` | Backend publishable key |
| `GAIN_ENFORCEMENT_MODE` | `visibility_only` / `warn` / `redact` / `block` |
| `GAIN_DEVICE_LABEL` | Friendly device name |
| `GAIN_DEPARTMENT` | Optional department tag shown in Deployment Health |
| `GAIN_DESKTOP_GUARD` | `on` / `off` for foreground-only desktop clipboard protection |
| `GAIN_DESKTOP_GUARD_APPS` | Optional comma-separated monitored desktop app list |
| `GAIN_SIEM_WEBHOOK_URL` | Optional SIEM/webhook JSON destination for metadata events |
| `GAIN_SIEM_BEARER_TOKEN` | Optional bearer token for the SIEM webhook |

You can also exclude paths from scanning via `"disabled_paths": ["secrets/", "vendor/"]`
in the config file.

## SIEM export

Configure a generic HTTP JSON webhook:

```sh
gain-agent setup --siem-webhook-url https://siem.example.com/ingest --siem-token <TOKEN>
gain-agent siem-test
```

SIEM events contain metadata only: tool, action, severity, pattern types/counts,
device id, department, and timestamp. Raw prompt text, file contents, and secret
values are not included.

## Update channel

Manual update:

```sh
gain-agent update --check
gain-agent update
```

Managed auto-update:

```sh
gain-agent enable-auto-update
gain-agent disable-auto-update
```

The updater reads `latest.json`, skips work when the installed version is
current, and uses the hosted installer with SHA-256 verification when an update
is available. On Windows, `enable-auto-update` creates a hidden daily Scheduled
Task. On macOS/Linux it prints the cron entry for IT/MDM deployment.

## Licensing (self-hosted / offline)

For self-hosted or air-gapped deployments, the agent supports an **offline signed
license**. No phone-home required. A license proves entitlement (org, seats,
expiry, features) and is verified with Ed25519 against an embedded public key, so
it can't be forged or edited.

Self-hosted mode is explicit configuration, not a hidden build flag:

```sh
gain-agent setup --deployment-mode self_hosted --no-telemetry \
  --supabase-url https://gain.internal.example \
  --org-key <ORG_KEY>
```

With `deployment_mode=self_hosted` and telemetry disabled, the agent will not
send events to CyberWardion's hosted backend. It can still report metadata to
the customer's own self-hosted Edge/Supabase endpoint when `--supabase-url`
points there.

```sh
gain-agent license <license-string>     # install
gain-agent license @license.txt          # install from a file
gain-agent license                       # show status (org, seats, expiry)
gain-agent doctor                         # also reports license validity
```

Licensing is **additive**: an unlicensed agent still runs (so nothing breaks
out of the box). Self-hosted builds can gate enforcement on a valid license by
checking `verifyLicense().valid`. Configure the public key via
`GAIN_LICENSE_PUBLIC_KEY` or `src/license/public-key.pem`. (License issuing is
done by CyberWardion with the private key, never shipped to customers.)

CyberWardion-side license issuing supports both term and founding-customer
lifetime licenses:

```sh
node scripts/issue-license.js --org "Acme GmbH" --seats 25 --expires 2027-01-01
node scripts/issue-license.js --org "Acme GmbH" --seats 25 --lifetime --features self_hosted,mcp
```

## Privacy

The agent transmits **metadata only**: pattern types, counts, severities, the
action taken, and a timestamp. It never sends your prompts, file contents, or the
actual sensitive values. Detection and redaction run entirely on your machine.

## License

UNLICENSED. Copyright CyberWardion. Contact support@cyberwardion.com.
