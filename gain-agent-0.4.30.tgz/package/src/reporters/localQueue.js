"use strict";

// Append-only local queue of metadata events (JSON lines) at ~/.gain/queue.jsonl.
// Events wait here until they are flushed to the Supabase Edge ingest.
// Stores metadata only. Never prompt or file content.

const fs = require("fs");
const path = require("path");
const { configDir } = require("../config/loadPolicy");

function queuePath() {
  return path.join(configDir(), "queue.jsonl");
}

function enqueue(event) {
  const dir = configDir();
  fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(queuePath(), `${JSON.stringify(event)}\n`);
}

function readAll() {
  try {
    return fs.readFileSync(queuePath(), "utf8")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        try { return JSON.parse(line); } catch (_error) { return null; }
      })
      .filter(Boolean);
  } catch (_error) {
    return [];
  }
}

function count() {
  return readAll().length;
}

function rewrite(events) {
  const dir = configDir();
  fs.mkdirSync(dir, { recursive: true });
  if (!events.length) {
    try { fs.rmSync(queuePath()); } catch (_error) { /* already gone */ }
    return;
  }
  fs.writeFileSync(queuePath(), events.map((event) => JSON.stringify(event)).join("\n") + "\n");
}

function clear() {
  rewrite([]);
}

module.exports = { enqueue, readAll, count, rewrite, clear, queuePath };
