"use strict";

// Posts metadata-only events to the Supabase Edge ingest, matching the contract in
// supabase/functions/extension-events/index.ts:
//   - POST {supabase_url}/functions/v1/extension-events
//   - org key via x-org-api-key header
//   - supabase anon key via apikey + Authorization headers
//   - body: { event: { event_type, domain, tool_name, ... } }
// data_source is forced to "live" server-side. Never sends prompt/file content.

const EVENTS_PATH = "/functions/v1/extension-events";
const BOOTSTRAP_PATH = "/functions/v1/extension-bootstrap";
const HEARTBEAT_PATH = "/functions/v1/extension-heartbeat";
const PRESENCE_PATH = "/functions/v1/extension-presence";
const TIMEOUT_MS = 8000;
const AGENT_VERSION = require("../../package.json").version;
const { DEFAULT_SUPABASE_URL } = require("../config/loadPolicy");

function isConfigured(config) {
  return Boolean(config && config.org_api_key && config.supabase_url && config.supabase_key);
}

function isDefaultHostedBackend(url) {
  return String(url || "").replace(/\/+$/, "") === DEFAULT_SUPABASE_URL;
}

function shouldContactBackend(config) {
  if (!isConfigured(config)) return { ok: false, reason: "not_configured" };
  if (config.active === false) return { ok: false, reason: "device_removed_by_admin" };
  if (config.deployment_mode === "self_hosted" && config.telemetry_enabled === false && isDefaultHostedBackend(config.supabase_url)) {
    return { ok: false, reason: "self_hosted_no_vendor_telemetry" };
  }
  return { ok: true };
}

function buildHeaders(config) {
  return {
    "Content-Type": "application/json",
    "apikey": config.supabase_key,
    "Authorization": `Bearer ${config.supabase_key}`,
    "x-org-api-key": config.org_api_key
  };
}

async function sendEvent(config, event) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  const url = config.supabase_url.replace(/\/+$/, "") + EVENTS_PATH;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: buildHeaders(config),
      body: JSON.stringify({ event }),
      signal: controller.signal
    });
    const text = await response.text();
    let parsed = {};
    try { parsed = JSON.parse(text); } catch (_error) { parsed = { raw: text }; }
    if (!response.ok || parsed.ok === false) {
      return { ok: false, status: response.status, error: parsed.error || text || `HTTP ${response.status}` };
    }
    return { ok: true, status: response.status, event: parsed.event };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  } finally {
    clearTimeout(timer);
  }
}

function buildAgentDevicePayload(config, extra = {}) {
  return {
    device_id: config.device_id,
    device_label: config.device_label || "G.A.I.N Agent",
    department: config.department || null,
    component: "agent",
    browser: "agent",
    extension_id: "gain-agent",
    extension_version: `agent-${AGENT_VERSION}`,
    deployment_mode: config.deployment_mode || "hosted",
    status: "active",
    ...extra
  };
}

async function postEdge(config, path, body) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  const url = config.supabase_url.replace(/\/+$/, "") + path;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: buildHeaders(config),
      body: JSON.stringify(body),
      signal: controller.signal
    });
    const text = await response.text();
    let parsed = {};
    try { parsed = JSON.parse(text); } catch (_error) { parsed = { raw: text }; }
    if (!response.ok || parsed.ok === false) {
      return { ok: false, status: response.status, error: parsed.error || text || `HTTP ${response.status}`, code: parsed.code || null };
    }
    return { ok: true, status: response.status, ...parsed };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  } finally {
    clearTimeout(timer);
  }
}

async function enrollDevice(config, extra = {}) {
  return postEdge(config, BOOTSTRAP_PATH, {
    org_api_key: config.org_api_key,
    reactivate: true,
    enrollment_intent: "reactivate",
    ...buildAgentDevicePayload(config, extra)
  });
}

async function sendHeartbeat(config, extra = {}) {
  return postEdge(config, HEARTBEAT_PATH, {
    org_api_key: config.org_api_key,
    ...buildAgentDevicePayload(config, extra)
  });
}

async function sendPresence(config, extra = {}) {
  return postEdge(config, PRESENCE_PATH, {
    org_api_key: config.org_api_key,
    ...buildAgentDevicePayload(config, extra)
  });
}

async function checkConnection(config) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  const url = config.supabase_url.replace(/\/+$/, "") + BOOTSTRAP_PATH;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: buildHeaders(config),
      body: JSON.stringify({
        preview_only: true,
        org_api_key: config.org_api_key,
        device_id: config.device_id,
        device_label: config.device_label || "G.A.I.N Agent",
        component: "agent",
        browser: "agent",
        extension_version: "agent",
        deployment_mode: config.deployment_mode || "hosted"
      }),
      signal: controller.signal
    });
    const text = await response.text();
    let parsed = {};
    try { parsed = JSON.parse(text); } catch (_error) { parsed = { raw: text }; }
    if (!response.ok || parsed.ok === false) {
      return { ok: false, status: response.status, error: parsed.error || text || `HTTP ${response.status}` };
    }
    return {
      ok: true,
      status: response.status,
      org: parsed.org || (parsed.policy_bundle && parsed.policy_bundle.org) || null,
      license: parsed.policy_bundle && parsed.policy_bundle.license ? parsed.policy_bundle.license : null
    };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  } finally {
    clearTimeout(timer);
  }
}

async function fetchPolicyBundle(config) {
  const contact = shouldContactBackend(config);
  if (!contact.ok) return { ok: false, skipped: true, reason: contact.reason };
  if (typeof fetch !== "function") {
    return { ok: false, skipped: true, reason: "fetch_unavailable" };
  }

  const url = config.supabase_url.replace(/\/+$/, "") + BOOTSTRAP_PATH;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: buildHeaders(config),
      body: JSON.stringify({
        preview_only: true,
        org_api_key: config.org_api_key,
        device_id: config.device_id,
        device_label: config.device_label || "G.A.I.N Agent",
        component: "agent",
        browser: "agent",
        extension_version: "agent",
        deployment_mode: config.deployment_mode || "hosted"
      }),
      signal: controller.signal
    });
    const text = await response.text();
    let parsed = {};
    try { parsed = JSON.parse(text); } catch (_error) { parsed = { raw: text }; }
    if (!response.ok || parsed.ok === false || !parsed.policy_bundle) {
      return { ok: false, status: response.status, error: parsed.error || text || `HTTP ${response.status}` };
    }
    return {
      ok: true,
      status: response.status,
      policy_bundle: parsed.policy_bundle,
      org: parsed.org || parsed.policy_bundle.org || null,
      license: parsed.policy_bundle.license || null
    };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  } finally {
    clearTimeout(timer);
  }
}

module.exports = {
  sendEvent,
  checkConnection,
  fetchPolicyBundle,
  enrollDevice,
  sendHeartbeat,
  sendPresence,
  isConfigured,
  shouldContactBackend,
  EVENTS_PATH,
  BOOTSTRAP_PATH,
  HEARTBEAT_PATH,
  PRESENCE_PATH,
  AGENT_VERSION
};
