"use strict";

const TIMEOUT_MS = 5000;

function hasSiem(config) {
  return Boolean(config && config.siem_webhook_url);
}

function siemEvent(event, config) {
  return {
    vendor: "CyberWardion",
    product: "G.A.I.N",
    surface: event.surface || "agent",
    event_type: event.event_type,
    action: event.action || event.enforcement_action,
    severity: event.severity,
    tool_name: event.tool_name,
    domain: event.domain,
    category: event.category,
    patterns_detected: event.patterns_detected || [],
    policy_triggered: event.policy_triggered || null,
    content_length: event.content_length || 0,
    device_id: event.device_id || config.device_id || null,
    department: config.department || null,
    created_at: event.created_at || new Date().toISOString()
  };
}

async function sendSiemEvent(config, event) {
  if (!hasSiem(config)) return { ok: false, skipped: true, reason: "siem_not_configured" };
  if (typeof fetch !== "function") return { ok: false, skipped: true, reason: "fetch_unavailable" };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const headers = { "Content-Type": "application/json" };
  if (config.siem_bearer_token) headers.Authorization = `Bearer ${config.siem_bearer_token}`;

  try {
    const response = await fetch(config.siem_webhook_url, {
      method: "POST",
      headers,
      body: JSON.stringify(siemEvent(event, config)),
      signal: controller.signal
    });
    if (!response.ok) return { ok: false, status: response.status, error: `HTTP ${response.status}` };
    return { ok: true, status: response.status };
  } catch (error) {
    return { ok: false, error: error.name === "AbortError" ? "timeout" : error.message };
  } finally {
    clearTimeout(timer);
  }
}

module.exports = { hasSiem, siemEvent, sendSiemEvent };
