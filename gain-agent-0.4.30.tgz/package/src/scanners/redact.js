"use strict";

// Single source of truth: the agent reuses the SAME redaction logic the browser
// extension ships in shared/redact.js, loaded in a VM context exactly like
// scanners/patterns.js. The extension, the dashboard simulator, and the agent
// therefore redact identically. scripts/scanner-harness.js asserts the
// canonical redactor matches the extension's inline copy over the full corpus.
//
// Override the path with GAIN_REDACT_PATH (used in a packaged/vendored build).

const fs = require("fs");
const path = require("path");
const vm = require("vm");

// Packaged build: vendor/redact.js ships inside the package. Dev checkout: fall
// back to the repo's shared/redact.js. Override with env.
const VENDORED_REDACT_PATH = path.resolve(__dirname, "..", "..", "vendor", "redact.js");
const REPO_REDACT_PATH = path.resolve(__dirname, "..", "..", "..", "shared", "redact.js");
const REDACT_PATH = process.env.GAIN_REDACT_PATH
  || (fs.existsSync(VENDORED_REDACT_PATH) ? VENDORED_REDACT_PATH : REPO_REDACT_PATH);

function loadRedactor(redactPath) {
  const code = fs.readFileSync(redactPath, "utf8");
  const context = { globalThis: {}, module: { exports: {} } };
  vm.createContext(context);
  vm.runInContext(code, context);
  const api = context.globalThis.SHADOW_AI_REDACT;
  if (!api || typeof api.redactSensitiveText !== "function") {
    throw new Error("shared/redact.js did not expose SHADOW_AI_REDACT.redactSensitiveText");
  }
  return api;
}

let redactor;
function getRedactor() {
  if (!redactor) {
    try {
      redactor = loadRedactor(REDACT_PATH);
    } catch (error) {
      throw new Error(`Could not load redactor from ${REDACT_PATH}: ${error.message}`);
    }
  }
  return redactor;
}

function redactSensitiveText(text, patterns) {
  return getRedactor().redactSensitiveText(String(text || ""), Array.isArray(patterns) ? patterns : []);
}

module.exports = { redactSensitiveText, getRedactor, REDACT_PATH };
