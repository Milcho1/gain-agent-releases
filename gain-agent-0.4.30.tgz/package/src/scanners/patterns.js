"use strict";

// Single source of truth: the agent reuses the SAME detection logic the browser
// extension ships in shared/patterns.js. We load it in a VM context (exactly like
// scripts/scanner-harness.js) so the agent and extension can never drift apart.
//
// In a standalone/published build, a packaging step would vendor shared/patterns.js
// into the agent. For the in-repo MVP we resolve it relative to the repo root, and
// allow an override via GAIN_PATTERNS_PATH.

const fs = require("fs");
const path = require("path");
const vm = require("vm");

// Dev checkout: always use the repo's canonical shared/patterns.js when it is
// present. Packaged builds do not include ../../../shared, so they fall back to
// vendor/patterns.js. Override with env for explicit tests/emergency use only.
const VENDORED_PATTERNS_PATH = path.resolve(__dirname, "..", "..", "vendor", "patterns.js");
const REPO_PATTERNS_PATH = path.resolve(__dirname, "..", "..", "..", "shared", "patterns.js");

function resolvePatternsPath({
  env = process.env,
  fsImpl = fs,
  repoPatternsPath = REPO_PATTERNS_PATH,
  vendorPatternsPath = VENDORED_PATTERNS_PATH
} = {}) {
  if (env.GAIN_PATTERNS_PATH) return env.GAIN_PATTERNS_PATH;
  if (fsImpl.existsSync(repoPatternsPath)) return repoPatternsPath;
  return vendorPatternsPath;
}

const PATTERNS_PATH = resolvePatternsPath();

function loadDetector(patternsPath) {
  const code = fs.readFileSync(patternsPath, "utf8");
  const context = { globalThis: {} };
  vm.createContext(context);
  vm.runInContext(code, context);
  const api = context.globalThis.SHADOW_AI_PATTERNS;
  if (!api || typeof api.detectSensitivePatterns !== "function") {
    throw new Error("shared/patterns.js did not expose SHADOW_AI_PATTERNS.detectSensitivePatterns");
  }
  return api;
}

let detector;
function getDetector() {
  if (!detector) {
    try {
      detector = loadDetector(PATTERNS_PATH);
    } catch (error) {
      throw new Error(`Could not load detection patterns from ${PATTERNS_PATH}: ${error.message}`);
    }
  }
  return detector;
}

function detectSensitivePatterns(text) {
  return getDetector().detectSensitivePatterns(String(text || ""));
}

module.exports = { detectSensitivePatterns, getDetector, PATTERNS_PATH, resolvePatternsPath };
