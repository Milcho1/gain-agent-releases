"use strict";

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const { spawnSync } = require("child_process");

const DOCUMENT_EXTENSIONS = new Set([".pdf", ".docx"]);
const MAX_EXTRACTED_TEXT_CHARS = 2 * 1024 * 1024;

function documentKind(filePath) {
  const ext = path.extname(String(filePath || "")).toLowerCase();
  if (ext === ".pdf") return "pdf";
  if (ext === ".docx") return "docx";
  return null;
}

function extractDocumentText(filePath, options = {}) {
  const kind = documentKind(filePath);
  if (kind === "docx") return extractDocxText(filePath, options);
  if (kind === "pdf") return extractPdfText(filePath, options);
  return { ok: false, kind: null, text: "", reason: "unsupported_document_type" };
}

function extractDocxText(filePath) {
  try {
    const buffer = fs.readFileSync(filePath);
    const xml = readZipEntry(buffer, "word/document.xml");
    if (!xml) return { ok: false, kind: "docx", text: "", reason: "docx_document_xml_missing" };
    return {
      ok: true,
      kind: "docx",
      text: limitText(stripDocxXmlText(xml.toString("utf8"))),
      reason: null
    };
  } catch (error) {
    return { ok: false, kind: "docx", text: "", reason: error.message || "docx_extract_failed" };
  }
}

function extractPdfText(filePath, options = {}) {
  if (typeof options.pdfTextExtractor === "function") {
    try {
      return { ok: true, kind: "pdf", text: limitText(options.pdfTextExtractor(filePath)), reason: null };
    } catch (error) {
      return { ok: false, kind: "pdf", text: "", reason: error.message || "pdf_extract_failed" };
    }
  }
  const commands = Array.isArray(options.pdftotextCommands) && options.pdftotextCommands.length
    ? options.pdftotextCommands
    : ["pdftotext"];
  for (const command of commands) {
    const result = spawnSync(command, ["-layout", filePath, "-"], {
      encoding: "utf8",
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true
    });
    if (result.error && result.error.code === "ENOENT") continue;
    if (result.error) {
      return { ok: false, kind: "pdf", text: "", reason: result.error.message || "pdf_extract_failed" };
    }
    if (result.status === 0) {
      return { ok: true, kind: "pdf", text: limitText(result.stdout || ""), reason: null };
    }
    const detail = String(result.stderr || "").trim();
    return { ok: false, kind: "pdf", text: "", reason: detail || `pdftotext_exit_${result.status}` };
  }
  return { ok: false, kind: "pdf", text: "", reason: "pdftotext_not_found" };
}

function readZipEntry(buffer, targetName) {
  const eocdOffset = findEndOfCentralDirectory(buffer);
  if (eocdOffset < 0) throw new Error("zip_central_directory_missing");
  const totalEntries = readUInt16(buffer, eocdOffset + 10);
  let offset = readUInt32(buffer, eocdOffset + 16);
  for (let i = 0; i < totalEntries; i += 1) {
    if (readUInt32(buffer, offset) !== 0x02014b50) throw new Error("zip_central_directory_invalid");
    const compression = readUInt16(buffer, offset + 10);
    const compressedSize = readUInt32(buffer, offset + 20);
    const fileNameLength = readUInt16(buffer, offset + 28);
    const extraLength = readUInt16(buffer, offset + 30);
    const commentLength = readUInt16(buffer, offset + 32);
    const localHeaderOffset = readUInt32(buffer, offset + 42);
    const nameStart = offset + 46;
    const name = buffer.subarray(nameStart, nameStart + fileNameLength).toString("utf8").replace(/\\/g, "/");
    if (name === targetName) return readLocalZipEntry(buffer, localHeaderOffset, compressedSize, compression);
    offset = nameStart + fileNameLength + extraLength + commentLength;
  }
  return null;
}

function readLocalZipEntry(buffer, localHeaderOffset, compressedSize, compression) {
  if (readUInt32(buffer, localHeaderOffset) !== 0x04034b50) throw new Error("zip_local_header_invalid");
  const fileNameLength = readUInt16(buffer, localHeaderOffset + 26);
  const extraLength = readUInt16(buffer, localHeaderOffset + 28);
  const dataStart = localHeaderOffset + 30 + fileNameLength + extraLength;
  const data = buffer.subarray(dataStart, dataStart + compressedSize);
  if (compression === 0) return data;
  if (compression === 8) return zlib.inflateRawSync(data);
  throw new Error(`zip_compression_${compression}_unsupported`);
}

function findEndOfCentralDirectory(buffer) {
  const min = Math.max(0, buffer.length - 22 - 65535);
  for (let i = buffer.length - 22; i >= min; i -= 1) {
    if (readUInt32(buffer, i) === 0x06054b50) return i;
  }
  return -1;
}

function stripDocxXmlText(xml) {
  return decodeXmlEntities(String(xml || "")
    .replace(/<w:tab\b[^>]*\/>/g, "\t")
    .replace(/<w:br\b[^>]*\/>/g, "\n")
    .replace(/<\/w:p>/g, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim());
}

function decodeXmlEntities(value) {
  const named = { amp: "&", lt: "<", gt: ">", quot: "\"", apos: "'" };
  return String(value || "").replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (match, entity) => {
    if (entity[0] === "#") {
      const isHex = entity[1] && entity[1].toLowerCase() === "x";
      const code = Number.parseInt(entity.slice(isHex ? 2 : 1), isHex ? 16 : 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    }
    return Object.prototype.hasOwnProperty.call(named, entity) ? named[entity] : match;
  });
}

function limitText(value) {
  return String(value || "").slice(0, MAX_EXTRACTED_TEXT_CHARS);
}

function readUInt16(buffer, offset) {
  if (offset < 0 || offset + 2 > buffer.length) throw new Error("zip_read_out_of_range");
  return buffer.readUInt16LE(offset);
}

function readUInt32(buffer, offset) {
  if (offset < 0 || offset + 4 > buffer.length) throw new Error("zip_read_out_of_range");
  return buffer.readUInt32LE(offset);
}

module.exports = {
  DOCUMENT_EXTENSIONS,
  MAX_EXTRACTED_TEXT_CHARS,
  documentKind,
  extractDocumentText,
  extractDocxText,
  extractPdfText,
  stripDocxXmlText,
  _internal: { readZipEntry, findEndOfCentralDirectory }
};
