"use strict";

// STUB. Not wired yet (Phase 2).
// Intended to wrap terminal AI tools (e.g. `gain-agent run -- <ai-cli> ...`) so prompts
// and referenced files are scanned/redacted before they reach the model, with a
// metadata-only event reported. No prompt content is stored.

function wrapCommand() {
  throw new Error("shellWrapper is a Phase 2 stub and is not implemented yet.");
}

module.exports = { wrapCommand };
