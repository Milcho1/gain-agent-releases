"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync, execFileSync } = require("child_process");
const {
  PROXY_URL,
  persistProxyEnvironment,
  parseLoopbackProxyUrl,
  probeProxyPort
} = require("../system/proxyService");

const GAIN_MCP = { command: "gain-agent", args: ["mcp"] };
const CLAUDE_HOOK_COMMAND = "gain-agent claude-hook";
const CLAUDE_HOOK_EVENTS = ["UserPromptSubmit", "PreToolUse"];
const PROXY_ENV_VARS = ["ANTHROPIC_BASE_URL", "OPENAI_BASE_URL", "OPENAI_API_BASE", "COPILOT_PROVIDER_BASE_URL"];

function defaultCommandExists(command, options = {}) {
  const platform = options.platform || process.platform;
  const runner = platform === "win32" ? "where.exe" : "which";
  const result = spawnSync(runner, [command], { stdio: "ignore", windowsHide: true });
  return !result.error && result.status === 0;
}

function defaultCommandPaths(command, options = {}) {
  const platform = options.platform || process.platform;
  const runner = platform === "win32" ? "where.exe" : "which";
  const result = spawnSync(runner, [command], { encoding: "utf8", windowsHide: true });
  if (result.error || result.status !== 0) return [];
  return String(result.stdout || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function homeDirFromOptions(options = {}) {
  return options.homeDir || os.homedir();
}

function appDataPaths(homeDir, options = {}) {
  return {
    appData: options.appData || process.env.APPDATA || path.join(homeDir, "AppData", "Roaming"),
    localAppData: options.localAppData || process.env.LOCALAPPDATA || path.join(homeDir, "AppData", "Local")
  };
}

function toolPaths(homeDir, options = {}) {
  const { appData, localAppData } = appDataPaths(homeDir, options);
  const vscodeStorage = path.join(appData, "Code", "User", "globalStorage");
  return {
    claude: {
      dir: path.join(homeDir, ".claude"),
      legacyJson: path.join(homeDir, ".claude.json"),
      configPath: path.join(homeDir, ".claude", "settings.json"),
      windowsDesktop: path.join(localAppData, "AnthropicClaude", "claude.exe"),
      macDesktop: path.join(homeDir, "Library", "Application Support", "Claude")
    },
    cursor: {
      dir: path.join(homeDir, ".cursor"),
      configPath: path.join(homeDir, ".cursor", "mcp.json"),
      windowsApp: path.join(localAppData, "Programs", "Cursor", "Cursor.exe")
    },
    codex: {
      dir: path.join(homeDir, ".codex"),
      configPath: path.join(homeDir, ".codex", "config.toml")
    },
    gemini: {
      dir: path.join(homeDir, ".gemini"),
      configPath: path.join(homeDir, ".gemini", "settings.json")
    },
    copilot: {
      ghExtension: path.join(homeDir, ".config", "gh", "extensions", "gh-copilot"),
      windowsGhExtension: path.join(appData, "GitHub CLI", "extensions", "gh-copilot")
    },
    windsurf: {
      dir: path.join(homeDir, ".codeium", "windsurf"),
      altDir: path.join(homeDir, ".windsurf"),
      windowsApp: path.join(localAppData, "Programs", "Windsurf", "Windsurf.exe")
    },
    aider: {
      configPath: path.join(homeDir, ".aider.conf.yml"),
      altConfigPath: path.join(homeDir, ".aider.conf.yaml")
    },
    continue: {
      dir: path.join(homeDir, ".continue"),
      vscodeStorage: path.join(vscodeStorage, "continue.continue")
    },
    cline: {
      vscodeStorage: path.join(vscodeStorage, "saoudrizwan.claude-dev"),
      rooStorage: path.join(vscodeStorage, "rooveterinaryinc.roo-cline")
    }
  };
}

function toolDefinitions(paths) {
  return [
    {
      id: "claude-code",
      name: "Claude Code",
      configType: "claude",
      configPath: paths.claude.configPath,
      commands: ["claude"],
      checks: [
        ["settings", paths.claude.configPath],
        ["config directory", paths.claude.dir],
        ["legacy config", paths.claude.legacyJson],
        ["Windows desktop app", paths.claude.windowsDesktop, "win32"],
        ["macOS desktop app", paths.claude.macDesktop, "darwin"]
      ],
      mechanisms: ["redact via proxy", "block via hook", "MCP", "git"],
      proxyEnv: ["ANTHROPIC_BASE_URL"],
      mcp: true,
      nativeHook: true,
      gitFallback: true
    },
    {
      id: "cursor",
      name: "Cursor",
      configType: "json-mcp",
      configPath: paths.cursor.configPath,
      commands: ["cursor"],
      checks: [
        ["mcp config", paths.cursor.configPath],
        ["config directory", paths.cursor.dir],
        ["Windows app", paths.cursor.windowsApp, "win32"]
      ],
      mechanisms: ["MCP", "git"],
      mcp: true,
      gitFallback: true,
      notes: "Proxy redaction is available only in Cursor modes that explicitly use an OpenAI-compatible custom base URL."
    },
    {
      id: "copilot-cli",
      name: "GitHub Copilot CLI",
      configType: "proxy-env",
      commands: ["gh", "copilot"],
      checks: [
        ["GitHub CLI Copilot extension", paths.copilot.ghExtension],
        ["Windows GitHub CLI Copilot extension", paths.copilot.windowsGhExtension, "win32"]
      ],
      mechanisms: ["redact via proxy", "git"],
      proxyEnv: ["COPILOT_PROVIDER_BASE_URL"],
      gitFallback: true
    },
    {
      id: "codex-cli",
      name: "OpenAI Codex CLI",
      configType: "toml",
      configPath: paths.codex.configPath,
      commands: ["codex"],
      checks: [
        ["config", paths.codex.configPath],
        ["config directory", paths.codex.dir]
      ],
      mechanisms: ["redact via proxy", "MCP", "git"],
      proxyEnv: ["OPENAI_BASE_URL", "OPENAI_API_BASE"],
      mcp: true,
      gitFallback: true
    },
    {
      id: "gemini-cli",
      name: "Gemini CLI",
      configType: "json-mcp",
      configPath: paths.gemini.configPath,
      commands: ["gemini"],
      checks: [
        ["settings", paths.gemini.configPath],
        ["config directory", paths.gemini.dir]
      ],
      mechanisms: ["MCP", "git"],
      mcp: true,
      gitFallback: true,
      notes: "Gemini native API traffic is not routed through the proxy until the proxy supports Gemini request bodies."
    },
    {
      id: "windsurf",
      name: "Windsurf",
      configType: "none",
      commands: ["windsurf"],
      checks: [
        ["config directory", paths.windsurf.dir],
        ["legacy config directory", paths.windsurf.altDir],
        ["Windows app", paths.windsurf.windowsApp, "win32"]
      ],
      mechanisms: ["git"],
      gitFallback: true,
      notes: "No stable native hook or config file is edited. Git protection still catches generated secrets before commit."
    },
    {
      id: "aider",
      name: "Aider",
      configType: "proxy-env",
      commands: ["aider"],
      checks: [
        ["config", paths.aider.configPath],
        ["config", paths.aider.altConfigPath]
      ],
      mechanisms: ["redact via proxy", "git"],
      proxyEnv: ["OPENAI_API_BASE"],
      gitFallback: true
    },
    {
      id: "continue",
      name: "Continue",
      configType: "none",
      commands: ["continue"],
      checks: [
        ["config directory", paths.continue.dir],
        ["VS Code storage", paths.continue.vscodeStorage]
      ],
      mechanisms: ["git"],
      gitFallback: true,
      notes: "No stable native hook is edited. Use git protection plus MCP or provider settings where your Continue setup supports them."
    },
    {
      id: "cline",
      name: "Cline",
      configType: "none",
      commands: ["cline"],
      checks: [
        ["VS Code storage", paths.cline.vscodeStorage],
        ["Roo/Cline storage", paths.cline.rooStorage]
      ],
      mechanisms: ["git"],
      gitFallback: true,
      notes: "No stable native hook is edited. Git protection catches secrets written by the agent before commit."
    }
  ];
}

function shellQuote(value) {
  const text = String(value || "");
  if (!text) return "\"\"";
  if (!/[\s"]/.test(text)) return text;
  return `"${text.replace(/"/g, "\\\"")}"`;
}

function bashCommandPath(filePath, options = {}) {
  const platform = options.platform || process.platform;
  const raw = String(filePath || "");
  if (raw && !/[\\/]/.test(raw) && !/^[a-zA-Z]:/.test(raw)) return raw;
  const resolved = path.resolve(raw);
  if (platform === "win32") return resolved.replace(/\\/g, "/");
  return resolved;
}

function isBuildArtifactAgentPath(filePath) {
  return /[\\/]dist[\\/]binaries[\\/]gain-agent-\d+\.\d+\.\d+/i.test(String(filePath || ""));
}

function isStandaloneAgentName(filePath) {
  return /^gain-agent(?:\.exe)?$/i.test(path.basename(String(filePath || "")));
}

function isUsableAgentBinary(filePath, options = {}) {
  const candidate = String(filePath || "").trim();
  if (!candidate || isBuildArtifactAgentPath(candidate) || !isStandaloneAgentName(candidate)) return false;
  const exists = options.exists || fs.existsSync;
  if (!exists(candidate)) return false;
  if ((options.platform || process.platform) === "win32") return true;
  try {
    fs.accessSync(candidate, fs.constants.X_OK);
    return true;
  } catch (_error) {
    return true;
  }
}

function installedAgentCandidates(options = {}) {
  const homeDir = homeDirFromOptions(options);
  const { localAppData } = appDataPaths(homeDir, options);
  const platform = options.platform || process.platform;
  const commandPaths = options.commandPaths || ((command) => defaultCommandPaths(command, { platform }));
  const candidates = [
    options.installedAgentPath,
    process.env.GAIN_AGENT_PATH,
    process.env.GAIN_AGENT_BIN
  ];

  if (platform === "win32") {
    candidates.push(
      path.join(localAppData, "Programs", "GAIN", "bin", "gain-agent.exe"),
      path.join(localAppData, "Programs", "G.A.I.N Agent", "gain-agent.exe")
    );
  } else {
    candidates.push(
      path.join(homeDir, ".local", "bin", "gain-agent"),
      "/usr/local/bin/gain-agent",
      "/opt/gain/bin/gain-agent"
    );
  }

  candidates.push(...commandPaths("gain-agent"));
  candidates.push(options.agentPath, process.execPath);
  return [...new Set(candidates.filter(Boolean).map(String))];
}

function resolveInstalledAgentPath(options = {}) {
  const candidates = installedAgentCandidates(options);
  const found = candidates.find((candidate) => isUsableAgentBinary(candidate, options));
  if (found) return found;
  const fallback = String(options.agentPath || process.execPath || "");
  if (isBuildArtifactAgentPath(fallback)) return "gain-agent";
  return fallback && !/\bnode(?:\.exe)?$/i.test(path.basename(fallback)) ? fallback : "gain-agent";
}

function claudeHookCommand(options = {}) {
  if (options.agentCommand) return String(options.agentCommand);
  const agentPath = resolveInstalledAgentPath(options);
  return `${shellQuote(bashCommandPath(agentPath, options))} claude-hook`;
}

function matchesToolFilter(tool, filter) {
  if (!filter || !filter.length) return true;
  const candidates = [tool.id, tool.name, ...(tool.commands || [])]
    .filter(Boolean)
    .map((v) => String(v).toLowerCase().replace(/\s+/g, "-"));
  return filter.some((item) => candidates.includes(item));
}

function normalizeToolFilter(value) {
  if (Array.isArray(value)) return value.map(String).map((s) => s.trim().toLowerCase()).filter(Boolean);
  return String(value || "")
    .split(",")
    .map((s) => s.trim().toLowerCase().replace(/\s+/g, "-"))
    .filter(Boolean);
}

function detectTool(def, options = {}) {
  const exists = options.exists || fs.existsSync;
  const commandExists = options.commandExists || ((command) => defaultCommandExists(command, { platform: options.platform || process.platform }));
  const platform = options.platform || process.platform;

  for (const [label, filePath, onlyPlatform] of def.checks || []) {
    if (onlyPlatform && onlyPlatform !== platform) continue;
    if (filePath && exists(filePath)) return { detected: true, detectedBy: label };
  }
  for (const command of def.commands || []) {
    if (commandExists(command)) return { detected: true, detectedBy: `${command} on PATH` };
  }
  return { detected: false, detectedBy: null };
}

function detectInstalledTools(options = {}) {
  const homeDir = homeDirFromOptions(options);
  const paths = toolPaths(homeDir, options);
  const filter = normalizeToolFilter(options.tools || options.toolFilter);
  return toolDefinitions(paths)
    .filter((def) => matchesToolFilter(def, filter))
    .map((def) => {
      const detected = detectTool(def, options);
      return { ...def, detected: detected.detected, detectedBy: detected.detectedBy };
    });
}

function readJsonFile(filePath) {
  if (!fs.existsSync(filePath)) return {};
  const raw = fs.readFileSync(filePath, "utf8").trim();
  if (!raw) return {};
  return JSON.parse(raw);
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function ensureMcpServer(config, added) {
  if (!isPlainObject(config.mcpServers)) config.mcpServers = {};
  const current = config.mcpServers.gain;
  if (isPlainObject(current) && current.command === GAIN_MCP.command && JSON.stringify(current.args || []) === JSON.stringify(GAIN_MCP.args)) {
    return false;
  }
  config.mcpServers.gain = { ...GAIN_MCP };
  added.push("MCP server gain");
  return true;
}

function isGainClaudeHookCommand(command) {
  return /\bgain-agent(?:\.exe)?\b/i.test(String(command || "")) && /\bclaude-hook\b/i.test(String(command || ""));
}

function hasClaudeHook(config, eventName, hookCommand) {
  const entries = config.hooks && config.hooks[eventName];
  if (!Array.isArray(entries)) return false;
  return entries.some((entry) => Array.isArray(entry.hooks) && entry.hooks.some((hook) =>
    hook && hook.type === "command" && hook.command === hookCommand
  ));
}

function ensureClaudeHook(config, eventName, added, hookCommand) {
  if (!isPlainObject(config.hooks)) config.hooks = {};
  if (config.hooks[eventName] !== undefined && !Array.isArray(config.hooks[eventName])) {
    throw new Error(`Claude settings hooks.${eventName} must be an array`);
  }
  if (!Array.isArray(config.hooks[eventName])) config.hooks[eventName] = [];
  if (hasClaudeHook(config, eventName, hookCommand)) return false;
  for (const entry of config.hooks[eventName]) {
    if (!Array.isArray(entry && entry.hooks)) continue;
    const existing = entry.hooks.find((hook) => hook && hook.type === "command" && isGainClaudeHookCommand(hook.command));
    if (existing) {
      existing.command = hookCommand;
      added.push(`Claude Code ${eventName} hook`);
      return true;
    }
  }
  config.hooks[eventName].push({
    matcher: "",
    hooks: [{ type: "command", command: hookCommand }]
  });
  added.push(`Claude Code ${eventName} hook`);
  return true;
}

function wireClaudeSettings(config, options = {}) {
  const added = [];
  const hookCommand = claudeHookCommand(options);
  ensureMcpServer(config, added);
  for (const eventName of CLAUDE_HOOK_EVENTS) ensureClaudeHook(config, eventName, added, hookCommand);
  return { config, added, changed: added.length > 0 };
}

function wireJsonMcpConfig(config) {
  const added = [];
  ensureMcpServer(config, added);
  return { config, added, changed: added.length > 0 };
}

function gainTomlBlock() {
  return '[mcp_servers.gain]\ncommand = "gain-agent"\nargs = ["mcp"]\n';
}

function findTomlGainBlock(text) {
  const match = String(text || "").match(/(^|\n)\[mcp_servers\.gain\]\n[\s\S]*?(?=\n\[[^\]]+\]|\s*$)/);
  if (!match) return null;
  const start = match.index + match[1].length;
  const end = match.index + match[0].length;
  return { start, end, text: match[0].slice(match[1].length) };
}

function tomlBlockIsCurrent(block) {
  return /command\s*=\s*"gain-agent"/.test(block) && /args\s*=\s*\[\s*"mcp"\s*\]/.test(block);
}

function wireCodexToml(text) {
  const input = String(text || "");
  const block = findTomlGainBlock(input);
  if (block && tomlBlockIsCurrent(block.text)) {
    return { text: input, added: [], changed: false };
  }
  const nextBlock = gainTomlBlock();
  if (block) {
    return {
      text: `${input.slice(0, block.start)}${nextBlock}${input.slice(block.end).replace(/^\n+/, "\n")}`,
      added: ["MCP server gain"],
      changed: true
    };
  }
  const spacer = input.trim() ? (input.endsWith("\n") ? "\n" : "\n\n") : "";
  return { text: `${input}${spacer}${nextBlock}`, added: ["MCP server gain"], changed: true };
}

function backupPathFor(filePath, options = {}) {
  const stamp = (options.timestamp || new Date().toISOString()).replace(/[-:TZ.]/g, "").slice(0, 14);
  let candidate = `${filePath}.bak-${stamp}`;
  let index = 2;
  while (fs.existsSync(candidate)) {
    candidate = `${filePath}.bak-${stamp}-${index}`;
    index += 1;
  }
  return candidate;
}

function writeWithBackup(filePath, content, options = {}) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  let backupPath = null;
  const existed = fs.existsSync(filePath);
  if (existed) {
    backupPath = backupPathFor(filePath, options);
    fs.copyFileSync(filePath, backupPath);
  }
  fs.writeFileSync(filePath, content, "utf8");
  return { backupPath, created: !existed };
}

function applyToolWiring(tool, options = {}) {
  if (!tool.detected) return { ...tool, skipped: true, changed: false, added: [] };
  try {
    if (tool.configType === "claude") {
      const current = readJsonFile(tool.configPath);
      const wired = wireClaudeSettings(current, options);
      if (!wired.changed) return { ...tool, changed: false, added: [] };
      const write = writeWithBackup(tool.configPath, `${JSON.stringify(wired.config, null, 2)}\n`, options);
      return { ...tool, changed: true, added: wired.added, ...write };
    }
    if (tool.configType === "json-mcp") {
      const current = readJsonFile(tool.configPath);
      const wired = wireJsonMcpConfig(current);
      if (!wired.changed) return { ...tool, changed: false, added: [] };
      const write = writeWithBackup(tool.configPath, `${JSON.stringify(wired.config, null, 2)}\n`, options);
      return { ...tool, changed: true, added: wired.added, ...write };
    }
    if (tool.configType === "toml") {
      const current = fs.existsSync(tool.configPath) ? fs.readFileSync(tool.configPath, "utf8") : "";
      const wired = wireCodexToml(current);
      if (!wired.changed) return { ...tool, changed: false, added: [] };
      const write = writeWithBackup(tool.configPath, wired.text, options);
      return { ...tool, changed: true, added: wired.added, ...write };
    }
    return { ...tool, skipped: false, changed: false, added: [], reason: "No stable config file to edit for this tool." };
  } catch (error) {
    return { ...tool, ok: false, changed: false, added: [], error: error.message };
  }
}

function installGitFallback(options = {}) {
  try {
    const { installGlobalGitHook } = require("../hooks/gitHook");
    const result = installGlobalGitHook({
      homeDir: homeDirFromOptions(options),
      cliPath: resolveInstalledAgentPath(options),
      execFile: options.execFile || execFileSync,
      force: Boolean(options.forceGitHook)
    });
    return result.ok
      ? { ok: true, changed: true, added: [`Global git hook at ${result.hookPath}`], result }
      : { ok: false, changed: false, error: result.message || result.reason || "Could not install global git hook", result };
  } catch (error) {
    return { ok: false, changed: false, error: error.message };
  }
}

function applyProxyEnvironmentForTools(tools, options = {}) {
  const detectedProxyTools = tools.filter((tool) => tool.detected && Array.isArray(tool.proxyEnv) && tool.proxyEnv.length);
  if (!detectedProxyTools.length || options.noProxyEnv) return { ok: true, changed: false, skipped: true };
  try {
    return {
      ...persistProxyEnvironment({
        enabled: true,
        platform: options.platform || process.platform,
        homeDir: homeDirFromOptions(options),
        execFile: options.execFile || execFileSync,
        url: options.proxyUrl || PROXY_URL
      }),
      changed: true,
      tools: detectedProxyTools.map((tool) => tool.id)
    };
  } catch (error) {
    return { ok: false, changed: false, error: error.message, tools: detectedProxyTools.map((tool) => tool.id) };
  }
}

function agentInactive(options = {}) {
  return options.config && options.config.active === false;
}

function applyAutoWiring(options = {}) {
  if (agentInactive(options) && !options.allowInactive) {
    return {
      ok: false,
      skipped: true,
      reason: "agent_inactive",
      message: `G.A.I.N Agent is disabled locally${options.config.inactive_reason ? `: ${options.config.inactive_reason}` : ""}. Re-run setup before wiring coding tools.`,
      tools: [],
      proxyEnv: { ok: true, changed: false, skipped: true },
      git: { ok: true, changed: false, skipped: true },
      detectedCount: 0,
      changedCount: 0
    };
  }
  const tools = detectInstalledTools(options);
  const results = tools.map((tool) => applyToolWiring(tool, options));
  const proxyEnv = applyProxyEnvironmentForTools(tools, options);
  const git = options.noGitHook ? { ok: true, skipped: true, changed: false } : installGitFallback(options);
  return {
    ok: !results.some((item) => item.ok === false) && proxyEnv.ok !== false,
    tools: results,
    proxyEnv,
    git,
    detectedCount: results.filter((item) => item.detected).length,
    changedCount: results.filter((item) => item.changed).length + (proxyEnv.changed ? 1 : 0) + (git.changed ? 1 : 0)
  };
}

function printAutoWiringResult(result, io = {}) {
  const out = io.stdout || process.stdout;
  const write = (line = "") => out.write(`${line}\n`);
  write("Coding tool auto-wiring");
  if (result.skipped && result.reason === "agent_inactive") {
    write(`  Skipped: ${result.message || "G.A.I.N Agent is disabled locally."}`);
    return;
  }
  if (!result.detectedCount) {
    write("  No supported coding tools were detected. Proxy environment and git fallback were still checked.");
  }
  for (const tool of result.tools.filter((item) => item.detected)) {
    write(`  ${tool.name}: ${tool.changed ? "wired" : "checked"}`);
    if (tool.configPath) write(`    Config: ${tool.configPath}`);
    if (tool.detectedBy) write(`    Detected by: ${tool.detectedBy}`);
    write(`    Mechanisms: ${tool.mechanisms.join(", ")}`);
    if (tool.backupPath) write(`    Backup: ${tool.backupPath}`);
    if (tool.created) write("    Created config file.");
    if (tool.added && tool.added.length) write(`    Added: ${tool.added.join(", ")}`);
    if (tool.reason) write(`    Note: ${tool.reason}`);
    if (tool.notes) write(`    Limit: ${tool.notes}`);
    if (tool.error) write(`    Error: ${tool.error}`);
    if (tool.id === "claude-code" && tool.changed) write("    Restart Claude Code for the hook to take effect.");
  }
  if (result.proxyEnv && result.proxyEnv.ok !== false && !result.proxyEnv.skipped) {
    write(`  Proxy env: set ${PROXY_ENV_VARS.join(", ")} to ${result.proxyEnv.url || PROXY_URL}. Restart terminals for persistent env changes.`);
  } else if (result.proxyEnv && result.proxyEnv.error) {
    write(`  Proxy env error: ${result.proxyEnv.error}`);
  }
  if (result.git && result.git.ok) {
    write(result.git.skipped ? "  Git fallback: skipped." : `  Git fallback: ${result.git.added ? result.git.added.join(", ") : "checked"}`);
  } else if (result.git && result.git.error) {
    write(`  Git fallback warning: ${result.git.error}`);
  }
  write("");
  write("Run `gain-agent status` to see which detected tools are active. Redact via proxy is active only when a tool routes to a reachable local proxy.");
}

function readToolConfig(tool) {
  try {
    if (tool.configType === "claude" || tool.configType === "json-mcp") return readJsonFile(tool.configPath);
    if (tool.configType === "toml") return fs.existsSync(tool.configPath) ? fs.readFileSync(tool.configPath, "utf8") : "";
  } catch (_error) {}
  return null;
}

function hasMcpConfigured(tool) {
  const config = readToolConfig(tool);
  if (tool.configType === "toml") return tomlBlockIsCurrent(String(config || ""));
  return isPlainObject(config) && isPlainObject(config.mcpServers) && isPlainObject(config.mcpServers.gain) && config.mcpServers.gain.command === "gain-agent";
}

function configuredClaudeHookEvents(tool) {
  const config = readToolConfig(tool);
  if (!isPlainObject(config)) return [];
  return CLAUDE_HOOK_EVENTS.filter((eventName) => {
    const entries = config.hooks && config.hooks[eventName];
    return Array.isArray(entries) && entries.some((entry) => Array.isArray(entry.hooks) && entry.hooks.some((hook) => hook && hook.type === "command" && isGainClaudeHookCommand(hook.command)));
  });
}

// Wiring drift guard: auto-update refreshes the agent binary but never
// re-runs `integrations --apply`, so if a required hook event is added to
// CLAUDE_HOOK_EVENTS after a user already wired an older set, their settings
// end up PARTIALLY configured (some events present, some missing) with no
// visible warning -- `hasClaudeHookConfigured()` alone just silently reports
// "off". This distinguishes that drift case from "never configured at all"
// so doctor can flag it specifically.
function missingClaudeHookEvents(tool) {
  const configuredEvents = configuredClaudeHookEvents(tool);
  return CLAUDE_HOOK_EVENTS.filter((eventName) => !configuredEvents.includes(eventName));
}

function hasClaudeHookConfigured(tool) {
  return missingClaudeHookEvents(tool).length === 0;
}

function gitFallbackStatus(options = {}) {
  try {
    const { currentGlobalHooksPath, globalHooksDir, globalPreCommitPath } = require("../hooks/gitHook");
    const homeDir = homeDirFromOptions(options);
    const current = currentGlobalHooksPath(options.execFile || execFileSync);
    const active = current && path.resolve(homeDir, current) === path.resolve(globalHooksDir(homeDir)) && fs.existsSync(globalPreCommitPath(homeDir));
    return { configured: Boolean(active), active: Boolean(active) };
  } catch (_error) {
    return { configured: false, active: false };
  }
}

function routedEnvForTool(tool, env = process.env) {
  return (tool.proxyEnv || []).filter((name) => parseLoopbackProxyUrl(env[name]));
}

async function proxyActiveForTool(tool, options = {}) {
  const env = options.env || process.env;
  const routed = routedEnvForTool(tool, env);
  if (!routed.length) return { configured: false, active: false, env: [] };
  for (const name of routed) {
    const target = parseLoopbackProxyUrl(env[name]);
    if (!target) continue;
    const probe = options.probe || probeProxyPort;
    try {
      if (await probe(target.host, target.port, options.timeoutMs || 250)) {
        return { configured: true, active: true, env: routed };
      }
    } catch (_error) {}
  }
  return { configured: true, active: false, env: routed };
}

async function getIntegrationStatus(options = {}) {
  const tools = detectInstalledTools(options);
  const git = gitFallbackStatus(options);
  const activeAllowed = !agentInactive(options) && options.agentActive !== false;
  const rows = [];
  for (const tool of tools) {
    const mechanisms = [];
    if (tool.proxyEnv && tool.proxyEnv.length) {
      const proxy = await proxyActiveForTool(tool, options);
      mechanisms.push({ name: "redact via proxy", configured: proxy.configured, active: activeAllowed && proxy.active, detail: activeAllowed ? (proxy.env.join(", ") || tool.proxyEnv.join(", ")) : "agent disabled locally; wiring ignored" });
    }
    if (tool.nativeHook) {
      const configured = tool.id === "claude-code" && hasClaudeHookConfigured(tool);
      mechanisms.push({ name: "block via hook", configured, active: activeAllowed && configured, detail: activeAllowed ? "catastrophic secrets always block" : "agent disabled locally; hook no-ops" });
    }
    if (tool.mcp) {
      const configured = hasMcpConfigured(tool);
      mechanisms.push({ name: "MCP", configured, active: activeAllowed && configured, detail: configured ? (activeAllowed ? "gain MCP server configured" : "agent disabled locally; MCP telemetry ignored") : "not configured" });
    }
    if (tool.gitFallback) {
      mechanisms.push({ name: "git", configured: git.configured, active: activeAllowed && git.active, detail: activeAllowed ? "pre-commit fallback" : "agent disabled locally; hook no-ops" });
    }
    rows.push({
      id: tool.id,
      name: tool.name,
      detected: tool.detected,
      detected_by: tool.detectedBy,
      mechanisms,
      active: mechanisms.some((m) => m.active),
      notes: tool.notes || null
    });
  }
  return {
    generated_at: new Date().toISOString(),
    agent_active: activeAllowed,
    proxy_url: PROXY_URL,
    tools: rows
  };
}

module.exports = {
  CLAUDE_HOOK_COMMAND,
  GAIN_MCP,
  PROXY_ENV_VARS,
  applyAutoWiring,
  applyToolWiring,
  bashCommandPath,
  claudeHookCommand,
  configuredClaudeHookEvents,
  detectInstalledTools,
  getIntegrationStatus,
  missingClaudeHookEvents,
  normalizeToolFilter,
  printAutoWiringResult,
  toolDefinitions,
  toolPaths,
  wireClaudeSettings,
  wireCodexToml,
  wireJsonMcpConfig
};
