"use strict";

// G.A.I.N. MCP server: exposes the agent's local detection + redaction engine
// as Model Context Protocol tools, so any MCP client (Claude Desktop, Claude
// Code, other agents) can scrub or scan text before it leaves the machine.
//
// Dependency-free: hand-rolled JSON-RPC 2.0 over newline-delimited stdio (the MCP
// stdio transport). handleMessage() is pure and side-effect-free so it can be
// unit-tested; start() wires it to stdin/stdout and does best-effort metadata
// reporting (surface: "mcp") via the local queue. Content is never reported.

const readline = require("readline");
const { detectSensitivePatterns } = require("../scanners/patterns");
const { redactSensitiveText } = require("../scanners/redact");

const PROTOCOL_VERSION = "2024-11-05";
let serverVersion = "0.0.0";
try { serverVersion = require("../../package.json").version; } catch (_error) { /* keep default */ }

const TOOLS = [
  {
    name: "redact_text",
    description: "Redact secrets, credentials, PII, and payment-card numbers from text locally and return the safe text. Call this before sending text to any external service or model.",
    inputSchema: {
      type: "object",
      properties: { text: { type: "string", description: "The text to redact." } },
      required: ["text"]
    }
  },
  {
    name: "scan_text",
    description: "Detect sensitive data in text WITHOUT modifying it. Returns the types and counts of sensitive patterns found. Never the values themselves.",
    inputSchema: {
      type: "object",
      properties: { text: { type: "string", description: "The text to scan." } },
      required: ["text"]
    }
  }
];

function ok(id, result) {
  return { jsonrpc: "2.0", id, result };
}

function fail(id, code, message) {
  return { jsonrpc: "2.0", id, error: { code, message } };
}

function textContent(text) {
  return { content: [{ type: "text", text }] };
}

function runTool(name, args) {
  const text = String((args && args.text) || "");
  if (name === "redact_text") {
    const result = redactSensitiveText(text, detectSensitivePatterns(text));
    return textContent(result.text);
  }
  if (name === "scan_text") {
    const patterns = detectSensitivePatterns(text).map((p) => ({ type: p.type, count: p.count, risk: p.risk }));
    return textContent(JSON.stringify({ found: patterns.length > 0, patterns }, null, 2));
  }
  return null; // unknown tool
}

// Pure dispatch. Returns a JSON-RPC response object, or null for notifications
// (messages without an id) which must not be answered.
function handleMessage(message) {
  if (!message || typeof message !== "object") return null;
  const { id, method, params } = message;
  const isNotification = id === undefined || id === null;

  switch (method) {
    case "initialize":
      return ok(id, {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: { tools: {} },
        serverInfo: { name: "gain-agent", version: serverVersion }
      });
    case "ping":
      return ok(id, {});
    case "tools/list":
      return ok(id, { tools: TOOLS });
    case "tools/call": {
      const name = params && params.name;
      const result = runTool(name, params && params.arguments);
      if (!result) return fail(id, -32602, `Unknown tool: ${name}`);
      return ok(id, result);
    }
    default:
      if (isNotification) return null; // e.g. notifications/initialized
      return fail(id, -32601, `Method not found: ${method}`);
  }
}

// Best-effort, metadata-only visibility for an MCP tool call. Never throws into
// the request path; content is never recorded. Only pattern types/counts.
function reportToolCall(params) {
  const name = params && params.name;
  const text = String((params && params.arguments && params.arguments.text) || "");
  if (!text) return;
  const patterns = detectSensitivePatterns(text);
  if (!patterns.length) return;
  // Required lazily so unit tests of handleMessage stay free of config/fs.
  const localQueue = require("../reporters/localQueue");
  const { loadConfig } = require("../config/loadPolicy");
  const config = loadConfig();
  if (config.active === false) return;
  localQueue.enqueue({
    surface: "mcp",
    event_type: "mcp_tool_call",
    domain: "agent.mcp",
    tool_name: "G.A.I.N MCP",
    category: "developer_workflow",
    action: name === "redact_text" ? "redacted" : "logged",
    enforcement_action: name === "redact_text" ? "redacted" : "log_only",
    content_length: text.length,
    patterns_detected: patterns,
    device_id: config.device_id,
    created_at: new Date().toISOString()
  });
}

function start() {
  const rl = readline.createInterface({ input: process.stdin, terminal: false });
  process.stderr.write(`[G.A.I.N] MCP server ready (protocol ${PROTOCOL_VERSION}). Tools: ${TOOLS.map((t) => t.name).join(", ")}.\n`);
  rl.on("line", (line) => {
    const trimmed = line.trim();
    if (!trimmed) return;
    let message;
    try { message = JSON.parse(trimmed); } catch (_error) { return; }
    const response = handleMessage(message);
    if (response) process.stdout.write(`${JSON.stringify(response)}\n`);
    if (message && message.method === "tools/call") {
      try { reportToolCall(message.params); } catch (_error) { /* visibility is best-effort */ }
    }
  });
}

module.exports = { handleMessage, reportToolCall, runTool, start, TOOLS, PROTOCOL_VERSION };
