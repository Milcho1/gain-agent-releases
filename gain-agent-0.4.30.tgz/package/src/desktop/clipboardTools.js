"use strict";

const { spawnSync } = require("child_process");

function commandExists(command) {
  const checker = process.platform === "win32" ? "where" : "command";
  const args = process.platform === "win32" ? [command] : ["-v", command];
  const result = spawnSync(checker, args, { stdio: "ignore", shell: process.platform !== "win32" });
  return !result.error && result.status === 0;
}

function run(command, args, options = {}) {
  return spawnSync(command, args, {
    input: options.input,
    encoding: "utf8",
    maxBuffer: 8 * 1024 * 1024,
    windowsHide: true
  });
}

function powershellClipboard() {
  const command = commandExists("powershell.exe") ? "powershell.exe" : (commandExists("powershell") ? "powershell" : null);
  if (!command) return null;
  return {
    name: "powershell",
    readText() {
      const result = run(command, ["-NoProfile", "-Command", "Get-Clipboard -Raw"]);
      if (result.error || result.status !== 0) return "";
      return String(result.stdout || "");
    },
    writeText(text) {
      const result = run(command, ["-NoProfile", "-Command", "$input | Set-Clipboard"], { input: String(text || "") });
      return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
    }
  };
}

function macClipboard() {
  if (!commandExists("pbpaste") || !commandExists("pbcopy")) return null;
  return {
    name: "pbpaste/pbcopy",
    readText() {
      const result = run("pbpaste", []);
      if (result.error || result.status !== 0) return "";
      return String(result.stdout || "");
    },
    writeText(text) {
      const result = run("pbcopy", [], { input: String(text || "") });
      return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
    }
  };
}

function linuxClipboard() {
  if (commandExists("wl-paste") && commandExists("wl-copy")) {
    return {
      name: "wl-paste/wl-copy",
      readText() {
        const result = run("wl-paste", ["-n"]);
        if (result.error || result.status !== 0) return "";
        return String(result.stdout || "");
      },
      writeText(text) {
        const result = run("wl-copy", [], { input: String(text || "") });
        return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
      }
    };
  }
  if (commandExists("xclip")) {
    return {
      name: "xclip",
      readText() {
        const result = run("xclip", ["-selection", "clipboard", "-o"]);
        if (result.error || result.status !== 0) return "";
        return String(result.stdout || "");
      },
      writeText(text) {
        const result = run("xclip", ["-selection", "clipboard"], { input: String(text || "") });
        return { ok: !result.error && result.status === 0, error: result.error ? result.error.message : String(result.stderr || "").trim() };
      }
    };
  }
  return null;
}

function getClipboardAdapter(platform = process.platform) {
  if (platform === "win32") return powershellClipboard();
  if (platform === "darwin") return macClipboard();
  return linuxClipboard();
}

module.exports = {
  commandExists,
  getClipboardAdapter
};
