"use strict";

const { spawnSync } = require("child_process");
const { commandExists } = require("./clipboardTools");

function notify(message, options = {}) {
  const title = options.title || "G.A.I.N";
  const platform = options.platform || process.platform;
  const text = String(message || "");
  if (!text) return { ok: false, reason: "empty_message" };

  if (platform === "win32") {
    const escapedTitle = title.replace(/'/g, "''");
    const escapedText = text.replace(/'/g, "''");
    const script = `
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$n = New-Object System.Windows.Forms.NotifyIcon
$n.Icon = [System.Drawing.SystemIcons]::Information
$n.BalloonTipTitle = '${escapedTitle}'
$n.BalloonTipText = '${escapedText}'
$n.Visible = $true
$n.ShowBalloonTip(4000)
Start-Sleep -Milliseconds 800
$n.Dispose()
`;
    const result = spawnSync("powershell.exe", ["-NoProfile", "-Command", script], { stdio: "ignore", windowsHide: true });
    return { ok: !result.error && result.status === 0 };
  }

  if (platform === "darwin" && commandExists("osascript")) {
    const script = `display notification ${JSON.stringify(text)} with title ${JSON.stringify(title)}`;
    const result = spawnSync("osascript", ["-e", script], { stdio: "ignore" });
    return { ok: !result.error && result.status === 0 };
  }

  if (commandExists("notify-send")) {
    const result = spawnSync("notify-send", [title, text], { stdio: "ignore" });
    return { ok: !result.error && result.status === 0 };
  }

  return { ok: false, reason: "notification_unavailable" };
}

module.exports = { notify };
