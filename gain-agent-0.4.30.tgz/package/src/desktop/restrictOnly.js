"use strict";

const { spawn } = require("child_process");
const { loadConfig } = require("../config/loadPolicy");
const { getOrgPolicyBundle } = require("../config/orgPolicyCache");
const { decideAccess } = require("../policies/accessControl");
const localQueue = require("../reporters/localQueue");
const { sendEvent, isConfigured } = require("../reporters/supabaseEdgeClient");
const { sendSiemEvent } = require("../reporters/siem");

const KNOWN_DESKTOP_AI_TOOLS = [
  { app: "chatgpt", aliases: ["chatgpt", "openai"], domain: "chatgpt.com", name: "ChatGPT Desktop" },
  { app: "claude", aliases: ["claude", "anthropic"], domain: "claude.ai", name: "Claude Desktop" },
  { app: "copilot", aliases: ["copilot", "microsoft copilot"], domain: "copilot.microsoft.com", name: "Microsoft Copilot Desktop" },
  { app: "perplexity", aliases: ["perplexity"], domain: "perplexity.ai", name: "Perplexity Desktop" },
  { app: "gemini", aliases: ["gemini", "google gemini"], domain: "gemini.google.com", name: "Gemini Desktop" },
  { app: "cursor", aliases: ["cursor"], domain: "cursor.com", name: "Cursor" }
];

function normalizeToken(value) {
  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/^https?:\/\//, "")
    .split(/[/?#]/)[0]
    .replace(/^www\./, "")
    .replace(/\.(exe|app)$/i, "");
}

function knownToolFor(appName, domain) {
  const app = normalizeToken(appName);
  const host = normalizeToken(domain);
  return KNOWN_DESKTOP_AI_TOOLS.find((tool) => {
    if (host && (host === tool.domain || host.endsWith(`.${tool.domain}`))) return true;
    return tool.aliases.some((alias) => app === alias || app.includes(alias));
  }) || null;
}

function normalizeDesktopTarget({ appName, domain } = {}) {
  const known = knownToolFor(appName, domain);
  const normalizedDomain = normalizeToken(domain) || known?.domain || "desktop.local";
  const normalizedName = String(appName || known?.name || normalizedDomain || "Desktop AI app").trim();
  return {
    appName: normalizedName,
    domain: normalizedDomain,
    knownTool: known
  };
}

function buildDesktopEvent(config, target, access) {
  return {
    surface: "desktop_app",
    event_type: "desktop_access",
    domain: target.domain,
    tool_name: target.appName,
    category: "desktop_app",
    action: access.allowed ? "allow" : "block",
    enforcement_action: access.allowed ? "allowed" : "blocked",
    severity: access.allowed ? "info" : "high",
    content_length: 0,
    char_count: 0,
    patterns_detected: [],
    policy_triggered: access.policy_triggered,
    detection_reason: access.reason,
    is_approved_tool: access.is_approved_tool,
    tool_status: access.status,
    device_id: config.device_id,
    created_at: new Date().toISOString()
  };
}

async function reportDesktopEvent(config, event, options = {}) {
  if (options.reporter) return options.reporter(event);
  if (options.noReport) return { ok: true, skipped: true, reason: "no-report flag" };
  localQueue.enqueue(event);
  if (isConfigured(config)) {
    const sent = await sendEvent(config, event);
    if (sent.ok) {
      const remaining = localQueue.readAll();
      remaining.pop();
      localQueue.rewrite(remaining);
    }
  }
  await sendSiemEvent(config, event);
  return { ok: true };
}

async function resolvePolicyBundle(config, injectedBundle) {
  if (injectedBundle !== undefined) {
    return injectedBundle ? { ok: true, source: "test", policy_bundle: injectedBundle } : { ok: false, source: "none" };
  }
  return getOrgPolicyBundle(config);
}

async function checkDesktopAccess(input = {}, options = {}) {
  const config = options.config || loadConfig();
  const target = normalizeDesktopTarget(input);
  const policyResult = await resolvePolicyBundle(config, options.orgPolicyBundle);
  const access = decideAccess({
    toolName: target.appName,
    domain: target.domain,
    config,
    orgPolicyBundle: policyResult.ok ? policyResult.policy_bundle : null
  });
  const event = buildDesktopEvent(config, target, access);
  await reportDesktopEvent(config, event, options);

  return {
    allowed: access.allowed,
    action: access.action,
    status: access.status,
    policy_triggered: access.policy_triggered,
    reason: access.reason,
    target,
    event
  };
}

async function guardDesktopLaunch(input = {}, options = {}) {
  const result = await checkDesktopAccess(input, options);
  if (!result.allowed) return { ...result, launched: false };

  const command = input.command || input.execPath;
  if (!command) return { ...result, launched: false };
  const launcher = options.launcher || ((cmd) => spawn(cmd, [], { detached: true, stdio: "ignore" }).unref());
  launcher(command);
  return { ...result, launched: true };
}

module.exports = {
  KNOWN_DESKTOP_AI_TOOLS,
  normalizeDesktopTarget,
  buildDesktopEvent,
  reportDesktopEvent,
  checkDesktopAccess,
  guardDesktopLaunch
};
