"use strict";

const crypto = require("crypto");
const { loadConfig } = require("../config/loadPolicy");
const { getOrgPolicyBundle } = require("../config/orgPolicyCache");
const { detectSensitivePatterns } = require("../scanners/patterns");
const { redactSensitiveText } = require("../scanners/redact");
const { decide } = require("../policies/decisionEngine");
const { patternSummary } = require("../ui/messages");
const { getClipboardAdapter } = require("./clipboardTools");
const { getForegroundApp } = require("./foregroundApp");
const { notify } = require("./nativeNotify");
const { reportDesktopEvent } = require("./restrictOnly");

const DEFAULT_POLL_MS = 500;

const DEFAULT_MONITORED_APPS = [
  {
    name: "Claude Desktop",
    domain: "claude.ai",
    aliases: ["claude", "claude desktop", "anthropicclaude"],
    pathHints: ["anthropicclaude/claude.exe", "anthropicclaude\\claude.exe", "claude.exe", "/claude.app"]
  },
  {
    name: "ChatGPT Desktop",
    domain: "chatgpt.com",
    aliases: ["chatgpt", "chatgpt desktop"],
    pathHints: ["chatgpt.exe", "/chatgpt.app"]
  }
];

function normalize(value) {
  return String(value || "").toLowerCase().trim().replace(/\\/g, "/");
}

function hashText(text) {
  return crypto.createHash("sha256").update(String(text || "")).digest("hex");
}

function createDesktopGuardState() {
  return {
    lastProcessedHash: null,
    lastProcessedAt: 0,
    lastWrittenHash: null
  };
}

function monitoredAppsFromConfig(config = {}) {
  const configured = Array.isArray(config.desktop_guard_apps) ? config.desktop_guard_apps : [];
  if (!configured.length) return DEFAULT_MONITORED_APPS.map((app) => ({ ...app, aliases: [...app.aliases], pathHints: [...app.pathHints] }));
  return configured.map((item) => {
    if (item && typeof item === "object") {
      return {
        name: item.name || item.app || item.domain || "Desktop AI app",
        domain: item.domain || "desktop.local",
        aliases: Array.isArray(item.aliases) ? item.aliases : [item.name, item.app, item.domain].filter(Boolean),
        pathHints: Array.isArray(item.pathHints) ? item.pathHints : [item.path, item.exec].filter(Boolean)
      };
    }
    const value = String(item || "").trim();
    return {
      name: value,
      domain: value.includes(".") ? value : "desktop.local",
      aliases: [value],
      pathHints: [value]
    };
  });
}

function resolveMonitoredApp(foregroundApp, config = {}) {
  if (!foregroundApp) return null;
  const name = normalize(foregroundApp.name);
  const processName = normalize(foregroundApp.processName);
  const appPath = normalize(foregroundApp.path);
  const haystack = [name, processName, appPath].filter(Boolean).join(" ");

  for (const app of monitoredAppsFromConfig(config)) {
    const aliases = (app.aliases || []).map(normalize).filter(Boolean);
    const pathHints = (app.pathHints || []).map(normalize).filter(Boolean);
    const aliasMatch = aliases.some((alias) => name === alias || processName === alias || haystack.includes(alias));
    const pathMatch = pathHints.some((hint) => appPath && appPath.includes(hint));
    if (aliasMatch || pathMatch) {
      return {
        name: app.name || foregroundApp.name || "Desktop AI app",
        domain: app.domain || "desktop.local",
        foreground: foregroundApp
      };
    }
  }
  return null;
}

function metadataPatterns(patterns = []) {
  return (patterns || []).map((pattern) => ({
    type: pattern.type,
    count: Number(pattern.count || 1),
    risk: pattern.risk || "info"
  }));
}

function buildClipboardEvent(config, target, decision, patterns, textLength, policyResult) {
  return {
    surface: "desktop_app",
    event_type: "desktop_clipboard",
    domain: target.domain,
    tool_name: target.name,
    category: "desktop_app",
    action: decision.action,
    enforcement_action: decision.action,
    severity: decision.severity,
    content_length: textLength,
    char_count: textLength,
    patterns_detected: metadataPatterns(patterns),
    policy_triggered: decision.policy_triggered,
    detection_reason: `${decision.reason} Clipboard matched while ${target.name} was foreground.`,
    policy_bundle_version: policyResult?.policy_bundle?.bundle_version || null,
    policy_source: policyResult?.source || "local",
    device_id: config.device_id,
    created_at: new Date().toISOString()
  };
}

function shouldSkipClipboard(state, text) {
  const hash = hashText(text);
  if (state.lastWrittenHash && hash === state.lastWrittenHash) {
    return { skip: true, reason: "self_written_clipboard", hash };
  }
  if (state.lastProcessedHash === hash) {
    return { skip: true, reason: "unchanged_clipboard", hash };
  }
  return { skip: false, hash };
}

async function resolvePolicyBundle(config, injectedBundle) {
  if (injectedBundle !== undefined) {
    return injectedBundle ? { ok: true, source: "test", policy_bundle: injectedBundle } : { ok: false, source: "none" };
  }
  return getOrgPolicyBundle(config);
}

async function runDesktopGuardIteration(options = {}) {
  const state = options.state || createDesktopGuardState();
  const now = Number(options.now || Date.now());
  const config = options.config || loadConfig();
  if (config.active === false) return { action: "skip", reason: "inactive" };
  if (config.desktop_guard_enabled === false) return { action: "skip", reason: "disabled" };

  const foreground = options.foregroundApp !== undefined ? options.foregroundApp : getForegroundApp(options.platform);
  const target = resolveMonitoredApp(foreground, config);
  if (!target) return { action: "skip", reason: "unmonitored_app", foreground };

  const adapter = options.clipboard || getClipboardAdapter(options.platform);
  if (!adapter || typeof adapter.readText !== "function" || typeof adapter.writeText !== "function") {
    return { action: "skip", reason: "clipboard_unavailable", target };
  }

  const text = String(adapter.readText() || "");
  if (!text) return { action: "skip", reason: "empty_clipboard", target };

  const skip = shouldSkipClipboard(state, text);
  if (skip.skip) return { action: "skip", reason: skip.reason, target };

  const patterns = detectSensitivePatterns(text);
  if (!patterns.length) {
    state.lastProcessedHash = skip.hash;
    state.lastProcessedAt = now;
    return { action: "allow", reason: "clean_clipboard", target };
  }

  const policyResult = await resolvePolicyBundle(config, options.orgPolicyBundle);
  const decision = decide({
    patterns,
    orgPolicyBundle: policyResult.ok ? policyResult.policy_bundle : null,
    enforcementMode: config.enforcement_mode,
    context: { domain: target.domain, toolName: target.name, category: "desktop_app" }
  });

  let writeResult = null;
  let notification = null;
  if (decision.action === "redact") {
    const redacted = redactSensitiveText(text, patterns);
    if (redacted.changed) {
      writeResult = adapter.writeText(redacted.text);
      state.lastWrittenHash = hashText(redacted.text);
    }
  } else if (decision.action === "block") {
    writeResult = adapter.writeText("");
    state.lastWrittenHash = hashText("");
    notification = (options.notify || notify)(`Blocked sensitive data from being pasted into ${target.name}.`, { title: "G.A.I.N", platform: options.platform });
  } else if (decision.action === "warn") {
    notification = (options.notify || notify)(`About to paste a secret into ${target.name}.`, { title: "G.A.I.N", platform: options.platform });
  }

  state.lastProcessedHash = skip.hash;
  state.lastProcessedAt = now;

  const event = buildClipboardEvent(config, target, decision, patterns, text.length, policyResult);
  await reportDesktopEvent(config, event, { reporter: options.reporter, noReport: options.noReport });

  return {
    action: decision.action,
    decision,
    target,
    patterns: metadataPatterns(patterns),
    event,
    writeResult,
    notification,
    summary: patternSummary(patterns)
  };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runDesktopGuard(options = {}) {
  const state = options.state || createDesktopGuardState();
  const intervalMs = Math.max(100, Number(options.intervalMs || DEFAULT_POLL_MS));
  const stdout = options.stdout || process.stdout;
  const stderr = options.stderr || process.stderr;
  const adapter = options.clipboard || getClipboardAdapter(options.platform);

  if (!adapter) {
    stdout.write("G.A.I.N desktop guard skipped: no supported clipboard tool found on this system.\n");
    return { ok: false, reason: "clipboard_unavailable" };
  }

  stdout.write(`G.A.I.N desktop guard running. Clipboard is checked only while a monitored desktop AI app is foreground. Polling every ${intervalMs}ms.\n`);
  while (!options.signal || !options.signal.aborted) {
    try {
      const config = loadConfig();
      if (config.desktop_guard_enabled === false || config.active === false) {
        stdout.write("G.A.I.N desktop guard stopped by local config.\n");
        return { ok: true, stopped: true };
      }
      await runDesktopGuardIteration({ ...options, state, config, clipboard: adapter });
    } catch (error) {
      stderr.write(`G.A.I.N desktop guard warning: ${error.message}\n`);
    }
    if (options.once) break;
    await sleep(intervalMs);
  }
  return { ok: true };
}

module.exports = {
  DEFAULT_MONITORED_APPS,
  DEFAULT_POLL_MS,
  buildClipboardEvent,
  createDesktopGuardState,
  hashText,
  metadataPatterns,
  monitoredAppsFromConfig,
  resolveMonitoredApp,
  runDesktopGuard,
  runDesktopGuardIteration,
  shouldSkipClipboard
};
