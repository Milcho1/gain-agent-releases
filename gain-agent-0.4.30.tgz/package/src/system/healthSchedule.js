"use strict";

const os = require("os");
const path = require("path");
const fs = require("fs");
const { execFileSync } = require("child_process");
const { configDir } = require("../config/loadPolicy");

const TASKS = [
  {
    name: "G.A.I.N Agent Presence",
    command: "presence",
    args: ["/SC", "MINUTE", "/MO", "5"],
    description: "lightweight online presence every 5 minutes"
  },
  {
    name: "G.A.I.N Agent Heartbeat",
    command: "sync",
    args: ["/SC", "HOURLY", "/MO", "1"],
    description: "policy sync and deployment heartbeat every hour"
  },
  {
    name: "G.A.I.N Agent Desktop Guard",
    command: "desktop-guard",
    args: ["/SC", "ONLOGON"],
    description: "desktop AI clipboard guard at user logon"
  }
];

const UPDATE_TASKS = [
  {
    name: "G.A.I.N Agent Update",
    command: "update --scheduled",
    args: ["/SC", "DAILY", "/ST", "03:15"],
    description: "daily checksum-verified update check"
  }
];

function defaultCliPath() {
  return process.pkg ? "" : path.resolve(__dirname, "..", "cli", "index.js");
}

function commandLine(nodePath, cliPath, command) {
  const executable = shellQuoteForCommand(nodePath);
  if (!cliPath) return `${executable} ${command}`;
  return `${executable} ${shellQuoteForCommand(cliPath)} ${command}`;
}

function hiddenRunnerPath() {
  return path.join(configDir(), "run-hidden.vbs");
}

function writeWindowsHiddenRunner({ nodePath, cliPath, runnerPath = hiddenRunnerPath() } = {}) {
  fs.mkdirSync(path.dirname(runnerPath), { recursive: true });
  const script = [
    "Option Explicit",
    "Dim shell, args, commandLine, i, arg",
    "Set shell = CreateObject(\"WScript.Shell\")",
    "Set args = WScript.Arguments",
    "If args.Count < 1 Then WScript.Quit 1",
    cliPath
      ? `commandLine = Chr(34) & "${escapeVbs(nodePath)}" & Chr(34) & " " & Chr(34) & "${escapeVbs(cliPath)}" & Chr(34)`
      : `commandLine = Chr(34) & "${escapeVbs(nodePath)}" & Chr(34)`,
    "For i = 0 To args.Count - 1",
    "  arg = Replace(args.Item(i), Chr(34), Chr(34) & Chr(34))",
    "  commandLine = commandLine & \" \" & Chr(34) & arg & Chr(34)",
    "Next",
    "shell.Run commandLine, 0, False"
  ].join("\r\n");
  fs.writeFileSync(runnerPath, script, "utf8");
  return runnerPath;
}

function taskRunCommand(nodePath, cliPath, command, options = {}) {
  if (options.hiddenRunnerPath) {
    return `"wscript.exe" "${options.hiddenRunnerPath}" ${command}`;
  }
  return commandLine(nodePath, cliPath, command);
}

function windowsCreateTaskArgs(task, { nodePath, cliPath, hiddenRunnerPath: runnerPath }) {
  return [
    "/Create",
    "/TN", task.name,
    ...task.args,
    "/TR", taskRunCommand(nodePath, cliPath, task.command, { hiddenRunnerPath: runnerPath }),
    "/F"
  ];
}

function windowsDeleteTaskArgs(task) {
  return ["/Delete", "/TN", task.name, "/F"];
}

function windowsQueryTaskArgs(task) {
  return ["/Query", "/TN", task.name, "/V", "/FO", "LIST"];
}

function taskAlreadyInstalled(task, { hiddenRunnerPath: runnerPath, execFileSync: runner = execFileSync } = {}) {
  try {
    const output = String(runner("schtasks", windowsQueryTaskArgs(task), { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }) || "");
    return output.includes("run-hidden.vbs") && output.includes(task.command) &&
      (!runnerPath || output.includes(runnerPath));
  } catch (_error) {
    return false;
  }
}

function manualScheduleInstructions({ nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const commandPrefix = commandLine(nodePath, cliPath, "");
  return [
    "Automatic health scheduling is installed directly on Windows.",
    "For macOS/Linux, add these user cron entries or deploy the equivalent with your MDM:",
    "",
    `*/5 * * * * ${commandPrefix}presence >/tmp/gain-agent-presence.log 2>&1`,
    `0 * * * * ${commandPrefix}sync >/tmp/gain-agent-heartbeat.log 2>&1`,
    `@reboot ${commandPrefix}desktop-guard >/tmp/gain-agent-desktop-guard.log 2>&1`,
    "",
    `Config is read from ${path.join(os.homedir(), ".gain", "config.json")} unless GAIN_CONFIG_DIR is set.`
  ].join("\n");
}

function installHealthSchedule(options = {}) {
  return installWindowsOrManualTasks(TASKS, options, "presence/heartbeat");
}

function installDesktopGuardSchedule(options = {}) {
  return installWindowsOrManualTasks([TASKS[2]], options, "desktop-guard");
}

function installAutoUpdateSchedule(options = {}) {
  return installWindowsOrManualTasks(UPDATE_TASKS, options, "auto-update");
}

function installWindowsOrManualTasks(tasks, options = {}, purpose = "schedule") {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;
  const nodePath = options.nodePath || process.execPath;
  const cliPath = options.cliPath !== undefined ? options.cliPath : defaultCliPath();

  if (platform !== "win32") {
    return {
      ok: true,
      installed: false,
      manual: true,
      instructions: purpose === "auto-update"
        ? autoUpdateManualScheduleInstructions({ nodePath, cliPath })
        : manualScheduleInstructions({ nodePath, cliPath })
    };
  }

  const installed = [];
  const errors = [];
  const runnerPath = options.hiddenRunnerPath || writeWindowsHiddenRunner({ nodePath, cliPath });
  for (const task of tasks) {
    try {
      if (taskAlreadyInstalled(task, { hiddenRunnerPath: runnerPath, execFileSync: runner })) {
        installed.push({ name: task.name, description: `${task.description} (already installed)` });
        continue;
      }
      runner("schtasks", windowsCreateTaskArgs(task, { nodePath, cliPath, hiddenRunnerPath: runnerPath }), { stdio: "pipe" });
      installed.push({ name: task.name, description: task.description });
    } catch (error) {
      errors.push({ task: task.name, error: error.message });
    }
  }
  return { ok: errors.length === 0, installed: installed.length > 0, tasks: installed, errors, hiddenRunnerPath: runnerPath, purpose };
}

function autoUpdateManualScheduleInstructions({ nodePath = process.execPath, cliPath = defaultCliPath() } = {}) {
  const commandPrefix = commandLine(nodePath, cliPath, "");
  return [
    "For macOS/Linux, add this user cron entry or deploy the equivalent with your MDM:",
    "",
    `15 3 * * * ${commandPrefix}update --scheduled >/tmp/gain-agent-update.log 2>&1`,
    "",
    `Config is read from ${path.join(os.homedir(), ".gain", "config.json")} unless GAIN_CONFIG_DIR is set.`
  ].join("\n");
}

function uninstallHealthSchedule(options = {}) {
  return uninstallWindowsOrManualTasks(TASKS, options, "Remove the G.A.I.N Agent cron entries for `presence`, `sync`, and `desktop-guard` from the user's crontab or your MDM policy.");
}

function uninstallAutoUpdateSchedule(options = {}) {
  return uninstallWindowsOrManualTasks(UPDATE_TASKS, options, "Remove the G.A.I.N Agent auto-update cron entry from the user's crontab or your MDM policy.");
}

function uninstallDesktopGuardSchedule(options = {}) {
  return uninstallWindowsOrManualTasks([TASKS[2]], options, "Remove the G.A.I.N Agent `desktop-guard` cron entry from the user's crontab or your MDM policy.");
}

function uninstallWindowsOrManualTasks(tasks, options = {}, instructions) {
  const platform = options.platform || process.platform;
  const runner = options.execFileSync || execFileSync;

  if (platform !== "win32") {
    return {
      ok: true,
      removed: false,
      manual: true,
      instructions
    };
  }

  const removed = [];
  const errors = [];
  for (const task of tasks) {
    try {
      runner("schtasks", windowsDeleteTaskArgs(task), { stdio: "pipe" });
      removed.push(task.name);
    } catch (error) {
      errors.push({ task: task.name, error: error.message });
    }
  }
  return { ok: errors.length === 0, removed, errors };
}

function shellQuoteForCommand(value) {
  return `"${String(value || "").replace(/"/g, '\\"')}"`;
}

function escapeVbs(value) {
  return String(value || "").replace(/"/g, "\"\"");
}

module.exports = {
  TASKS,
  UPDATE_TASKS,
  defaultCliPath,
  commandLine,
  hiddenRunnerPath,
  writeWindowsHiddenRunner,
  taskRunCommand,
  windowsCreateTaskArgs,
  windowsDeleteTaskArgs,
  windowsQueryTaskArgs,
  taskAlreadyInstalled,
  manualScheduleInstructions,
  autoUpdateManualScheduleInstructions,
  installHealthSchedule,
  uninstallHealthSchedule,
  installDesktopGuardSchedule,
  uninstallDesktopGuardSchedule,
  installAutoUpdateSchedule,
  uninstallAutoUpdateSchedule
};
