"use strict";

// Loads the agent's own configuration (org key, Supabase target, enforcement mode,
// device id). Sources, lowest to highest precedence:
//   1. built-in defaults
//   2. ~/.gain/config.json
//   3. environment variables (GAIN_*)
// The org key / Supabase keys are connection config, not secrets we detect on.

const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");

const DEFAULT_SUPABASE_URL = "https://ljrvyophvulsjilbrtig.supabase.co";
const DEFAULT_SUPABASE_KEY = "sb_publishable_MJsYZ_nfv8ryJUp0oxDfXQ_XkyP0gIe";
const DEPLOYMENT_MODES = new Set(["hosted", "self_hosted"]);

function configDir() {
  return process.env.GAIN_CONFIG_DIR || path.join(os.homedir(), ".gain");
}

function configPath() {
  return path.join(configDir(), "config.json");
}

function readConfigFile() {
  try {
    return JSON.parse(fs.readFileSync(configPath(), "utf8"));
  } catch (_error) {
    return {};
  }
}

function writeConfigFile(config) {
  const dir = configDir();
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify(config, null, 2));
}

function ensureDeviceId(fileConfig) {
  if (fileConfig.device_id) return fileConfig.device_id;
  const deviceId = `agent-${crypto.randomUUID()}`;
  writeConfigFile({ ...fileConfig, device_id: deviceId });
  return deviceId;
}

function readBoolean(value, fallback) {
  if (value === undefined || value === null || value === "") return fallback;
  const normalized = String(value).toLowerCase().trim();
  if (["true", "1", "yes", "on"].includes(normalized)) return true;
  if (["false", "0", "no", "off"].includes(normalized)) return false;
  return fallback;
}

function readList(value) {
  if (Array.isArray(value)) return value.map((item) => (typeof item === "string" ? item.trim() : item)).filter(Boolean);
  if (typeof value === "string") return value.split(",").map((item) => item.trim()).filter(Boolean);
  return [];
}

function loadConfig() {
  const fileConfig = readConfigFile();
  const deviceId = ensureDeviceId(fileConfig);
  const deploymentMode = DEPLOYMENT_MODES.has(process.env.GAIN_DEPLOYMENT_MODE)
    ? process.env.GAIN_DEPLOYMENT_MODE
    : (DEPLOYMENT_MODES.has(fileConfig.deployment_mode) ? fileConfig.deployment_mode : "hosted");
  const telemetryDefault = deploymentMode === "self_hosted" ? false : true;
  const telemetryValue = process.env.GAIN_TELEMETRY_ENABLED ?? fileConfig.telemetry_enabled;

  const config = {
    org_api_key: process.env.GAIN_ORG_API_KEY || fileConfig.org_api_key || null,
    supabase_url: process.env.GAIN_SUPABASE_URL || fileConfig.supabase_url || DEFAULT_SUPABASE_URL,
    supabase_key: process.env.GAIN_SUPABASE_KEY || fileConfig.supabase_key || DEFAULT_SUPABASE_KEY,
    enforcement_mode: process.env.GAIN_ENFORCEMENT_MODE || fileConfig.enforcement_mode || "visibility_only",
    deployment_mode: deploymentMode,
    telemetry_enabled: telemetryValue === undefined
      ? telemetryDefault
      : ["true", "1", "yes"].includes(String(telemetryValue).toLowerCase()),
    disabled_paths: Array.isArray(fileConfig.disabled_paths) ? fileConfig.disabled_paths : [],
    device_label: process.env.GAIN_DEVICE_LABEL || fileConfig.device_label || `${os.hostname()} (agent)`,
    department: process.env.GAIN_DEPARTMENT || fileConfig.department || null,
    siem_webhook_url: process.env.GAIN_SIEM_WEBHOOK_URL || fileConfig.siem_webhook_url || null,
    siem_bearer_token: process.env.GAIN_SIEM_BEARER_TOKEN || fileConfig.siem_bearer_token || null,
    access_mode: process.env.GAIN_ACCESS_MODE || fileConfig.access_mode || "monitor",
    approved_tools: process.env.GAIN_APPROVED_TOOLS || fileConfig.approved_tools || [],
    blocked_tools: process.env.GAIN_BLOCKED_TOOLS || fileConfig.blocked_tools || [],
    auto_update: ["true", "1", "yes"].includes(String(process.env.GAIN_AGENT_AUTO_UPDATE || fileConfig.auto_update || "").toLowerCase()),
    desktop_guard_enabled: readBoolean(process.env.GAIN_DESKTOP_GUARD ?? fileConfig.desktop_guard_enabled, true),
    desktop_guard_apps: readList(process.env.GAIN_DESKTOP_GUARD_APPS || fileConfig.desktop_guard_apps),
    proxy_service_enabled: readBoolean(process.env.GAIN_PROXY_SERVICE_ENABLED ?? fileConfig.proxy_service_enabled, false),
    proxy_service_host: process.env.GAIN_PROXY_HOST || fileConfig.proxy_service_host || "127.0.0.1",
    proxy_service_port: Number(process.env.GAIN_PROXY_PORT || fileConfig.proxy_service_port || 8787),
    proxy_fail_policy: process.env.GAIN_PROXY_FAIL_POLICY || fileConfig.proxy_fail_policy || "fail_closed",
    active: process.env.GAIN_AGENT_ACTIVE === undefined
      ? fileConfig.active !== false
      : ["true", "1", "yes"].includes(String(process.env.GAIN_AGENT_ACTIVE).toLowerCase()),
    inactive_reason: fileConfig.inactive_reason || null,
    device_id: deviceId
  };

  return config;
}

module.exports = { loadConfig, writeConfigFile, readConfigFile, configPath, configDir, DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_KEY, DEPLOYMENT_MODES };
