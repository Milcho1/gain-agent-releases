"use strict";

// Finds and loads a per-project policy file: .gain/policy.json
// Walks up from the scan target to the filesystem root. Example file:
// {
//   "ai_allowed": false,
//   "reason": "Customer source code cannot be shared with AI tools",
//   "action": "block",
//   "report_metadata": true
// }

const fs = require("fs");
const path = require("path");

const POLICY_RELATIVE = path.join(".gain", "policy.json");
const VALID_ACTIONS = new Set(["block", "warn", "redact", "log_only", "allow"]);

function findProjectPolicy(startPath) {
  let dir = path.resolve(startPath);
  try {
    if (fs.statSync(dir).isFile()) dir = path.dirname(dir);
  } catch (_error) {
    return null;
  }

  while (true) {
    const candidate = path.join(dir, POLICY_RELATIVE);
    if (fs.existsSync(candidate)) {
      return loadPolicyFile(candidate, dir);
    }
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

function loadPolicyFile(policyPath, projectRoot) {
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(policyPath, "utf8"));
  } catch (error) {
    return { error: `Invalid .gain/policy.json: ${error.message}`, path: policyPath };
  }

  const policy = {
    ai_allowed: raw.ai_allowed !== false ? (raw.ai_allowed === true ? true : null) : false,
    reason: typeof raw.reason === "string" ? raw.reason : null,
    action: VALID_ACTIONS.has(raw.action) ? raw.action : null,
    report_metadata: raw.report_metadata !== false
  };

  return { policy, path: policyPath, projectRoot };
}

module.exports = { findProjectPolicy, POLICY_RELATIVE, VALID_ACTIONS };
