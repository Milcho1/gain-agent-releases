"use strict";

const fs = require("fs");
const path = require("path");
const { configDir } = require("./loadPolicy");
const { fetchPolicyBundle, isConfigured } = require("../reporters/supabaseEdgeClient");

const CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000;

function cachePath() {
  return path.join(configDir(), "policy-cache.json");
}

function readPolicyCache(now = Date.now()) {
  try {
    const raw = JSON.parse(fs.readFileSync(cachePath(), "utf8"));
    const cachedAt = Number(raw.cached_at_ms || 0);
    const ageMs = cachedAt ? now - cachedAt : Number.POSITIVE_INFINITY;
    if (!raw.policy_bundle || ageMs > CACHE_MAX_AGE_MS) return { ok: false, reason: "stale_or_missing" };
    return { ok: true, source: "cache", ageMs, policy_bundle: raw.policy_bundle };
  } catch (_error) {
    return { ok: false, reason: "missing" };
  }
}

function writePolicyCache(policyBundle) {
  if (!policyBundle || typeof policyBundle !== "object") return false;
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(cachePath(), JSON.stringify({
    cached_at: new Date().toISOString(),
    cached_at_ms: Date.now(),
    bundle_version: policyBundle.bundle_version || null,
    policy_bundle: policyBundle
  }, null, 2));
  return true;
}

async function getOrgPolicyBundle(config, options = {}) {
  const { allowFetch = true } = options;
  if (allowFetch && isConfigured(config)) {
    const live = await fetchPolicyBundle(config);
    if (live.ok && live.policy_bundle) {
      writePolicyCache(live.policy_bundle);
      return { ok: true, source: "live", policy_bundle: live.policy_bundle };
    }
    const cached = readPolicyCache();
    if (cached.ok) return { ...cached, liveError: live.error || live.reason || "fetch_failed" };
    return { ok: false, source: "none", reason: live.error || live.reason || "fetch_failed" };
  }
  return readPolicyCache();
}

module.exports = { cachePath, readPolicyCache, writePolicyCache, getOrgPolicyBundle, CACHE_MAX_AGE_MS };
