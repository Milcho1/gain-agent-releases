"use strict";

const fs = require("fs");
const path = require("path");

function baselinePath(root = process.cwd()) {
  return path.join(path.resolve(root), ".gain", "baseline.json");
}

function normalizeFile(file) {
  return String(file || "").replace(/\\/g, "/").replace(/^\.\//, "");
}

function findingEntries(findings = []) {
  const entries = [];
  for (const finding of findings) {
    for (const pattern of finding.patterns || []) {
      entries.push({
        file: normalizeFile(finding.file),
        type: pattern.type,
        count: pattern.count || 1,
        risk: pattern.risk || "info"
      });
    }
  }
  return entries;
}

function writeBaseline(root, scanResult) {
  const filePath = baselinePath(root);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const baseline = {
    version: 1,
    created_at: new Date().toISOString(),
    root: path.resolve(root),
    entries: findingEntries(scanResult.findings)
  };
  fs.writeFileSync(filePath, JSON.stringify(baseline, null, 2));
  return { path: filePath, baseline };
}

function loadBaseline(root = process.cwd()) {
  const filePath = baselinePath(root);
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (!Array.isArray(parsed.entries)) return null;
    return { path: filePath, baseline: parsed };
  } catch (_error) {
    return null;
  }
}

function baselineMap(baseline) {
  const map = new Map();
  for (const entry of baseline?.entries || []) {
    const key = `${normalizeFile(entry.file)}::${entry.type}`;
    map.set(key, (map.get(key) || 0) + (entry.count || 1));
  }
  return map;
}

function applyBaseline(findings = [], baseline) {
  if (!baseline || !Array.isArray(baseline.entries)) {
    return { findings, suppressed: 0 };
  }
  const allowed = baselineMap(baseline);
  let suppressed = 0;
  const nextFindings = [];

  for (const finding of findings) {
    const nextPatterns = [];
    for (const pattern of finding.patterns || []) {
      const key = `${normalizeFile(finding.file)}::${pattern.type}`;
      const baselineCount = allowed.get(key) || 0;
      const count = pattern.count || 1;
      if (baselineCount >= count) {
        suppressed += count;
        allowed.set(key, baselineCount - count);
        continue;
      }
      if (baselineCount > 0) {
        suppressed += baselineCount;
        allowed.set(key, 0);
        nextPatterns.push({ ...pattern, count: count - baselineCount });
        continue;
      }
      nextPatterns.push(pattern);
    }
    if (nextPatterns.length) nextFindings.push({ ...finding, patterns: nextPatterns });
  }

  return { findings: nextFindings, suppressed };
}

module.exports = {
  baselinePath,
  writeBaseline,
  loadBaseline,
  applyBaseline,
  findingEntries,
  normalizeFile
};
