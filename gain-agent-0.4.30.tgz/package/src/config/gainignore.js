"use strict";

const fs = require("fs");
const path = require("path");

function gainignorePath(root = process.cwd()) {
  return path.join(path.resolve(root), ".gainignore");
}

function normalizePath(value) {
  return String(value || "")
    .replace(/\\/g, "/")
    .replace(/^\.\//, "")
    .replace(/^\/+/, "")
    .replace(/\/+/g, "/");
}

function findRepoRoot(start = process.cwd()) {
  let current = path.resolve(start || process.cwd());
  try {
    const stat = fs.existsSync(current) ? fs.statSync(current) : null;
    if (stat && stat.isFile()) current = path.dirname(current);
  } catch (_error) {
    current = process.cwd();
  }

  while (true) {
    if (fs.existsSync(path.join(current, ".git"))) return current;
    const parent = path.dirname(current);
    if (parent === current) return path.resolve(start || process.cwd());
    current = parent;
  }
}

function loadGainignore(root = process.cwd()) {
  const filePath = gainignorePath(root);
  try {
    const raw = fs.readFileSync(filePath, "utf8");
    const patterns = raw
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#"));
    return { path: filePath, patterns };
  } catch (_error) {
    return null;
  }
}

function isIgnored(relPath, patterns = []) {
  const normalized = normalizePath(relPath);
  if (!normalized || !Array.isArray(patterns) || !patterns.length) return false;
  return patterns.some((pattern) => matchesPattern(normalized, pattern));
}

function matchesPattern(relPath, pattern) {
  const raw = String(pattern || "").trim();
  if (!raw || raw.startsWith("#")) return false;

  const anchored = raw.startsWith("/");
  const dirOnly = raw.endsWith("/");
  const normalizedPattern = normalizePath(raw).replace(/\/+$/, "");
  if (!normalizedPattern) return false;

  const hasSlash = normalizedPattern.includes("/");
  const body = globToRegex(normalizedPattern);
  const prefix = anchored || hasSlash ? "^" : "(?:^|/)";
  const suffix = dirOnly ? "(?:/.*)?$" : "$";
  return new RegExp(`${prefix}${body}${suffix}`).test(relPath);
}

function globToRegex(pattern) {
  let out = "";
  for (let index = 0; index < pattern.length; index += 1) {
    const char = pattern[index];
    if (char === "*") {
      if (pattern[index + 1] === "*") {
        out += ".*";
        index += 1;
      } else {
        out += "[^/]*";
      }
      continue;
    }
    out += escapeRegex(char);
  }
  return out;
}

function escapeRegex(char) {
  return /[|\\{}()[\]^$+?.]/.test(char) ? `\\${char}` : char;
}

module.exports = {
  gainignorePath,
  loadGainignore,
  isIgnored,
  findRepoRoot,
  normalizePath,
  _test: { matchesPattern, globToRegex }
};
